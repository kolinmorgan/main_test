		<div class="row">
            <div class="form-group">
                <div class="col-md-12"><input type="text" id="callback-name" class="form-control" name="CallBack[name]" placeholder="Ваше имя"></div>
                <div class="help-block"></div>
            </div>
		</div>
		<div class="row">	
            <div class="form-group">
                <div class="col-md-12"><input type="text" id="callback-phone" class="form-control" name="CallBack[phone]" placeholder="Ваш номер"></div>
                <div class="help-block"></div>
            </div>
        </div>
        <div class="row">
            <div class="form-group">
                <div class="col-md-12"><input type="text" id="callback-email" class="form-control" name="CallBack[email]" placeholder="Ваш e-mail"></div>
                <div class="help-block"></div>
            </div>
		</div>
		<div class="row">		
            <div class="form-group">
                <div class="col-md-12"><input type="text" id="callback-subject" class="form-control" name="CallBack[subject]" placeholder="Тема сообщения"></div>
                <div class="help-block"></div>
            </div>
        </div>
        <div class="row">
            <div class="form-group">
                <div class="col-md-12"><textarea style="resize:none;" id="callback-text" class="form-control" name="CallBack[text]" placeholder="Сообщение"></textarea></div>
                <div class="help-block"></div>
            </div>        
		</div>
		<div class="row" style="margin-top:15px;">
			<div class="col-md-12"><button type="submit" class="btn btn-danger">Отправить</button></div>
		</div>