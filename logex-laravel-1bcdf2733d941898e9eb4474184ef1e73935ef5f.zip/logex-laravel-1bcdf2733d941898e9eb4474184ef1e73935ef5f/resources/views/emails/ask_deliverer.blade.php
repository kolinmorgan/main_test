<html>
<body>
<h1>Вызов курьера</h1>
<div class="order">
	<table>
		<tr bgcolor="#f1f1f1">
			<td width="200">Имя:</td>
			<td width="400">{{ $curierForm['name'] }}</td>
		</tr>
		<tr>
			<td>Телефон:</td>
			<td>{{ $curierForm['phone'] }}</td>
		</tr>	
		<tr bgcolor="#f1f1f1">
			<td>Город:</td>
			<td>{{ $curierForm['country'] }}</td>
		</tr>	
		<tr>
			<td>Адрес:</td>
			<td>{{ $curierForm['adress'] }}</td>
		</tr>	
		<tr bgcolor="#f1f1f1">
			<td>Когда:</td>
			<td>{{ $curierForm['when'] }}</td>
		</tr>	
		<tr>
			<td>Вес:</td>
			<td>{{ $curierForm['weight'] }}</td>
		</tr>	
		<tr bgcolor="#f1f1f1">
			<td colspan="2">
			@if($curierForm['package'] == 1)
				Нужна упаковка <br />
			@endif			
			</td>
		</tr>	
		<tr>
			<td colspan="2">
			@if($curierForm['insurance'] == 1)
				Нужна страховка <br />
			@endif			
			</td>
		</tr>				
	</table>
</div>
</body>
</html>