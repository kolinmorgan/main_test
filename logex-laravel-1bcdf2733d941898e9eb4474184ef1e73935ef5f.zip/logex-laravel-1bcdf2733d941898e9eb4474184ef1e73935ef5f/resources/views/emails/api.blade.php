<html>
<body>
<h1>Заказ с DarBazar № {{$data['data']['code']}}</h1>
@foreach($data['data']['from'] as $key=> $from)
Отправитель № {{$key+1}}
Город: {{$from['city'] or '' }}<br>
Вес: {{$from['weight'] or '' }}<br>
Название: {{$from['name'] or '' }}<br>
Телефон: {{$from['phone'] or '' }}<br>
Адрес: {{$from['address'] or '' }}<br>
Объем: {{$from['volume'] or '' }}<br>
Товар: {{$from['product'] or '' }}<br>

@endforeach
<br><br>
Получатель 
Город: {{$data['data']['to']['city'] or '' }}<br>
Название: {{$data['data']['to']['name'] or '' }}<br>
Телефон: {{$data['data']['to']['phone'] or '' }}<br>
Адрес: {{$data['data']['to']['address'] or '' }}<br>

Стоимость заказа: {{$data['data']['payment_sum'] or '' }}<br>
Тип оплаты: {{$data['data']['payment_type'] or '' }}<br>
</body>
</html>