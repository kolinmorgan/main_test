<html>
<body>
<h1>Обратный звонок</h1>
<div class="order">
	<table>
		<tr bgcolor="#f1f1f1">
			<td width="200">Имя:</td>
			<td width="400">{{ $сallBack['name'] }}</td>
		</tr>
		<tr>
			<td>Телефон:</td>
			<td>{{ $сallBack['phone'] }}</td>
		</tr>		
		<tr bgcolor="#f1f1f1">
			<td>Почта:</td>
			<td>{{ $сallBack['email'] }}</td>
		</tr>		
		<tr>
			<td>Тема:</td>
			<td>{{ $сallBack['subject'] }}</td>
		</tr>		
		<tr bgcolor="#f1f1f1">
			<td>Сообщение:</td>
			<td>{{ $сallBack['text'] }}</td>
		</tr>		
	</table>
</div>
</body>
</html>