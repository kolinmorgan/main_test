<html>
<body>
<h1>Контакты</h1>
<div class="order">
	<table>
		<tr bgcolor="#f1f1f1">
			<td width="200">Имя:</td>
			<td width="400">{{ $contactForm['name'] }}</td>
		</tr>
		<tr>
			<td>Почта:</td>
			<td>{{ $contactForm['email'] }}</td>
		</tr>	
		<tr bgcolor="#f1f1f1">
			<td>Тема:</td>
			<td>{{ $contactForm['subject'] }}</td>
		</tr>
		<tr>
			<td>Сообщение:</td>
			<td>{{ $contactForm['body'] }}</td>
		</tr>			
	</table>	
</div>
</body>
</html>