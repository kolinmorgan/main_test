<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="utf-8">
        <style>
            @import url('https://fonts.googleapis.com/css?family=Roboto&subset=cyrillic');
            .content {
                max-width: 360px;
            }
            p {
                margin: 5px;
            }
            hr {
                border-style: dashed;
            }
            td {
              width: 180px;
                text-align: right;
            }
        </style>
    </head>
    <body>
        <div class="content">
            <p style="text-align: center;">ТОО "Logex"</p>
            <p style="text-align: center;">БИН - 131040000642</p>
            <p style="text-align: center;">НДС Серия 60001 N0085787</p>
            <p style="text-align: center;">РК, г. Алматы, ул. Ратушного 16</p>
            <p style="text-align: center;">Зав. номер: {{$check['Data']['Cashbox']['UniqueNumber']}}</p>
            <p style="text-align: center;">Рег. номер:: {{$check['Data']['Cashbox']['RegistrationNumber']}}</p>
            <p style="text-align: center;">Порядковый номер чека №{{$check['Data']['CheckOrderNumber']}}</p>
            <p style="text-align: center;">Время: {{$check['Data']['DateTime']}}</p>
            <hr>
            <ol>
                
                @foreach($products['data']['from'] as $key=>$product)
                @if($product['count'] > 0)
                <li>
                {{$product['product']}} <br>
                {{number_format($product['count'], 2, ',', ' ')}} x {{number_format($product['price'], 2, ',', ' ')}} <span style="float: right;">{{number_format(($product['count']*$product['price']), 2, ',', ' ')}}</span>
                </li>
                @endif
                @endforeach
                
            </ol>
            <hr>
            <table>
                <tr>
                    <td>Итого за товары:</td>
                    <td>{{number_format($products['data']['payment_sum'], 2, ',', ' ')}}</td>
                </tr>
                <tr>
                    <td>Стоимость доставки:</td>
                    <td>{{number_format($products['data']['total_cost'], 2, ',', ' ')}}</td>
                </tr>
                <!--
                <tr>
                   
                    <td>Комиссия:</td>
                    <td>{{number_format($waybill->commission, 2, ',', ' ')}}</td>
                </tr>
                    -->
                <tr>
                    <td>Итого:</td>
                    <td>{{number_format(($products['data']['payment_sum']+$products['data']['total_cost']), 2, ',', ' ')}}</td>
                    <!--<td>{{number_format(($products['data']['payment_sum']+$products['data']['total_cost']+round($products['data']['payment_sum']*0.01)), 2, ',', ' ')}}</td>-->
                </tr>
               <tr>
                    <td>в т.ч. НДС:</td>
                    <td>{{number_format(($products['data']['total_cost']*0.12),2, ',', ' ')}}</td>
                </tr>
            </table>
            <hr>
            <p>Фискальный признак: {{$check['Data']['CheckNumber']}}</p>
            <p>Оператор фильскальных данных АО "Казахтелеком"</p>
            <p>Для проверки чека зайдите на сайт consumer.oofd.kz</p>
            <hr>
            <p style="text-align: center;">*** СПАСИБО ЗА ПОКУПКУ ***</p>
        </div>
    </body>
</html>
