@extends('cabinet.layouts.app')

@section('content')



<section class="content">


    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Заказы с Darbazar</h3>

                <div class="box-tools">

                    <a class="btn btn-success" href="{!! route('cabinet.waybills.create') !!}">Создать</a>    

                </div>
            </div>
            <div class="box-body table-responsive no-padding">

                <div class="box-table-admin">
                    <div class="double-scroll">
                        <table class="table table-hover" id="waybills-table">
                            <tbody>
                                <tr>
                                    <th>Дата приема</th>
                                    <th>Номер накладной</th>
                                    <th>Номер darbazar</th>
                                    <th>Статус</th>
                                    <th>Действия</th>
                                </tr>


                                @foreach($waybills as $waybill)
                                
                                @if(in_array($waybill->status, ['Новая','В доставке', 'Принят']) && ((time() - strtotime($waybill->send_date)) > 432000)) <tr class="warning"> @else <tr> @endif
                                   
                     
                                    <td>{!! $waybill->send_date !!}</td>
                                    <td>{!! $waybill->code !!}</td>
                                    <td>{!! $waybill->darbazar_id !!}</td>

                                    <td>
                                        
                                        {!! Form::model($waybill, ['route' => ['cabinet.waybills.update', $waybill->id], 'method' => 'patch']) !!}
                                         @if($waybill->waybills->where('status', 'Забор осуществлён')->count() == count($waybill->waybills))
                                        {!! Form::select('status', ['Новая' => 'Новая', 'В обработке' => 'В обработке', 'В доставке' => 'В доставке', 'Забор осуществлён' => 'Забор осуществлён', 'Доставлено' => 'Доставлено', 'Не доставлено' => 'Не доставлено', 'Возврат' => 'Возврат', 'Частичный возврат' => 'Частичный возврат','Возврат в сортировочный центр'=>'Возврат в сортировочный центр'], $waybill->status, ['class' => 'form-control, selectpicker',  'data-container' => 'body',  'data-width' => '150px']) !!}
                                        <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-saved" aria-hidden="true"></span></button>
                                        @else
                                        
                                        {!! Form::select('status', ['Новая' => 'Новая', 'В обработке' => 'В обработке', 'В доставке' => 'В доставке', 'Забор осуществлён' => 'Забор осуществлён', 'Доставлено' => 'Доставлено', 'Не доставлено' => 'Не доставлено', 'Возврат' => 'Возврат', 'Частичный возврат' => 'Частичный возврат','Возврат в сортировочный центр'=>'Возврат в сортировочный центр'], $waybill->status, ['class' => 'form-control, selectpicker',  'data-container' => 'body',  'data-width' => '150px','disabled' => 'disabled']) !!}
                                        @endif
                                        {!! Form::close() !!}
                                        
                                    </td>
                                   
                                    <td>
                                        {!! Form::open(['route' => ['cabinet.waybills.destroy', $waybill->id], 'method' => 'delete']) !!}

                                        <a class="btn btn-success" href="{!! route('cabinet.waybills.show', ['id' => $waybill->id]) !!}" >смотреть</a>

                                        <a class="btn btn-warning" href="{!! route('cabinet.waybills.edit', [$waybill->id]) !!}">править</a>
                    

                                        {!! Form::close() !!}
                                    </td>
                                    
                                </tr>
                                @foreach($waybill->waybills as $w)
                                                                @if(in_array($w->status, ['Новая','В доставке', 'Принят']) && ((time() - strtotime($waybill->send_date)) > 432000)) <tr class="warning"> @else <tr> @endif
                                  
                
                                    <td>{!! $w->send_date !!}</td>
                                    <td>{!! $w->code !!}</td>
                                    <td>{!! $w->darbazar_id !!}</td>

                                    <td>
                                        
                                        {!! Form::model($w, ['route' => ['cabinet.waybills.update', $w->id], 'method' => 'patch']) !!}
                                        {!! Form::select('status', ['Новая' => 'Новая', 'В обработке' => 'В обработке', 'В доставке' => 'В доставке', 'Забор осуществлён' => 'Забор осуществлён', 'Доставлено' => 'Доставлено', 'Не доставлено' => 'Не доставлено', 'Возврат' => 'Возврат', 'Частичный возврат' => 'Частичный возврат','Возврат в сортировочный центр'=>'Возврат в сортировочный центр'], $w->status, ['class' => 'form-control, selectpicker',  'data-container' => 'body',  'data-width' => '150px']) !!}
                                        <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-saved" aria-hidden="true"></span></button>

                                        {!! Form::close() !!}
                                       
                                    </td>
                                   
                                    <td>
                                        {!! Form::open(['route' => ['cabinet.waybills.destroy', $w->id], 'method' => 'delete']) !!}

                                        <a class="btn btn-success" href="{!! route('cabinet.waybills.show', ['id' => $w->id]) !!}" >смотреть</a>

                                        <a class="btn btn-warning" href="{!! route('cabinet.waybills.edit', [$w->id]) !!}">править</a>
                    

                                        {!! Form::close() !!}
                                    </td>
                                    
                                </tr>
                                @endforeach
                                <tr>
                                    <td colspan="5"></td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>


            </div>    
            <div class="box-footer clearfix">
                {!! $waybills->render() !!}
            </div>

        </div>
    </div>


</section>

@endsection
