@extends('cabinet.layouts.app')

@section('content')

<section class="content">
    @include('flash::message')
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Доставки курьера</h3>

            </div>
            <div class="box-body table-responsive no-padding">

                <div class="box-table-admin">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <!--<th>Статус</th>-->
                                <th>Курьер</th>
                                <th>Место приема</th>
                                <th>Место доставки</th>
                                <th>Дата создания</th>
                                <th>Дата изменения</th>
                                <th>Накладная</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($routes as $route)
                            <tr>

                                <!--<td>{{ $route->status }}</td>-->
                                <td>{{ $route->courier->name }}</td>
                                <td>({{$route->from_text}}) {{$route->from_value_text}}</td>
                                <td>({{$route->to_text}}) {{$route->to_value_text}}</td>
                                <td>{{ date('d.m.Y H:i', strtotime($route->created_at)) }}
                                <td>{{ date('d.m.Y H:i', strtotime($route->updated_at)) }}
                                @if(isset($route->waybill->code))
                                <td><a href="/cabibet/waybills/{{$route->waybill->code}}">{{$route->waybill->code}}</a></td>
                                @else
                                <td>Накладная удалена</td>
                                @endif

                            </tr>
                            @endforeach

                        </tbody>
                    </table>
                </div>


            </div>    
            <div class="box-footer clearfix">
                {!! $routes->render() !!}
            </div>

        </div>
    </div>


</section>


<!-- /.box -->
@endsection
