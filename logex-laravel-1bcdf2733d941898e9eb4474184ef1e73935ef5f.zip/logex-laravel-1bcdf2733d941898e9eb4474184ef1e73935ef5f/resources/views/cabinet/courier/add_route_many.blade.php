<form type="POST" id="add-route">


    <div class="form-group col-sm-12">
        <label for="courier_id">Курьер</label>
        <input type="hidden" id="add-route-waybill-id" name="waybill_id" value="{{$waybill->id}}">
        {{ csrf_field() }}

        <select id="courier_id" name="courier_id" class="selectpicker form-control"  data-live-search="true" data-container="body">
            <optgroup label="Курьеры в городе приема">
                @foreach($couriers as $courier)
                @if($waybill->sender_city == $courier->location->name)
                <option value="{{$courier->id}}">{{$courier->name}}</option>
                @endif
                @endforeach
            </optgroup>
            <optgroup label="Курьеры в городе доставки">
                @foreach($couriers as $courier)
                @if($waybill->recepient_city == $courier->location->name)
                <option value="{{$courier->id}}">{{$courier->name}}</option>
                @endif
                @endforeach
            </optgroup>
           <optgroup label="Курьеры привязанные к компании">
                @foreach($couriers as $courier)
                @foreach($courier->company as $company)
                @if($waybill->company_sender->id == $company->id)
                <option value="{{$courier->id}}">{{$courier->name}}</option>
                @endif
                @endforeach
                @endforeach
            </optgroup>
            <optgroup label="Все курьеры">
                @foreach($couriers as $courier)
                <option value="{{$courier->id}}">{{$courier->name}}</option>
                @endforeach
            </optgroup>
        </select>
    </div>

    <div class="form-group col-sm-6">
        <label for="courier_from">От</label>

        <select id="courier_from" name="from" class="form-control">
            <option value="client">Клиент отправитель</option>
            <option value="sort_center">Сортировочный центр</option>
            <option value="custom">Другое (адрес)</option>
        </select>
    </div>

    <div id="courier_from_sort_center" style="display: none;" class="form-group col-sm-6">
        <label>Сортировочный центр</label>

        <select name="from_sort_center" class="selectpicker form-control"  data-live-search="true" data-container="body">
            @foreach($sort_centers as $center)
            <option value="{{$center->id}}">{{$center->location->name}} {{$center->name}}</option>
            @endforeach
        </select>
    </div>
    <div id="courier_from_custom" style="display: none;" class="form-group col-sm-6">
        <label>Адрес</label>
        <input name="from_custom" class="form-control">
    </div>


    <div class="clearfix"></div>

    <div class="form-group col-sm-6">
        <label for="courier_to">До</label>

        <select id="courier_to" name="to" class="form-control">
            <option value="client">Клиент получатель</option>
            <option value="sort_center">Сортировочный центр</option>
            <option value="custom">Другое (адрес)</option>
        </select>
    </div>


    <div id="courier_to_sort_center" style="display: none;" class="form-group col-sm-6">
        <label>Сортировочный центр</label>

        <select name="to_sort_center" class="selectpicker form-control"  data-live-search="true" data-container="body">
            @foreach($sort_centers as $center)
            <option value="{{$center->id}}">{{$center->location->name}} {{$center->name}}</option>
            @endforeach
        </select>
    </div>
    <div id="courier_to_custom" style="display: none;" class="form-group col-sm-6">
        <label>Адрес</label>
        <input name="to_custom" class="form-control">
    </div>

    <div class="form-group col-sm-12">
        {!! Form::button('Сохранить', ['class' => 'btn btn-success', 'id' => 'add-route-button']) !!}

    </div>
</form>