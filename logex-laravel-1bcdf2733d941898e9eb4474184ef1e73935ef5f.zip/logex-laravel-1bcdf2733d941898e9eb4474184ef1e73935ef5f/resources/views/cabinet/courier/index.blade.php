@extends('cabinet.layouts.app')

@section('content')

<section class="content">
    @include('flash::message')
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Курьеры</h3>

            </div>
            <div class="box-body table-responsive no-padding">

                <div class="box-table-admin">
                    <table class="table table-hover" id="waybills-table">
                        <thead>
                            <tr>
                             <th>Имя</th>
                             <th>email</th>
                             <th>Курьерская компания</th>
                             <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($users as $user)
                            <tr>
                                <td>{!! $user->name !!}</td>
                                <td>{{ $user->email }}</td>
                                <td>{{ $user->company_name }}</td>
                                <td>
                                    <form method="POST" action="/cabinet/couriers/update" class="form-inline">
                                        {{ csrf_field() }}
                                        <input type="hidden" value="{{$user->id}}" name="user_id">
           
                                         {!! Form::select('role', ['admin' => 'Администратор', 'manager' => 'Оператор', 'courier' => 'Курьер', 'user' => 'Клиент', 'ban' => 'Удалён'], $user->role, ['class' => 'form-control selectpicker','data-container' => 'body', 'data-live-search' => 'true', 'data-width' => '150px']) !!}
                                         {!! Form::select('location_id', App\Models\Location::all('id', 'name')->lists('name', 'id'), $user->location_id, ['class' => 'form-control selectpicker','data-container' => 'body', 'data-live-search' => 'true', 'data-width' => '150px']) !!}
                                          
                                         {!! Form::select('company_id[]', App\Models\Company::all('id', 'name')->lists('name', 'id'), $user->company->lists('id')->all(), ['class' => 'form-control selectpicker','data-container' => 'body', 'multiple' => 'multiple', 'data-live-search' => 'true', 'data-width' => '150px']) !!}
                                          <button type="submit" class="btn btn-success">Обновить</button>
                                          <a class="btn btn-success" href='/cabinet/couriers/routes/{{$user->id}}'>Доставки</a>
                                         <button type="submit" name="role" value="ban" class="btn btn-danger">Заблокировать</button>
                                    
                                    </form>
                                    
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>


            </div>    
            <div class="box-footer clearfix">
                {!! $users->render() !!}
            </div>

        </div>
    </div>


</section>


<!-- /.box -->
@endsection
