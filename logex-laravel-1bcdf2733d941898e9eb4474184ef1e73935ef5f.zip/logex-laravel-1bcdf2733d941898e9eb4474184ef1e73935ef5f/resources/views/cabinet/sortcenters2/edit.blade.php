@extends('cabinet.layouts.app')

@section('content')

<section class="content">
    <!-- Default box -->
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Редактировать локацию</h3>

            </div>
            <div class="box-body">

                @include('core-templates::common.errors')


                {!! Form::model($center, ['route' => ['cabinet.sortcenters.update', $center->id], 'method' => 'patch']) !!}

                @include('cabinet.sortcenters.fields')

                {!! Form::close() !!}

            </div>	
        </div> 
    </div> 
</section>
@endsection