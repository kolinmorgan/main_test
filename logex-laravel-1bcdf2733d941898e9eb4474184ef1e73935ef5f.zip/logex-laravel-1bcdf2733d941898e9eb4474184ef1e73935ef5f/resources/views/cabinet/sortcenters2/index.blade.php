@extends('cabinet.layouts.app')

@section('content')



<section class="content">

    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Сортировочные центры</h3>
                <div class="box-tools">
                    <a class="btn btn-success" href="{!! route('cabinet.sortcenters.create') !!}">Создать</a>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">

                <div class="box-table-admin">
                    <table class="table table-hover" id="waybills-table">
                        <tbody>
                            <tr>
                                <th>Название</th>
                                <th>Адрес</th>
                                <th>Город</th>
                                <th colspan="3">Действие</th>
                            </tr>



                            @foreach($centers as $center)
                            <tr>
                                <td>{!! $center->name !!}</td>
                                <td>{!! $center->adress !!}</td>
                                <td>{!! $center->location->name !!}</td>
                                

                                <td>
                                    <a class="btn btn-warning" href="{!! route('cabinet.sortcenters.edit', [$center->id]) !!}">править</a>
                                </td>

                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>


            </div>    
            <div class="box-footer clearfix">
                {!! $centers->render() !!}
            </div>

        </div>
    </div>


</section>


<!-- /.box -->
@endsection
