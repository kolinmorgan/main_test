<div class="form-group col-sm-6">
    {!! Form::label('name', 'Название :') !!}
    {!! Form::text('name', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group col-sm-6">
    {!! Form::label('adress', 'Адрес :') !!}
    {!! Form::text('adress', null, ['class' => 'form-control']) !!}
</div>


<div class="form-group col-sm-12">
    {!! Form::label('location_id',  'Город :') !!}
    {!! Form::select('location_id',  App\Models\Location::all('id','name')->lists('name','id'), null, ['class' => 'form-control selectpicker', 'data-live-search' => 'true', 'data-container' => 'body']) !!}
</div>


<div class="form-group col-sm-12">
    {!! Form::submit('Сохранить', ['class' => 'btn btn-success']) !!}
    <a href="{!! route('cabinet.sortcenters.index') !!}" class="btn btn-danger">Отменить</a>
    
</div>
