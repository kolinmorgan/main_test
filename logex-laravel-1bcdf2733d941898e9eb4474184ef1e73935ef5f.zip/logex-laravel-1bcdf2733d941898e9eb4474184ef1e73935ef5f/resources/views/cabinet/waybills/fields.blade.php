<!-- User Id Field -->

<!--
<div class="form-group col-sm-6">
    {!! Form::label('user_id', 'User Id:') !!}
    {!! Form::select('user_id', App\User::all('id','name')->lists('name','id'), null, ['class' => 'form-control selectpicker', 'data-container' => 'body']) !!}
</div>
-->
<!-- Manager Field -->

<div class="form-group col-sm-12">
    {!! Form::label('manager', 'Менеджер отправитель :') !!}
    {!! Form::text('manager', null, ['class' => 'form-control']) !!}
</div>

<!-- Send date Date Field -->
<div class="form-group col-sm-6">
    {!! Form::label('send_date', 'Дата приема:') !!}
    {!! Form::text('send_date', null, ['class' => 'form-control datepicker-here']) !!}
</div>
<!-- Code Field -->
<div class="form-group col-sm-6">
    {!! Form::label('code', 'Номер накладной:') !!}
    {!! Form::text('code', null, ['class' => 'form-control']) !!}
</div>
<!-- package_id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('package_id', 'Номер отправления:') !!}
    {!! Form::text('package_id', null, ['class' => 'form-control']) !!}
</div>
<!-- company_cod Field -->
<div class="form-group col-sm-6">
    {!! Form::label('company_cod', 'Номер накладной (Компании):') !!}
    {!! Form::text('company_cod', null, ['class' => 'form-control']) !!}
</div>
<div class="form-group col-sm-6">
    {!! Form::label('company_sender_id', 'Отправитель (Компания):') !!}
    {!! Form::select('company_sender_id', App\Models\Company::all()->lists('name', 'id'), null, ['class' => 'form-control selectpicker','data-container' => 'body', 'data-live-search' => 'true', 'title' => 'Отправитель']) !!}
</div>

<!-- company_sender_name Field -->
<div class="form-group col-sm-6">
    {!! Form::label('company_recipient_name', 'Получатель (Компания):') !!}
    {!! Form::text('company_recipient_name', null, ['class' => 'form-control']) !!}
</div>
<!-- sender_city Field -->
<div class="form-group col-sm-6">
    {!! Form::label('sender_city', 'Город отправителя:') !!}
    {!! Form::select('sender_city', App\Models\Location::all('name')->lists('name', 'name'), null, ['class' => 'form-control selectpicker','data-container' => 'body', 'data-live-search' => 'true']) !!}

</div>
<!-- recipient_city Field -->
<div class="form-group col-sm-6">
    {!! Form::label('recipient_city', 'Город получателя:') !!}
    {!! Form::select('recipient_city', App\Models\Location::all('name')->lists('name', 'name'), null, ['class' => 'form-control selectpicker','data-container' => 'body', 'data-live-search' => 'true']) !!}
</div>

<div class="form-group col-sm-6">
    {!! Form::label('sender_address', 'Адрес отправителя:') !!}
    {!! Form::text('sender_address', null, ['class' => 'form-control']) !!}

</div>
<!-- recipient_city Field -->
<div class="form-group col-sm-6">
    {!! Form::label('recipient_address', 'Адрес получателя:') !!}
    {!! Form::text('recipient_address', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group col-sm-6">
    {!! Form::label('sender_phone', 'Телефон отправителя:') !!}
    {!! Form::text('sender_phone', null, ['class' => 'form-control']) !!}

</div>
<!-- recipient_city Field -->
<div class="form-group col-sm-6">
    {!! Form::label('recipient_phone', 'Телефон получателя:') !!}
    {!! Form::text('recipient_phone', null, ['class' => 'form-control']) !!}
</div>
<!-- places Field -->
<div class="form-group col-sm-6">
    {!! Form::label('places', 'Кол-во мест:') !!}
    {!! Form::text('places', null, ['class' => 'form-control']) !!}
</div>
<!-- weight Field -->
<div class="form-group col-sm-6">
    {!! Form::label('weight', 'Вес:') !!}
    {!! Form::text('weight', null, ['class' => 'form-control']) !!}
</div>
<!-- kind Field -->
<div class="form-group col-sm-6">
    {!! Form::label('kind', 'Вид отправления:') !!}
    {!! Form::text('kind', null, ['class' => 'form-control']) !!}
</div>
<!-- priority Field -->
<div class="form-group col-sm-6">
    {!! Form::label('priority', 'Важность:') !!}
    {!! Form::select('priority', ['Стандарт' => 'Стандарт', 'Экспресс'=> 'Экспресс', 'Авиа' => 'Авиа','Жд' => 'Жд','Город' => 'Город','Россия' => 'Россия','Международ' => 'Международ','Зона город' => 'Зона город'], null, ['class' => 'form-control selectpicker']) !!}
</div>
<!-- description Field -->
<div class="form-group col-sm-6">
    {!! Form::label('description', 'Прочие отметки:') !!}
    {!! Form::text('description', null, ['class' => 'form-control']) !!}
</div>

<!-- cost Field -->
<div class="form-group col-sm-6">
    <div class="row">
    <div class="col-xs-12">
        {!! Form::label('cost', 'Стоимость доставки:') !!}
    </div>
    <div class="col-xs-6">
        {!! Form::text('cost', null, ['class' => 'form-control', 'id'=>'waybill-cost']) !!}
    </div>
    <div class="col-xs-6">
        <button id="calc-button" class="btn btn-success">Рассчитать</button>
    </div>   
   </div>
</div>
<!-- Status Field -->
<div class="form-group col-sm-6">
    {!! Form::label('status', 'Статус:') !!}
    @if(isset($waybill))
     @if($waybill->waybills->where('status', 'Забор осуществлён')->count() == count($waybill->waybills))
    {!! Form::select('status', ['Новая' => 'Новая', 'В обработке' => 'В обработке', 'В доставке' => 'В доставке', 'Забор осуществлён' => 'Забор осуществлён', 'Доставлено' => 'Доставлено', 'Не доставлено' => 'Не доставлено', 'Возврат' => 'Возврат', 'Частичный возврат' => 'Частичный возврат'], null, ['class' => 'form-control']) !!}
    @else
    {!! Form::select('status', ['Новая' => 'Новая', 'В обработке' => 'В обработке', 'В доставке' => 'В доставке', 'Забор осуществлён' => 'Забор осуществлён', 'Доставлено' => 'Доставлено', 'Не доставлено' => 'Не доставлено', 'Возврат' => 'Возврат', 'Частичный возврат' => 'Частичный возврат'], null, ['class' => 'form-control', 'disabled' => 'disabled']) !!}
    @endif
    @else
    {!! Form::select('status', ['Новая' => 'Новая', 'В обработке' => 'В обработке', 'В доставке' => 'В доставке', 'Забор осуществлён' => 'Забор осуществлён', 'Доставлено' => 'Доставлено', 'Не доставлено' => 'Не доставлено', 'Возврат' => 'Возврат', 'Частичный возврат' => 'Частичный возврат'], null, ['class' => 'form-control']) !!}
    @endif
</div>

<div class="form-group col-sm-6">
    {!! Form::label('return_reason', 'Причина возврата:') !!}
    {!! Form::text('return_reason', null, ['class' => 'form-control']) !!}
</div>
<!-- Delivery Date Field -->
<div class="form-group col-sm-6">
    {!! Form::label('delivery_date', 'Дата доставки:') !!}
    {!! Form::text('delivery_date', null, ['class' => 'form-control datepicker-here']) !!}
</div>
<!-- Delivery Time Field -->
<div class="form-group col-sm-6">
    {!! Form::label('delivery_time', 'Время доставки:') !!}
    {!! Form::text('delivery_time', null, ['class' => 'form-control']) !!}
</div>
<!-- recipient Field -->
<div class="form-group col-sm-6">
    {!! Form::label('recipient', 'ФИО Получателя:') !!}
    {!! Form::text('recipient', null, ['class' => 'form-control']) !!}
</div>
<!-- recipient_position Field -->
<div class="form-group col-sm-6">
    {!! Form::label('recipient_position', 'Должность получателя:') !!}
    {!! Form::text('recipient_position', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group col-sm-6">
    {!! Form::label('volume', 'Объем:') !!}
    {!! Form::text('volume', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group col-sm-6">
    {!! Form::label('product', 'Название товара:') !!}
    {!! Form::text('product', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group col-sm-6">
    {!! Form::label('payment_type', 'Тип оплаты:') !!}
    {!! Form::select('payment_type', ['' => '', 'безналичный' => 'безналичный', 'наличный' => 'наличный'], null, ['class' => 'form-control selectpicker']) !!}
</div>
<div class="form-group col-sm-6">
    {!! Form::label('payment_sum', 'Цена товаров:') !!}
    {!! Form::text('payment_sum', null, ['class' => 'form-control']) !!}
</div>
@if(isset($waybill) && $waybill->payment_sum > 0 && $waybill->payment_type == 'наличный')
<div class="form-group col-xs-6">
    <label>Комиссия (DarBazar)</label>
    <input class="form-control" disabled="disabled" value="{{$waybill->commission}}">
</div>
@endif
<div class="form-group col-sm-6">
    {!! Form::label('darbazar_id', 'Номер с дарбазара:') !!}
    {!! Form::text('darbazar_id', null, ['class' => 'form-control']) !!}
</div>
<!-- Submit Field -->
<div class="form-group col-sm-12">
    {!! Form::submit('Сохранить', ['class' => 'btn btn-success']) !!}
    <a href="{!! route('cabinet.waybills.index') !!}" class="btn btn-danger">Отменить</a>
    <a href="{!! route('cabinet.waybills.create',['withold' => true]) !!}" class="btn btn-warning">Предыдущая накладная</a>
</div>

<script>
    $('#company_sender_id').on('changed.bs.select', function () {
     
        
        $.get('/cabinet/companies/meta/'+$(this).find("option:selected").val(),function(data) {
            data = JSON.parse(data);
            //if($('#sender_address').val() == '') {
            $('#sender_address').val(data.address);
        //}
          if(data.code != '') {
            $('#code').val(data.code);
           }
        });
     
});

    </script>