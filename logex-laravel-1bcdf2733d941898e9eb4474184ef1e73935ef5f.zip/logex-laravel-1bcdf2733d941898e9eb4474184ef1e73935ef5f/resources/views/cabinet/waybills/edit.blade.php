@extends('cabinet.layouts.app')

@section('content')

<section class="content">
    <!-- Default box -->
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Редактировать накладную</h3>

            </div>
            <div class="box-body">

                @include('core-templates::common.errors')
                @include('vendor.flash.message')


                {!! Form::model($waybill, ['route' => ['cabinet.waybills.update', $waybill->id], 'method' => 'patch', 'id' => 'waybill_form']) !!}

                @include('cabinet.waybills.fields')

                {!! Form::close() !!}

                @if($waybill->api_request != false)
                <div class="col-xs-12">



                    <p style="text-align: center;" class="col col-100">
                        Товары с Darbazar
                    </p>


                    @foreach($waybill->api_request['data']['from'] as $key => $value)
                    <hr>
                    <p style="text-align: center;" class="col col-100">
                        # {{($key + 1)}}
                    </p>

                    <p><b>Город и адрес</b> г.{{$value['city'] or ''}}, {{$value['address'] or ''}}</p>
                    <p><b>Телефон</b>{{$value['phone'] or ''}}</p>
                    <p><b>Товар и количество</b> {{$value['product'] or ''}} x {{$value['count'] or ''}}</p>

                    <p><b>Цена</b> {{$value['price'] or ''}} x {{$value['count'] or ''}} </p>
                    <p><b> Вес и объем (за 1)</b> {{$value['weight'] or ''}} кг, {{$value['volume'] or ''}}м3</p>


                    @endforeach
                </div>
                @endif
            </div>
        </div>
    </div>	
</div> 
</div> 
</section>
@endsection