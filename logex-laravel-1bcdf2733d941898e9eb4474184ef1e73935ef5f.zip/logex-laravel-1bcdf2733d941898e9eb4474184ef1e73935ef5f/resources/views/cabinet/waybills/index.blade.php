@extends('cabinet.layouts.app')

@section('content')



<section class="content">


    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Фильтр</h3>
            </div>
            <div class="box-body">

                <form  action="/cabinet/waybills" method="GET">
                    <div class="col-xs-4">
                        <div class="form-group">
                            <label>С</label>
                            <input type="text" value="{{$searchInput['from'] or ''}}" name="from" class="datepicker-here form-control">

                        </div>	
                        <div class="form-group">
                            <label>По</label> 
                            <input type="text" value="{{$searchInput['to'] or ''}}" name="to" class="datepicker-here form-control">
                        </div>

                    </div>
                    <div class="col-xs-4">
                        <div class="form-group">
                            <label>Номер накладной</label> 
                            <input class="form-control" value="{{$searchInput['company_cod'] or ''}}" type="text" placeholder="Номер накладной" name="company_cod">				
                        </div>
                        <div class="form-group">
                            <label>Отправитель (Компания)</label>

                            <select class="form-control selectpicker" data-width="100%" data-live-search="true"  name="company_sender_id">
                                <option value="">Все</option>
                                @foreach($company_senders as $company)
                                @if(isset($searchInput['company_sender_id']) && $searchInput['company_sender_id'] == $company->id)
                                <option value="{{$company->id}}" selected="selected" >{{$company->name}}</option>
                                @else
                                <option value="{{$company->id}}">{{$company->name}}</option>
                                @endif
                                @endforeach
                            </select>
                        </div>
                    </div> 
                    <div class="col-xs-4">
                        <div class="form-group"> 
                            <label>Статус</label>
                            {!! Form::select('status', ['' => 'Все', 'Новая' => 'Новая', 'В обработке' => 'В обработке', 'В доставке' => 'В доставке', 'Забор осуществлён' => 'Забор осуществлён', 'Доставлено' => 'Доставлено', 'Не доставлено' => 'Не доставлено', 'Возврат' => 'Возврат', 'Частичный возврат' => 'Частичный возврат', 'Удалено' => 'Удалено'], isset($searchInput['status']) ? $searchInput['status'] : '', ['class' => 'form-control']) !!}
                        </div>
                        <button class="btn btn-default" type="submit">Поиск</button>
                        <button class="btn btn-success" formaction="/cabinet/waybills/export" type="submit">Скачать накладные</button>
                        <a href="/cabinet/waybills" class="btn btn-danger" >Очистить поиск</a>
                    </div>
                </form>
            </div>   
        </div>
    </div>

    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Накладные</h3>

                <div class="box-tools">

                    <a class="btn btn-success" href="{!! route('cabinet.waybills.create') !!}">Создать</a>    

                </div>
            </div>
            <div class="box-body table-responsive no-padding">

                <div class="box-table-admin">
                    <div class="double-scroll">
                        <table class="table table-hover" id="waybills-table">
                            <tbody>
                                <tr>
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')  
                                    <th>Править</th>
                                    <th>Управление курьерами</th>
                                    @endif
                                    <th>Пользователь</th>
                                    <th>Менеджер отправитель</th>
                                    <th>Дата приема</th>
                                    <th>Номер Накладной</th>
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')      
                                    <th>Номер отправления</th>
                                    <th>Номер накладной (Компании)</th>
                                    @endif        
                                    <th>Отправитель (Компания)</th>
                                    <th>Получатель (Компания)</th>
                                    <th>Город отправителя</th>
                                    <th>Город получателя</th>
                                    <th>Кол-во мест</th>
                                    <th>Вес</th>
                                    <th>Вид отправления</th>
                                    <th>Важность</th>
                                    <th>Прочие отметки</th>
                                    <th>Стоимость доставки</th>
                                    <th>Статус</th>
                                    <th>Дата доставки</th>
                                    <th>Время доставки</th>
                                    <th>ФИО Получателя</th>
                                    <th>Должность получателя</th>
                                    <th>Объем</th>
                                    <th>Название товара</th>
                                    <th>Оплата:</th>
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')   
                                    <th>Действие</th>
                                    @endif
                                </tr>

                                <tr>
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')  
                                    <th>Edit</th>
                                     <th>Courier control</th>
                                    @endif
                                    <th>User name</th>
                                    <th>Manager</th>
                                    <th>Pick up date</th>
                                    <th>Airway bill number</th>
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')  
                                    <th>Shipment number</th>
                                    <th>Airway bill number of sender (Company)</th>
                                    @endif        
                                    <th>Sender (Company)</th>
                                    <th>Receiver (Company)</th>
                                    <th>Origin city</th>
                                    <th>Destination city</th>
                                    <th>Quantity of place</th>
                                    <th>Weight</th>
                                    <th>Type of shipment</th>
                                    <th>Importance</th>
                                    <th>Addition</th>
                                    <th>Delivery cost</th>
                                    <th>Status</th>
                                    <th>Delivery date</th>
                                    <th>Delivery time</th>
                                    <th>Receiver's name</th>
                                    <th>Position of receiver</th>
                                    <th>Volume</th>
                                    <th>Product name</th>
                                    <th>Payment:</th>
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')  
                                   
                                    <th>Action</th>
                                    @endif
                                </tr>

                                @foreach($not_deliver as $waybill)
                                <tr style="background-color: red; color: white;">
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')  
                                    <td>
                                        <a class="btn btn-warning" href="{!! route('cabinet.waybills.edit', [$waybill->id]) !!}">править</a>
                                        <a class="btn btn-success" href="/waybills/print?id={{$waybill->id}}">Скачать</a>
                                        <button type="button" title="Печать" class="btn btn-warning" onclick=" var gadget = new cloudprint.Gadget();     
                                                    gadget.setPrintDocument('url', 'Накладная {{$waybill->code}}', 'http://logex.kz/waybills/print?id={{$waybill->id}}');
                                                                        gadget.openPrintDialog();">Печать</button>
                                    </td>
                                    <td>
                                @if($waybill->waybills->where('status', 'Забор осуществлён')->count() == count($waybill->waybills))
                                        <button type="button"  class="btn btn-success" onclick="getCourierModal({{$waybill->id}});">Курьерская схема</button>
                                        @endif
                                    </td>

                                    @endif
                                    <td>{!! $waybill->user->name !!}</td>
                                    <td>{!! $waybill->manager !!}</td>
                                    <td>{!! $waybill->send_date !!}</td>
                                    <td>{!! $waybill->code !!}</td>

                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')        
                                    <td>{!! $waybill->package_id !!}</td>
                                    <td>{!! $waybill->company_cod !!}</td>
                                    @endif   
                                    <td>{!! $waybill->company_sender->name !!}</td>
                                    <td>{!! $waybill->company_recipient_name !!}</td>
                                    <td>{!! $waybill->sender_city !!}</td>
                                    <td>{!! $waybill->recipient_city !!}</td>
                                    <td>{!! $waybill->places !!}</td>
                                    <td>{!! $waybill->weight !!}</td>
                                    <td>{!! $waybill->kind !!}</td>
                                    <td>{!! $waybill->priority !!}</td>
                                    <td>{!! $waybill->description !!}</td>
                                    <td>{!! $waybill->cost !!}</td>
                                    <td>
                                         @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')   
                                          @if($waybill->waybills->where('status', 'Забор осуществлён')->count() == count($waybill->waybills))
                                        {!! Form::model($waybill, ['route' => ['cabinet.waybills.update', $waybill->id], 'method' => 'patch']) !!}
                                        {!! Form::select('status', ['Новая' => 'Новая', 'В обработке' => 'В обработке', 'В доставке' => 'В доставке', 'Забор осуществлён' => 'Забор осуществлён', 'Доставлено' => 'Доставлено', 'Не доставлено' => 'Не доставлено', 'Возврат' => 'Возврат', 'Частичный возврат' => 'Частичный возврат'], $waybill->status, ['class' => 'form-control, selectpicker',  'data-container' => 'body',  'data-width' => '150px']) !!}
                                        <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-saved" aria-hidden="true"></span></button>
                                        @else
                                        {!! Form::select('status', ['Новая' => 'Новая', 'В обработке' => 'В обработке', 'В доставке' => 'В доставке', 'Забор осуществлён' => 'Забор осуществлён', 'Доставлено' => 'Доставлено', 'Не доставлено' => 'Не доставлено', 'Возврат' => 'Возврат', 'Частичный возврат' => 'Частичный возврат'], $waybill->status, ['class' => 'form-control, selectpicker',  'data-container' => 'body', 'disabled' => 'disabled', 'data-width' => '150px']) !!}
                                        @endif
                                        {!! Form::close() !!}
                                        @endif
                                    </td>
                                    <td>{!! $waybill->delivery_date !!}</td>
                                    <td>{!! $waybill->delivery_time !!}</td>
                                    <td>{!! $waybill->recipient !!}</td>
                                    <td>{!! $waybill->recipient_position !!}</td>
                                    <td>{!! $waybill->volume !!}</td>
                                    <td>{!! $waybill->product !!}</td>
                                    <td>{!! $waybill->payment_sum !!} {!! $waybill->payment_type !!}</td>
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')  
  
          
                                    <td>
                                        {!! Form::open(['route' => ['cabinet.waybills.destroy', $waybill->id], 'method' => 'delete']) !!}

                                        <a class="btn btn-success" href="{!! route('cabinet.waybills.show', ['id' => $waybill->id]) !!}" >смотреть</a>

                                        <a class="btn btn-warning" href="{!! route('cabinet.waybills.edit', [$waybill->id]) !!}">править</a>
                                        {!! Form::button('Удалить', ['type' => 'submit', 'class' => 'btn btn-danger', 'onclick' => "return confirm('Вы уверены?')"]) !!}


                                        {!! Form::close() !!}
                                    </td>
                                    @endif
                                </tr>
                                @endforeach
                                @foreach($waybills as $waybill)
                                @if((in_array($waybill->status, ['Новая','В доставке', 'Принят']) && ((time() - strtotime($waybill->send_date)) > 432000)) || $waybill->status == 'Возврат' || $waybill->status == 'Частичный возврат') <tr class="warning"> @else <tr> @endif
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')  
                                    <td><a class="btn btn-warning" href="{!! route('cabinet.waybills.edit', [$waybill->id]) !!}">править</a>
                                        <a class="btn btn-success" href="/waybills/print?id={{$waybill->id}}">Скачать</a>
                                        <button type="button" title="Печать" class="btn btn-warning" onclick=" var gadget = new cloudprint.Gadget();     
                                                            gadget.setPrintDocument('url', 'Накладная {{$waybill->code}}', 'http://logex.kz/waybills/print?id={{$waybill->id}}');
                                                                                        gadget.openPrintDialog();">Печать</button>
                                    </td>
                                                <td>
                                @if($waybill->waybills->where('status', 'Забор осуществлён')->count() == count($waybill->waybills))
                                        <button type="button"   class="btn btn-success" onclick="getCourierModal({{$waybill->id}});">Курьерская схема</button>
                                        @endif
                                    </td>
                                    @endif
                                    <td>{!! $waybill->user->name !!}</td>
                                    <td>{!! $waybill->manager !!}</td>
                                    <td>{!! $waybill->send_date !!}</td>
                                    <td>{!! $waybill->code !!}</td>

                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')         
                                    <td>{!! $waybill->package_id !!}</td>
                                    <td>{!! $waybill->company_cod !!}</td>
                                    @endif   
                                    <td>{!! $waybill->company_sender->name !!}</td>
                                    <td>{!! $waybill->company_recipient_name !!}</td>
                                    <td>{!! $waybill->sender_city !!}</td>
                                    <td>{!! $waybill->recipient_city !!}</td>
                                    <td>{!! $waybill->places !!}</td>
                                    <td>{!! $waybill->weight !!}</td>
                                    <td>{!! $waybill->kind !!}</td>
                                    <td>{!! $waybill->priority !!}</td>
                                    <td>{!! $waybill->description !!}</td>
                                    <td>{!! $waybill->cost !!}</td>
                                    <td>
                                        @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')   
                                          @if($waybill->waybills->where('status', 'Забор осуществлён')->count() == count($waybill->waybills))
                                        {!! Form::model($waybill, ['route' => ['cabinet.waybills.update', $waybill->id], 'method' => 'patch']) !!}
                                        {!! Form::select('status', ['Новая' => 'Новая', 'В обработке' => 'В обработке', 'В доставке' => 'В доставке', 'Забор осуществлён' => 'Забор осуществлён', 'Доставлено' => 'Доставлено', 'Не доставлено' => 'Не доставлено', 'Возврат' => 'Возврат', 'Частичный возврат' => 'Частичный возврат'], $waybill->status, ['class' => 'form-control, selectpicker',  'data-container' => 'body',  'data-width' => '150px']) !!}
                                        <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-saved" aria-hidden="true"></span></button>
                                        @else
                                        {!! Form::select('status', ['Новая' => 'Новая', 'В обработке' => 'В обработке', 'В доставке' => 'В доставке', 'Забор осуществлён' => 'Забор осуществлён', 'Доставлено' => 'Доставлено', 'Не доставлено' => 'Не доставлено', 'Возврат' => 'Возврат', 'Частичный возврат' => 'Частичный возврат'], $waybill->status, ['class' => 'form-control, selectpicker',  'data-container' => 'body', 'disabled' => 'disabled', 'data-width' => '150px']) !!}
                                        @endif
                                        {!! Form::close() !!}
                                        @endif
                                    </td>
                                    <td>{!! $waybill->delivery_date !!}</td>
                                    <td>{!! $waybill->delivery_time !!}</td>
                                    <td>{!! $waybill->recipient !!}</td>
                                    <td>{!! $waybill->recipient_position !!}</td>
                                        <td>{!! $waybill->volume !!}</td>
                                    <td>{!! $waybill->product !!}</td>
                                    <td>{!! $waybill->payment_sum !!} {!! $waybill->payment_type !!}</td>
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')   

                        


                                    <td>
                                        {!! Form::open(['route' => ['cabinet.waybills.destroy', $waybill->id], 'method' => 'delete']) !!}

                                        <a class="btn btn-success" href="{!! route('cabinet.waybills.show', ['id' => $waybill->id]) !!}" >смотреть</a>

                                        <a class="btn btn-warning" href="{!! route('cabinet.waybills.edit', [$waybill->id]) !!}">править</a>
                                        @if($waybill->deleted_at == '')
                                        {!! Form::button('Удалить', ['type' => 'submit', 'class' => 'btn btn-danger', 'name' => 'delete', 'value'=>'true', 'onclick' => "return confirm('Вы уверены?')"]) !!}
                                        @else
                                        {!! Form::button('Восстановить', ['type' => 'submit', 'class' => 'btn btn-danger', 'name' => 'restore', 'value' => 'true', 'onclick' => "return confirm('Вы уверены?')"]) !!}
                                        @endif

                                        {!! Form::close() !!}
                                    </td>
                                    @endif
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>


            </div>    
            <div class="box-footer clearfix">
                {!! $waybills->appends($searchInput)->render() !!}
            </div>

        </div>
    </div>


</section>

<div class="modal fade" id="courier-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h3 class="modal-title" id="myModalLabel">Назначение курьеров</h3>
            </div>
            <div id="courier-modal-body" class="modal-body">

            </div>
        </div>
    </div>
</div>
<!-- /.box -->
@endsection
