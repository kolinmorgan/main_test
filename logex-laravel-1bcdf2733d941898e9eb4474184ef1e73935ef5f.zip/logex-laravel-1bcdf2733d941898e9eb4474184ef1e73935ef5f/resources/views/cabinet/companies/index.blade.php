@extends('cabinet.layouts.app')

@section('content')



<section class="content">

    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Компании</h3>
                <div class="box-tools">
                      <a class="btn btn-success" href="{!! route('cabinet.companies.create') !!}">Создать</a>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">

                <div class="box-table-admin">
                    <table class="table table-hover" id="waybills-table">
                        <tbody>
                            <tr>
                                <th>Название</th>
                                <th>Адрес</th>
                                <th>Диапазон номеров накладных</th>
                                <th colspan="3">Действие</th>
                            </tr>



                            @foreach($companies as $company)
                            <tr>
                 
                                <td>{!! $company->name !!}</td>
                                <td>{{ $company->address }}</td>
                                <td>
                                @if($company->id_min != null)
                                {{$company->nulls}}{{$company->id_min}} -  {{$company->nulls}}{{$company->id_max}} осталось
                                @if($company->id_balance <= 10)
                                <b style="color:red;">{{$company->id_balance}}</b>
                                @else
                                  <b style="color: green;">{{$company->id_balance}}</b>
                                @endif
                                @else
                                не указаны автоматические id
                                @endif
                                </td>
                                <td>
                   
                              
                                    <a class="btn btn-warning" href="{!! route('cabinet.companies.edit', [$company->id]) !!}">править</a>
                                  
                          
                                </td>

                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>


            </div>    
            <div class="box-footer clearfix">
                {!! $companies->render() !!}
            </div>

        </div>
    </div>


</section>


<!-- /.box -->
@endsection
