@extends('cabinet.layouts.app')

@section('content')

<section class="content">
    <!-- Default box -->
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Создать компанию</h3>

            </div>
            <div class="box-body">

                @include('core-templates::common.errors')


                {!! Form::open(['route' => 'cabinet.companies.store']) !!}

                @include('cabinet.companies.fields')

                {!! Form::close() !!}

            </div>	
        </div> 
    </div> 
</section>
@endsection