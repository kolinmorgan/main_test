<div class="form-group col-sm-6">
    {!! Form::label('name', 'Название :') !!}
    {!! Form::text('name', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group col-sm-6">
    {!! Form::label('location_id',  'Город :') !!}
    {!! Form::select('location_id',  App\Models\Location::all('id','name')->lists('name','id'), null, ['class' => 'form-control']) !!}
</div>

<div class="form-group col-sm-12">
    {!! Form::label('address', 'Адрес :') !!}
    {!! Form::text('address', null, ['class' => 'form-control']) !!}
</div>
<div class="form-group col-sm-6">
    {!! Form::label('id_min', 'Начало диапазона номеров:') !!}
    {!! Form::text('id_min', null, ['class' => 'form-control']) !!}
</div>
<div class="form-group col-sm-6">
    {!! Form::label('id_max', 'Конец диапазона номеров:') !!}
    {!! Form::text('id_max', null, ['class' => 'form-control']) !!}
</div>
<div class="form-group col-sm-6">
    {!! Form::label('id_null_count', 'Число нулей в начале накладной:') !!}
    {!! Form::text('id_null_count', null, ['class' => 'form-control']) !!}
</div>


<div class="form-group col-sm-12">
    {!! Form::submit('Сохранить', ['class' => 'btn btn-success']) !!}
    <a href="{!! route('cabinet.companies.index') !!}" class="btn btn-danger">Отменить</a>
    
</div>
