@extends('cabinet.layouts.app')

@section('content')



<section class="content">

    <div class="col-xs-12">
        <div class="box">
            {!! Form::open(['action' => ['Cabinet\RateController@postApiRates'], 'method' => 'post']) !!}

            <div class="box-header with-border">
                <h3 class="box-title">API тарифы</h3>
            </div>
            <div class="box-body table-responsive no-padding">

                <div class="box-table-admin">
                    <table class="table table-hover" id="waybills-table">
                        <tbody>
                            <tr>
                                <th colspan="4">Экспресс доставка 1 посылки </th>
                                <th colspan="4">Стандарт доставка 1 посылки </th>
                            </tr>
                            <tr>
                                <th>Вес</th>
                                <th>Зона 0</th>
                                <th>Зона 1</th>
                                <th>Зона 2</th> 
                                <th>Вес</th>
                                <th>Зона 0</th>
                                <th>Зона 1</th>
                                <th>Зона 2</th> 
                            </tr>
                            <tr>
                                <td>5 кг</td>
                                <td><input name="rates[5][zone_0]" value="{{$rates[5]->zone_0}}"></td>
                                <td><input name="rates[5][zone_1]" value="{{$rates[5]->zone_1}}"></td>
                                <td><input name="rates[5][zone_2]" value="{{$rates[5]->zone_2}}"></td> 
                                <td>5 кг</td>
                                <td><input name="rates[7][zone_0]" value="{{$rates[7]->zone_0}}"></td>
                                <td><input name="rates[7][zone_1]" value="{{$rates[7]->zone_1}}"></td>
                                <td><input name="rates[7][zone_2]" value="{{$rates[7]->zone_2}}"></td> 
                            </tr>
                            <tr>
                                <td>посл 1кг</td>
                                <td><input name="rates[6][zone_0]" value="{{$rates[6]->zone_0}}"></td>
                                <td><input name="rates[6][zone_1]" value="{{$rates[6]->zone_1}}"></td>
                                <td><input name="rates[6][zone_2]" value="{{$rates[6]->zone_2}}"></td> 
                                <td>посл 1кг</td>
                                <td><input name="rates[8][zone_0]" value="{{$rates[8]->zone_0}}"></td>
                                <td><input name="rates[8][zone_1]" value="{{$rates[8]->zone_1}}"></td>
                                <td><input name="rates[8][zone_2]" value="{{$rates[8]->zone_2}}"></td> 
                            </tr>

                            <tr>
                                <th colspan="4">Консолидация до 5 магазинов экспресс</th>
                                <th colspan="4">Консолидация до 5 магазинов стандарт </th>
                            </tr>
                            <tr>
                                <th>Вес</th>
                                <th>Зона 0</th>
                                <th>Зона 1</th>
                                <th>Зона 2</th> 
                                <th>Вес</th>
                                <th>Зона 0</th>
                                <th>Зона 1</th>
                                <th>Зона 2</th> 
                            </tr>
                            <tr>
                                <td>5 кг</td>
                                <td><input name="rates[1][zone_0]" value="{{$rates[1]->zone_0}}"></td>
                                <td><input name="rates[1][zone_1]" value="{{$rates[1]->zone_1}}"></td>
                                <td><input name="rates[1][zone_2]" value="{{$rates[1]->zone_2}}"></td> 
                                <td>5 кг</td>
                                <td><input name="rates[3][zone_0]" value="{{$rates[3]->zone_0}}"></td>
                                <td><input name="rates[3][zone_1]" value="{{$rates[3]->zone_1}}"></td>
                                <td><input name="rates[3][zone_2]" value="{{$rates[3]->zone_2}}"></td> 
                            </tr>
                            <tr>
                                <td>посл 1кг</td>
                                <td><input name="rates[2][zone_0]" value="{{$rates[2]->zone_0}}"></td>
                                <td><input name="rates[2][zone_1]" value="{{$rates[2]->zone_1}}"></td>
                                <td><input name="rates[2][zone_2]" value="{{$rates[2]->zone_2}}"></td> 
                                <td>посл 1кг</td>
                                <td><input name="rates[4][zone_0]" value="{{$rates[4]->zone_0}}"></td>
                                <td><input name="rates[4][zone_1]" value="{{$rates[4]->zone_1}}"></td>
                                <td><input name="rates[4][zone_2]" value="{{$rates[4]->zone_2}}"></td> 
                            </tr>
                            <tr>
                                <td>посл 1 адрес</td>
                                <td><input name="rates[9][zone_0]" value="{{$rates[9]->zone_0}}"></td>
                                <td><input name="rates[9][zone_1]" value="{{$rates[9]->zone_1}}"></td>
                                <td><input name="rates[9][zone_2]" value="{{$rates[9]->zone_2}}"></td> 
                                <td>посл 1 адрес</td>
                                <td><input name="rates[10][zone_0]" value="{{$rates[10]->zone_0}}"></td>
                                <td><input name="rates[10][zone_1]" value="{{$rates[10]->zone_1}}"></td>
                                <td><input name="rates[10][zone_2]" value="{{$rates[10]->zone_2}}"></td> 
                            </tr>
                             <tr>
                                <td colspan="2">Размер комиссии, процентов:</td>
                                <td colspan="2"><input name="settings[commission]" value="{{App\Models\Setting::where('name', 'commission')->first()->value}}"></td>
                            </tr>
							<tr>
								<td colspan="2">Минимальная сумма товара, тнг:</td>
								<td colspan="2"><input name="settings[min_products_cost]" value="{{App\Models\Setting::where('name', 'min_products_cost')->first()->value}}"></td>
							</tr>
                        </tbody>
                    </table>
                </div>


            </div>    
            <div class="box-footer clearfix">
                <button class="btn btn-success" type="submit">Обновить</button>
            </div>
            {!! Form::close() !!}
        </div>
    </div>



    <div class="col-xs-12">
        <div class="box">
            {!! Form::open(['action' => ['Cabinet\RateController@postPage', 1], 'method' => 'post']) !!}

            <div class="box-header with-border">
                <h3 class="box-title">Курьерские услуги</h3>
            </div>
            <div class="box-body table-responsive no-padding">

                <div class="box-table-admin">
                    <textarea name="text" id="courier-service">
                        {!! $page->text !!}
                    </textarea>
                </div>


            </div>    
            <div class="box-footer clearfix">
                <button class="btn btn-success" type="submit">Обновить</button>
                <a href="/cabinet/rates/rollback" class="btn btn-danger">Откатить обратно</a
            </div>
            {!! Form::close() !!}
        </div>
    </div>

</section>
<script>
        CKEDITOR.replace('courier-service',{} );
            </script>

<!-- /.box -->
@endsection
