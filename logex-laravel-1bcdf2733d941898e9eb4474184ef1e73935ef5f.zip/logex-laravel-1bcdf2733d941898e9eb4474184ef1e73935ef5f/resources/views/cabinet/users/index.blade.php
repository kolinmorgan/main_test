@extends('cabinet.layouts.app')

@section('content')

<section class="content">
    @include('flash::message')
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Пользователи</h3>

            </div>
            <div class="box-body table-responsive no-padding">

                <div class="box-table-admin">
                    <table class="table table-hover" id="waybills-table">
                        <tbody>
                            @foreach($users as $user)
                            <tr>
                                <td>{!! $user->name !!}</td>
                                <td>{{ $user->email }}</td>
                                <td>
                                    <form method="POST" action="/cabinet/users/update" class="form-inline">
                                        {{ csrf_field() }}
                                        <input type="hidden" value="{{$user->id}}" name="user_id">
           
                                         {!! Form::select('role', ['admin' => 'Администратор', 'manager' => 'Оператор', 'courier' => 'Курьер', 'user' => 'Клиент', 'ban' => 'Удален'], $user->role, ['class' => 'form-control selectpicker','data-container' => 'body', 'data-live-search' => 'true', 'data-width' => '200px']) !!}
                                         {!! Form::select('location_id', App\Models\Location::all('id', 'name')->lists('name', 'id'), $user->location_id, ['class' => 'form-control selectpicker','data-container' => 'body', 'data-live-search' => 'true', 'data-width' => '200px']) !!}
                                          
                                         {!! Form::select('company_id[]', App\Models\Company::all('id', 'name')->lists('name', 'id'), $user->company->lists('id')->all(), ['class' => 'form-control selectpicker','data-container' => 'body', 'multiple' => 'multiple', 'data-live-search' => 'true', 'data-width' => '200px']) !!}
                                          <button type="submit" class="btn btn-success">Обновить</button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>


            </div>    
            <div class="box-footer clearfix">
                {!! $users->render() !!}
            </div>

        </div>
    </div>


</section>


<!-- /.box -->
@endsection
