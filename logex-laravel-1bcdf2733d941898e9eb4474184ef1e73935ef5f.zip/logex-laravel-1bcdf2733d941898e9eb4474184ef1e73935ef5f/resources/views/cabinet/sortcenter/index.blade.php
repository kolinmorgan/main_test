@extends('cabinet.layouts.app')

@section('content')
<script>
 document.addEventListener('keydown', function(event) {
    if( event.keyCode == 17 || event.keyCode == 74 )
      event.preventDefault();
  });</script>
<section class="content">


  @include('vendor.flash.message')

    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Курьерские доставки</h3>


            </div>
            <div class="box-body table-responsive">
                <div class="row">
                    
                <div class="col-xs-3">
                <form method="POST">
                    {{csrf_field()}}
                    <div class="col-xs-12">
                            <select name="courier_id" class="selectpicker form-control"  data-live-search="true" data-width="100%" data-container="body">
                            @foreach($couriers as $courier)
                            <option value="{{$courier->id}}">{{$courier->name}}</option>
                            @endforeach
                        </select>
                    </div>
                    <div style="padding-bottom: 15px;" class="col-xs-6">
                        <button type="submit" name="type" value="sort"  class="btn btn-success">Принять</button>
                    </div>
                    <div class="col-xs-6">
                        <button type="submit" name="type" value="courier" class="btn btn-success">Отправить</button>
                    </div>
                    <div class="col-xs-12">
                        <textarea id="scanner_waybill" name="waybills" rows="20" style="width: 100%"></textarea>
                    </div>
        
                </form>
                </div>
                    <div class="col-xs-9">
                                    <div class="box-table-admin">
                    <div class="double-scroll">
                        <table class="table table-hover" id="waybills-table">
                            <tbody>
                                <tr>
                                    <th></th>
                                    <th>Номер накладной</th>
                                    <th>Номер darbazar</th>
                                    <th>Статус</th>
                                    <th>Действия</th>
                                </tr>


                                @foreach($routes as $route)
                                @if(isset($route->waybill))
                                @if(in_array($route->waybill->status, ['Новая','В доставке', 'Принят']) && ((time() - strtotime($route->waybill->send_date)) > 432000)) <tr class="warning"> @else <tr> @endif
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')  
                     
                                    <td> <button type="button"  class="btn btn-success" onclick="getCourierModal({{$route->waybill->id}});">Курьерская схема</button></td>
                                    <td>{!! $route->waybill->code !!}</td>
                                    <td>{!! $route->waybill->darbazar_id !!}</td>

                                    <td>
                                        
                                        {!! Form::model($route->waybill, ['route' => ['cabinet.waybills.update', $route->waybill->id], 'method' => 'patch']) !!}
                                        {!! Form::select('status', ['Новая' => 'Новая', 'В обработке' => 'В обработке', 'В доставке' => 'В доставке', 'Забор осуществлён' => 'Забор осуществлён', 'Доставлено' => 'Доставлено', 'Не доставлено' => 'Не доставлено', 'Возврат' => 'Возврат', 'Частичный возврат' => 'Частичный возврат','Возврат в сортировочный центр'=>'Возврат в сортировочный центр'], $route->waybill->status, ['class' => 'form-control, selectpicker',  'data-container' => 'body',  'data-width' => '150px']) !!}
                                        <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-saved" aria-hidden="true"></span></button>

                                        {!! Form::close() !!}
                                       
                                    </td>
                                   
                                    <td>
                                   

                                        <a class="btn btn-success" href="{!! route('cabinet.waybills.show', ['code' => $route->waybill->code]) !!}" >смотреть</a>

                                        <a class="btn btn-warning" href="{!! route('cabinet.waybills.edit', [$route->waybill->id]) !!}">править</a>
                    

                                  
                                    </td>
                                    @endif
                                </tr>
                                @endif
                                @endforeach
                            </tbody>
                        </table>
                        {!! $routes->render() !!}
                    </div>
                </div>


            </div>    
     
                </div>


            </div>    
            <div class="box-footer clearfix">

            </div>

        </div>
    </div>


</section>

<div class="modal fade" id="courier-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h3 class="modal-title" id="myModalLabel">Назначение курьеров</h3>
            </div>
            <div id="courier-modal-body" class="modal-body">

            </div>
        </div>
    </div>
</div>

@endsection
