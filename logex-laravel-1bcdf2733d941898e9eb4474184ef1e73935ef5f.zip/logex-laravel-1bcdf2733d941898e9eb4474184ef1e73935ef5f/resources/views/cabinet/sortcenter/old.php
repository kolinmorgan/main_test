@extends('cabinet.layouts.app')

@section('content')



<section class="content">




    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Курьерские доставки</h3>

                <div class="box-tools">

                    <a class="btn btn-success">Массовое назначение</a>    

                </div>
            </div>
            <div class="box-body table-responsive no-padding">

                <div class="box-table-admin">
                    <div class="double-scroll">
                        <table class="table table-hover" id="waybills-table">
                            <tbody>
                                <tr>
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')  
                                    <th>Управление курьерами</th>
                                    @endif
                                    <th>Пользователь</th>
                                    <th>Менеджер отправитель</th>
                                    <th>Дата приема</th>
                                    <th>Номер Накладной</th>
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')      
                                    <th>Номер отправления</th>
                                    <th>Номер накладной (Компании)</th>
                                    @endif        
                                    <th>Отправитель (Компания)</th>
                                    <th>Получатель (Компания)</th>
                                    <th>Город отправителя</th>
                                    <th>Город получателя</th>
                                    <th>Кол-во мест</th>
                                    <th>Вес</th>
                                    <th>Вид отправления</th>
                                    <th>Важность</th>
                                    <th>Прочие отметки</th>
                                    <th>Цена</th>

                                    <th>Дата доставки</th>
                                    <th>Время доставки</th>
                                    <th>ФИО Получателя</th>
                                    <th>Должность получателя</th>

                                </tr>

                                <tr>
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')  

                                     <th>Courier control</th>
                                    @endif
                                    <th>User name</th>
                                    <th>Manager</th>
                                    <th>Pick up date</th>
                                    <th>Airway bill number</th>
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')  
                                    <th>Shipment number</th>
                                    <th>Airway bill number of sender (Company)</th>
                                    @endif        
                                    <th>Sender (Company)</th>
                                    <th>Receiver (Company)</th>
                                    <th>Origin city</th>
                                    <th>Destination city</th>
                                    <th>Quantity of place</th>
                                    <th>Weight</th>
                                    <th>Type of shipment</th>
                                    <th>Importance</th>
                                    <th>Addition</th>
                                    <th>Price</th>

                                    <th>Delivery date</th>
                                    <th>Delivery time</th>
                                    <th>Receiver's name</th>
                                    <th>Position of receiver</th>
        
                                </tr>

                                
                                @foreach($routes as $waybill)
                                <?php $waybill = $waybill->waybill; ?>
                                @if(in_array($waybill->status, ['Новая','В доставке', 'Принят']) && ((time() - strtotime($waybill->send_date)) > 432000)) <tr class="warning"> @else <tr> @endif
                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')  
  
                                                <td>
                                                    <input type="checkbox">
                                        <button type="button"   class="btn btn-success" onclick="getCourierModal({{$waybill->id}});">Курьерская схема</button>
                                    </td>
                                    @endif
                                    <td>{!! $waybill->user->name !!}</td>
                                    <td>{!! $waybill->manager !!}</td>
                                    <td>{!! $waybill->send_date !!}</td>
                                    <td>{!! $waybill->code !!}</td>

                                    @if (Auth::user()->role == 'admin' || Auth::user()->role == 'manager')         
                                    <td>{!! $waybill->package_id !!}</td>
                                    <td>{!! $waybill->company_cod !!}</td>
                                    @endif   
                                    <td>{!! $waybill->company_sender->name !!}</td>
                                    <td>{!! $waybill->company_recipient_name !!}</td>
                                    <td>{!! $waybill->sender_city !!}</td>
                                    <td>{!! $waybill->recipient_city !!}</td>
                                    <td>{!! $waybill->places !!}</td>
                                    <td>{!! $waybill->weight !!}</td>
                                    <td>{!! $waybill->kind !!}</td>
                                    <td>{!! $waybill->priority !!}</td>
                                    <td>{!! $waybill->description !!}</td>
                                    <td>{!! $waybill->cost !!}</td>

                                    <td>{!! $waybill->delivery_date !!}</td>
                                    <td>{!! $waybill->delivery_time !!}</td>
                                    <td>{!! $waybill->recipient !!}</td>
                                    <td>{!! $waybill->recipient_position !!}</td>

                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>


            </div>    
            <div class="box-footer clearfix">
                {!! $routes->render() !!}
            </div>

        </div>
    </div>


</section>

<div class="modal fade" id="courier-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h3 class="modal-title" id="myModalLabel">Назначение курьеров</h3>
            </div>
            <div id="courier-modal-body" class="modal-body">

            </div>
        </div>
    </div>
</div>
<!-- /.box -->
@endsection
