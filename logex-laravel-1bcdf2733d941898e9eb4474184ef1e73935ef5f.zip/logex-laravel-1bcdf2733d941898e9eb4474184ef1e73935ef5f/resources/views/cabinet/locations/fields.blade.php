<div class="form-group col-sm-6">
    {!! Form::label('name', 'Название :') !!}
    {!! Form::text('name', null, ['class' => 'form-control']) !!}
</div>


<div class="form-group col-sm-12">
    {!! Form::submit('Сохранить', ['class' => 'btn btn-success']) !!}
    <a href="{!! route('cabinet.locations.index') !!}" class="btn btn-danger">Отменить</a>
    
</div>
