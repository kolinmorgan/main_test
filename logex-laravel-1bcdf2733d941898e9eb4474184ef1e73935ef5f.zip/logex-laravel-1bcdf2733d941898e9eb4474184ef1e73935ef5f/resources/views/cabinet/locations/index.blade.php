@extends('cabinet.layouts.app')

@section('content')



<section class="content">

    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Локации</h3>
                <div class="box-tools">
                      <a class="btn btn-success" href="{!! route('cabinet.locations.create') !!}">Создать</a>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">

                <div class="box-table-admin">
                    <table class="table table-hover" id="waybills-table">
                        <tbody>
                            <tr>
                                <th>Название</th>
                                <th colspan="3">Действие</th>
                            </tr>



                            @foreach($locations as $location)
                            <tr>
                                <td>{!! $location->name !!}</td>

                                <td>
                   
                                    {!! Form::open(['route' => ['cabinet.locations.destroy', $location->id], 'method' => 'delete']) !!}

                                 
                                   
                                    <a class="btn btn-warning" href="{!! route('cabinet.locations.edit', [$location->id]) !!}">править</a>
                                    {!! Form::button('Удалить', ['type' => 'submit', 'class' => 'btn btn-danger', 'onclick' => "return confirm('Вы уверены?')"]) !!}
                           

                                    {!! Form::close() !!}
                              
                               
                                  
                          
                                </td>

                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>


            </div>    
            <div class="box-footer clearfix">
                {!! $locations->render() !!}
            </div>

        </div>
    </div>


</section>


<!-- /.box -->
@endsection
