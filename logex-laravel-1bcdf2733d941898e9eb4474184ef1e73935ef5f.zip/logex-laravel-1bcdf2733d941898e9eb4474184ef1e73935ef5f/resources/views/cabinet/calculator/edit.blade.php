@extends('cabinet.layouts.app')

@section('content')

<section class="content">
    <!-- Default box -->
    <div class="col-xs-12">
        <div class="box">


                @include('core-templates::common.errors')


                {!! Form::open(['action' => ['Cabinet\CalculatorController@postEdit', 'id' => $rate->id], 'method' => 'post', 'id' => 'create-calc']) !!}


                
                <div class="box-header with-border">
                    <h3 class="box-title">Редактирование: {{$rate->name}}</h3>
                </div>
                <div class="box-body  no-padding">

                    <div class="box-table-admin">
                        <table class="table table-hover">
                            <tbody>
                                <tr>
                                    <th colspan="6"><input name="name" value="{{$rate->name}}" class="form-control" placeholder="Название"></th>
                                </tr>
                                <tr>
                                    <th colspan="6">Экспресс</th>      
                                </tr>
                                <tr>
                                    <th colspan="6">
                                        <textarea  placeholder="Вставка с excel" class="form-control paste_from_excel_express"></textarea>
                                    </th>
                                </tr>
                                <tr>
                                    <th>Вес</th>
                                    <th>Зона 0</th>
                                    <th>Зона 1</th>
                                    <th>Зона 2</th> 
                                    <th>Зона 3</th> 
                                    <th>Зона 4</th> 
                                </tr>
                                @foreach(['0,3','0,5','1','1,5','2','2,5','3','3,5','4','4,5','5','+0,5'] as $weight)
                                <tr>
                                    <td>{{$weight}} кг</td>
                                    @for($i=0; $i<=4; $i++)
                                    <td><input class="form-control inp-express" value="{{ $rate->rates['express'][$weight]['zone_'.$i] }}" name="rates[express][{{$weight}}][zone_{{$i}}]" ></td>
                                    @endfor
                                </tr>
                                @endforeach
                                <tr>
                                    <th colspan="6">Стандарт</th>
                                </tr>
                                <tr>
                                    <th colspan="6">
                                        <textarea  placeholder="Вставка с excel" class="form-control paste_from_excel_standart"></textarea>
                                    </th>
                                </tr>
                                <tr>
                                    <th>Вес</th>
                                    <th>Зона 1</th>
                                    <th>Зона 2</th> 
                                    <th>Зона 3</th> 
                                    <th>Зона 4</th> 
                                </tr>
                               @foreach(['0,5','1','1,5','2','2,5','3','3,5','4','4,5','5-10','+0,5'] as $weight)
                                <tr>
                                    <td>{{$weight}} кг</td>
                                    @for($i=1; $i<=4; $i++)
                                    <td><input class="form-control inp-standart" value="{{ $rate->rates['standart'][$weight]['zone_'.$i] }}" na name="rates[standart][{{$weight}}][zone_{{$i}}]" ></td>
                                    @endfor
                                </tr>
                                @endforeach
        
                            </tbody>
                        </table>
                    </div>


                </div>    
                <div class="box-footer clearfix">
                    <button class="btn btn-success" type="submit">Обновить</button>
                </div>


                {!! Form::close() !!}


    </div> 
</section>

@endsection

