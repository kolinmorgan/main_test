@extends('cabinet.layouts.app')

@section('content')

<section class="content">
   
       <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Добавить новую</h3>
            </div>
            <div class="box-body">

                <form class="form-inline" action="/cabinet/calculator/zones" method="POST">
                {{ csrf_field() }}
                        <div class="form-group">
                            <label>От</label>
                            {!! Form::select('from_id',  $cities->lists('name','id'), null, ['class' => 'form-control selectpicker','data-live-search' => 'true','data-container' => 'body', 'data-width' => '200px']) !!}

                        </div>	
                        <div class="form-group">
                            <label>До</label> 
                             {!! Form::select('to_id',  $cities->lists('name','id'), null, ['class' => 'form-control selectpicker','data-live-search' => 'true','data-container' => 'body', 'data-width' => '200px']) !!}
                        </div>
                        <div class="form-group">
                            <label>Зона</label> 
                           {!! Form::select('zone',  [0,1,2,3,4], null, ['class' => 'form-control selectpicker','data-container' => 'body', 'data-width' => '50px']) !!}
                        </div>
              
                  
   
                        <button class="btn btn-default" type="submit">Создать</button>
                  
             
                </form>
            </div>   
        </div>
    </div>
    <div class="col-xs-12">
        <div class="box">


        
            <div class="box-body  no-padding">

                <div class="box-table-admin">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>От</th>
                                <th>До</th>
                                <th>Номер зоны</th>     
                            </tr>
                            @foreach($zones as $zone)
                            <tr>
                                <td>{{$zone->city_from->name}}</td>
                                <td>{{$zone->city_to->name}}</td>
                                <td>{{$zone->zone}}</td>
                            </tr>
                            @endforeach
      

                        </tbody>
                    </table>
                </div>


            </div>    



 


        </div> 
</section>

@endsection

