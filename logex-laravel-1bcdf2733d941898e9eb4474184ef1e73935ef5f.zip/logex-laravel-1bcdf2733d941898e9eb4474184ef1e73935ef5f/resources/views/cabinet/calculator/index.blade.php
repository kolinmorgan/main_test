@extends('cabinet.layouts.app')

@section('content')

<section class="content">
    <!-- Default box -->
    <div class="col-xs-12">
        <div class="box">


            @include('core-templates::common.errors')



            <div class="box-header with-border">
                <h3 class="box-title">Тарифы</h3>
                <a class="btn btn-success" href="/cabinet/calculator/create">Создать</a>
                <a class="btn btn-success" href="/cabinet/calculator/zones">Управление зонами</a>
            </div>
            <div class="box-body  no-padding">

                <div class="box-table-admin">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Название</th>
                                <th>Тарифы</th>
                                <th>Компании</th>
                                <th></th>
                                
                            </tr>
                            @foreach($rates as $rate)
                            <tr>
                                <td>{{$rate->name}}</td>
                                <td style="width: 400px;">
                                    <table class="table">
                                        <tbody>

                                            <tr>
                                                <th colspan="6">Экспресс</th>      
                                            </tr>
                                            <tr>
                                                <th>Вес</th>
                                                <th>Зона 0</th>
                                                <th>Зона 1</th>
                                                <th>Зона 2</th> 
                                                <th>Зона 3</th> 
                                                <th>Зона 4</th> 
                                            </tr>
                                            @foreach(['0,3','0,5','1','1,5','2','2,5','3','3,5','4','4,5','5','+0,5'] as $weight)
                                            <tr>
                                                <td>{{$weight}} кг</td>
                                                @for($i=0; $i<=4; $i++)
                                                <td>{{ $rate->rates['express'][$weight]['zone_'.$i] }}</td>
                                                @endfor
                                            </tr>
                                            @endforeach
                                            <tr>
                                                <th colspan="6">Стандарт</th>
                                            </tr>
                                            <tr>
                                                <th>Вес</th>
                                                <th>Зона 1</th>
                                                <th>Зона 2</th> 
                                                <th>Зона 3</th> 
                                                <th>Зона 4</th> 
                                            </tr>
                                            @foreach(['0,5','1','1,5','2','2,5','3','3,5','4','4,5','5-10','+0,5'] as $weight)
                                            <tr>
                                                <td>{{$weight}} кг</td>
                                                @for($i=1; $i<=4; $i++)
                                                <td>{{ $rate->rates['standart'][$weight]['zone_'.$i] }}</td>
                                                @endfor
                                            </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </td>
                                <td>
                                    {!! Form::open(['action' => ['Cabinet\CalculatorController@postCompanies'], 'method' => 'post', 'id' => 'create-calc']) !!}
                                    <input type="hidden" name="rate_id" value="{{$rate->id}}">
                                        {!! Form::select('company_id[]', App\Models\Company::all('id', 'name')->lists('name', 'id'), $rate->companies->lists('id')->all(), ['class' => 'form-control selectpicker','data-container' => 'body', 'multiple' => 'multiple', 'data-live-search' => 'true', 'data-width' => '250px']) !!}
                                 
                                        <button type="submit" class="btn btn-success">Обновить</button>
                                       {!! Form::close() !!}
                                </td>
                                <td>
                                    <a href="/cabinet/calculator/edit/{{$rate->id}}" class="btn btn-warning">Редактировать</a>
                                    
                                </td>
                            </tr>
                            @endforeach

                        </tbody>
                    </table>
                </div>


            </div>    
            <div class="box-footer clearfix">
                <button class="btn btn-success" type="submit">Обновить</button>
            </div>


 


        </div> 
</section>

@endsection

