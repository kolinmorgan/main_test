<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Logex v2</title>

        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">


        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <!-- Theme style -->
        <script src="https://www.google.com/cloudprint/client/cpgadget.js"></script>
        <link rel="stylesheet" href="/cabinet/css/AdminLTE.css">
        <!-- AdminLTE Skins. Choose a skin from the css/skins
             folder instead of downloading all of them to reduce the load. -->

        <link href="/cabinet/css/skins/skin-red.css" rel="stylesheet" type="text/css"/>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->



        <script src="/js/jquery-1.12.0.min.js"></script>
        <!-- Bootstrap 3.3.6 -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <script src="/cabinet/js/app.js"></script>
        <!-- AdminLTE for demo purposes -->
        <script src="/cabinet/js/demo.js"></script>

        <link href="/css/datepicker.min.css" rel="stylesheet">
        <script src="/js/datepicker.min.js"></script>
 
        <script src="/js/jquery.scannerdetection.js" type="text/javascript"></script>
        <script src="/js/logex.js" type="text/javascript"></script>
      
      
       

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/css/bootstrap-select.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/bootstrap-select.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/i18n/defaults-ru_Ru.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ajax-bootstrap-select/1.3.7/css/ajax-bootstrap-select.css">
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/ajax-bootstrap-select/1.3.7/js/ajax-bootstrap-select.min.js"></script>


         <script src="//cdn.ckeditor.com/4.5.9/full/ckeditor.js"></script>

    </head>
    <body class="hold-transition skin-red sidebar-mini sidebar-collapse">

        <div class="wrapper">

            <header class="main-header">
                <!-- Logo -->
                <a href="/cabinet/waybills" class="logo">
                    <!-- mini logo for sidebar mini 50x50 pixels -->
                    <span class="logo-mini"><b>L</b>X</span>
                    <!-- logo for regular state and mobile devices -->
                    <span class="logo-lg"><b>Logex</b></span>
                </a>

                <nav class="navbar navbar-static-top">
                    <!-- Sidebar toggle button-->
                    <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                        <span>Меню</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>

                </nav>
            </header>

            <!-- =============================================== -->

            <!-- Left side column. contains the sidebar -->
            <aside class="main-sidebar">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel">
                        <div class="pull-left info">
                            <p>{{Auth::user()->name}}</p>
                        </div>
                    </div>

                    <ul class="sidebar-menu">

                        <li>
                            <a href="/cabinet/report">
                                <i class="fa fa-flag"></i> <span>Сводка</span>
                            </a>
                        </li>
                        <li>
                            <a href="{!! route('cabinet.waybills.index') !!}">
                                <i class="fa  fa-file-text-o"></i> <span>Накладные</span>
                            </a>
                        </li>
                        <li>
                            <a href="/cabinet/users">
                                <i class="fa fa-user"></i> <span>Пользователи</span>
                            </a>
                        </li>
                        <li>
                            <a href="/cabinet/couriers">
                                <i class="fa fa-car"></i> <span>Курьеры</span>
                            </a>
                        </li>
                        <li>
                            <a href="/cabinet/companies">
                                <i class="fa fa-building"></i> <span>Справочник компаний</span>
                            </a>
                        </li>
                        <li>
                            <a href="/cabinet/locations">
                                <i class="fa fa-globe"></i> <span>Локации</span>
                            </a>
                        </li>
                        <li>
                            <a href="/cabinet/sortcenters">
                                <i class="fa fa-sort"></i> <span>Сортировочные центры</span>
                            </a>
                        </li>
                        <li>
                            <a href="/cabinet/rates">
                                <i class="fa fa-usd"></i> <span>Тарифы</span>
                            </a>
                        </li>
                        <li>
                            <a href="/cabinet/calculator">
                                <i class="fa fa-calculator"></i> <span>Калькулятор</span>
                            </a>
                        </li>
     


                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>

            <!-- =============================================== -->

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->

                @yield('content')


                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->

            <footer class="main-footer">
                <div class="pull-right hidden-xs">
                    <b>Version</b> 0.1
                </div>
                <strong>Logex</strong> 
            </footer>


        </div>
        <!-- ./wrapper -->
    </body>
</html>
