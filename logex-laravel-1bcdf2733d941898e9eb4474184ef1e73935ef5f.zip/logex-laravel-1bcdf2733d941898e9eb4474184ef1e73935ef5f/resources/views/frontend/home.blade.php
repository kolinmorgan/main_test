@extends('frontend.layouts.app')

@section('content')
    <main>
        <div class="service clearfix">
            <div class="body-wrapper clearfix">
                <div class="service-number1">
                    <div class="service-content service-bg1">
                        <div class="service-title">Транспортные<br> услуги</div>
                        Международные и междугородние доставки
                        в самые короткие сроки
                        <a href="/transportation-services">Подробнее</a>
                    </div>
                </div>
                <div class="service-number2">
                    <div class="service-content service-bg2">
                        <div class="service-title">Курьерские<br> услуги</div>
                        Экспресс-доставка, обслуживание<br> интернет-магазинов
                        <a href="/courier-service">Подробнее</a>
                    </div>
                </div>
                <div class="service-number3">
                    <div class="service-content service-bg3">
                        <div class="service-title">Дополнительные<br> услуги</div>
                        Перенаправление, растаможка, прочие услуги
                        <a href="/additional-services">Подробнее</a>
                    </div>
                </div>
                <div class="service-number4">
                    <div class="service-content service-bg4">
                        <div class="service-title">Складские<br> услуги</div>
                        Склады в Алматы и Астане общей площадью более 2000 кв.м.
                        <a href="/warehousing-services">Подробнее</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="our-clients">
            <div class="body-wrapper clearfix">
                <p>Наши клиенты</p>
            </div>
			<div class="body-wrapper page-client clearfix">
				<div class="brand-item"><img src="/img/clients/clients-1.png" alt=""></div>
				<div class="brand-item"><img src="/img/clients/clients-2.png" alt=""></div>
				<div class="brand-item"><img src="/img/clients/clients-3.png" alt=""></div>
				<div class="brand-item"><img src="/img/clients/clients-4.png" alt=""></div>
				<div class="brand-item"><img src="/img/clients/clients-5.png" alt=""></div>
				<div class="brand-item"><img src="/img/clients/clients-6.png" alt=""></div>
				<div class="brand-item"><img src="/img/clients/clients-7.png" alt=""></div>
				<div class="brand-item"><img src="/img/clients/clients-8.png" alt=""></div>
				<div class="brand-item"><img src="/img/clients/clients-9.png" alt=""></div>
			<div class="brand-item"><img src="/img/clients/clients-10.png" alt=""></div> 			
            <div class="brand-item" style="text-align: center;">
                <img src="/img/clients/clients-14.png" alt="">
				<p style="border-left: none;color: black;font-size: 15px;text-transform: uppercase;margin:0;">Доствка биоматериалов за 24 часа по всему КЗ</p>
			</div>			                       
            <div class="brand-item"><img src="/img/clients/clients-11.png" alt=""></div>
            <div class="brand-item"><img src="/img/clients/clients-13.png" alt=""></div>
            <div class="brand-item"><img src="/img/clients/clients-15.png" alt="">
				<p style="border-left: none;color: black;font-size: 15px;text-transform: uppercase;margin:0;">АО "Торгово-промышленный Банк Китая в Алматы"</p>
			</div>			
			<div class="brand-item"><img src="/img/clients/clients-12.png" alt=""></div>		
			</div>			
        </div>		
    </main>
@endsection
