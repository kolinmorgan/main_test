@extends('frontend.layouts.app')

@section('content')
    <main>
    <div class="page-title">
        <div class="body-wrapper clearfix head-line">
            <p>Наши клиенты</p>
        </div>
    </div>
    <div class="our-clients-content">
        <div class="body-wrapper page-client clearfix">
            <div class="brand-item"><img src="/img/clients/clients-1.png" alt=""></div>
            <div class="brand-item"><img src="/img/clients/clients-2.png" alt=""></div>
            <div class="brand-item"><img src="/img/clients/clients-3.png" alt=""></div>
            <div class="brand-item"><img src="/img/clients/clients-4.png" alt=""></div>
            <div class="brand-item"><img src="/img/clients/clients-5.png" alt=""></div>
            <div class="brand-item"><img src="/img/clients/clients-6.png" alt=""></div>
            <div class="brand-item"><img src="/img/clients/clients-7.png" alt=""></div>
            <div class="brand-item"><img src="/img/clients/clients-8.png" alt=""></div>
            <div class="brand-item"><img src="/img/clients/clients-9.png" alt=""></div>
			<div class="brand-item"><img src="/img/clients/clients-10.png" alt=""></div> 			
            <div class="brand-item" style="text-align: center;">
                <img src="/img/clients/clients-14.png" alt="">
				<p style="border-left: none;color: black;font-size: 15px;text-transform: uppercase;margin:0;">Доствка биоматериалов за 24 часа по всему КЗ</p>
			</div>			                       
            <div class="brand-item"><img src="/img/clients/clients-11.png" alt=""></div>
            <div class="brand-item"><img src="/img/clients/clients-13.png" alt=""></div>
            <div class="brand-item"><img src="/img/clients/clients-15.png" alt="">
				<p style="border-left: none;color: black;font-size: 15px;text-transform: uppercase;margin:0;">АО "Торгово-промышленный Банк Китая в Алматы"</p>
			</div>				
			<div class="brand-item"><img src="/img/clients/clients-12.png" alt=""></div>			
        </div>
    </div>
</main>
@endsection
