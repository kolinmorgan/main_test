<footer>
    <div class="body-wrapper clearfix bg-footer">
        <div class="footer-write-to-us">
            <div class="footer-title">Напишите нам</div>
            <p>По общим вопросам:
                <span class="text-underline">info@logex.kz</span><br>
                По вопросам поддержки:
                <span class="text-underline">support@logex.kz</span></p>
        </div>

        <div class="footer-info">
            <div class="footer-title">Полезная информация</div>
            <a href="/about-us">О компании<br></a>
            <a href="/clients">Наши клиенты и партнеры<br></a>
            <a href="#">Правила упаковки<br></a>
            <a href="#">Частые вопросы</a>
        </div>

        <div class="footer-contacts">
            <div class="footer-title">Наши контакты</div>
            <p>Телефоны:<br> 
                    +7 (727) 3 777 000<br>
                    8 777 007 60 60<br>
                    8 777 007 13 77<br>
            </p>
        </div>
        <div style="clear:both; height:50px;"></div>
        <div class="copyright">© 2016 Logex. Все права защищены.</div>
    </div>

</footer>

