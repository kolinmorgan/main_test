<!DOCTYPE html>
<html lang="ru-RU">
<head>
    <meta charset="UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link href="/img/favicon.ico" rel="icon" type="image/x-icon">
    <title>Welcome to Logex</title>
    <meta name="description" content="">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu:400,500,300,700&amp;subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="/css/normalize.css" rel="stylesheet">
	<link href="/css/bootstrap.css" rel="stylesheet">
    <link href="/css/main.css" rel="stylesheet">

</head>
<body cz-shortcut-listen="true">
<div class="wrap">
    <header>
        @include('frontend.layouts.header')
    </header>
    @if(Request::is('/'))
        @include('frontend.layouts.slider')
    @endif
</div>
<div class="container">
    @yield('content')
</div>

</div>

@include('frontend.layouts.footer')


			<!-- Modal-login  -->
			<div class="modal fade" id="Modal-login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h3 class="modal-title" id="myModalLabel">Вход в личный кабинет</h3>
						</div>
						<div class="modal-body">
							@include('auth.modal')
						</div>
					</div>
				</div>
			</div>	
			<!-- END Modal-login-->	
			<!-- Modal-orderCall  -->
			<div class="modal fade" id="Modal-orderCall" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" >
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h3 class="modal-title" id="myModalLabel">Заказать обратный звонок</h3>
						</div>
						<div class="modal-body">
							@foreach ($errors->CallBack->all() as $error)
								<div class="col-md-6">                  
									<span class="help-block"><strong>{{ $error }}</strong></span>
								</div>
							@endforeach
							{!! Form::open(['route' => 'callback']) !!}
							@include('auth.modalOrderCall')
							{!! Form::close() !!}
						</div>
					</div>
				</div>
			</div>	
			<!-- END Modal-orderCall-->	

<script src="/js/jquery-1.12.0.min.js"></script>
{{--<script src="/assets/fed81716/yii.js?v=1461855020"></script>--}}
{{--<script src="/assets/fed81716/yii.validation.js?v=1461855020"></script>--}}
{{--<script src="/assets/fed81716/yii.activeForm.js?v=1461855020"></script>--}}
{{--<script src="/js/app.js"></script>--}}

<link href="/css/datepicker.min.css" rel="stylesheet">
<script src="/js/datepicker.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/jquery.slides.min.js"></script>
<script src="/js/jquery.inputmask.bundle.min.js"></script>
<script src="/js/owl.carousel-min.js"></script>
<script type="text/javascript">
    $(document).ready(
        function () {
      /*  $("#partners").owlCarousel({
            navigation: true,
            autoPlay: false,
            items: 3
        });
        */
        $('#delivery_time').inputmask("h:s");
     //   $('#code').inputmask("999999999999");
    });
    $(document).ready(function() {

        // запускаем скрипт после загрузки всех элементов
        /* засунем сразу все элементы в переменные, чтобы скрипту не приходилось их каждый раз искать при кликах */
        var overlay = $('.overlay'); // подложка, должна быть одна на странице
        var open_modal = $('.open_modal'); // все ссылки, которые будут открывать окна
        var close = $('.modal_close, .overlay'); // все, что закрывает модальное окно, т.е. крестик и оверлэй-подложка
        var modal = $('.modal_div'); // все скрытые модальные окна

        open_modal.click( function(event){ // ловим клик по ссылке с классом open_modal
            event.preventDefault(); // вырубаем стандартное поведение
            var div = $(this).attr('href'); // возьмем строку с селектором у кликнутой ссылки
            overlay.fadeIn(200, //показываем оверлэй
                    function(){ // после окончания показывания оверлэя
                        $(div) // берем строку с селектором и делаем из нее jquery объект
                                .css('display', 'block')
                                .fadeIn(100); // плавно показываем

                    });
        });

        $(document).on('click', '.modal_close', function(){ // ловим клик по крестику или оверлэю
            modal // все модальные окна
                    .fadeOut(100, // плавно прячем
                    function(){ // после этого
                        $(this).css('display', 'none');
                        overlay.fadeOut(200); // прячем подложку

                    }
            );

            return false;  // чтобы не кидало в самый вверх при клике
        });

        // Центрируем окошко

        $(window).resize(function(){
            $('.modal_div').css({
                position:'fixed',
                left: (jQuery (window).width()
                - jQuery ('.modal_div').outerWidth())/2, //ширина делить окно на 2
                top: (jQuery (window).height()
                - jQuery ('.modal_div').outerHeight())/2 // высота делит коно на два
            }); // Если нужно только одно удали ненужную строку

        });
        // вызов чтобы окно стало по центру в зависимости от разрешения
        $(window).resize();

        @if($errors->hasBag('CallBack'))
                  overlay.fadeIn(200);
            $('.modal_div').show();
        @endif
// autorize
        $('#autorize').click(function(){
            $(this).parent().children('.autorize-panel').slideToggle('fast');
            return false;
        });
    });
    $(function() {
        $('#slides').slidesjs({
                    width: 1600,
                    height: 600,
                    navigation: false,
                    play: {
                        active: true,
                        auto: true,
                        interval: 4000,
                        swap: true
                    }
                }
        );
    });
	
	// Scroll Table
	var container = $('.box-scroll-table');
	var topscroll = $('.top-scroll-table');

	$('.fake').width($('.box-table-admin').width());

	topscroll.scroll(function(e){
		container.scrollLeft($(this).scrollLeft());
	});
	container.scroll(function(e){
		topscroll.scrollLeft($(this).scrollLeft());
	});	
	@if($errors->hasBag('CallBack'))

$(document).ready(
        function () {
            $('#Modal-orderCall').modal('show');
        });

@endif
@if(($errors->getBag('default')->has('password') || $errors->getBag('default')->has('email')) && !Request::is('register') && !Request::is('login'))

$(document).ready(
        function () {
            $('#LoginForm').modal('show');
        });

@endif

    $(document).ready(
        function () {
    $('#flash-overlay-modal').modal();
     });
 
     

</script>
</body></html>