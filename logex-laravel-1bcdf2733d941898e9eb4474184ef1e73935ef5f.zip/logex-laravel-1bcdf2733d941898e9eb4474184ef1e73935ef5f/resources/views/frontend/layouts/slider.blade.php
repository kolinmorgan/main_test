<div class="header-slider">
    <div class="body-wrapper clearfix">
        <div id="slides" clearfix">
        <div class="slide">
            <div class="header-slider-title">
                Транспортные услуги
            </div>
            <ul>
                <li>Автомобильные</li>
                <li>Железнодорожные</li>
                <li>Авиаперевозки</li>
            </ul>
            <a href="/transportation-services" class="header-slider-submit">Подробнее</a>
        </div>
        <div class="slide">
            <div class="header-slider-title">
                Курьерские услуги
            </div>
            <ul>
                <li>Для компаний</li>
                <li>Для физ. лиц</li>
            </ul>
            <a href="/courier-service" class="header-slider-submit">Подробнее</a>
        </div>
        <div class="slide">
            <div class="header-slider-title">
                Складские услуги
            </div>
            <ul>
                <li>Просторные склады</li>
                <li>Проверенное оборудование</li>
            </ul>
            <a href="/warehousing-services" class="header-slider-submit">Подробнее</a>
        </div>
        <!-- navigation-->
        <a href="#" class="slidesjs-previous slidesjs-navigation"></a>
        <a href="#" class="slidesjs-next slidesjs-navigation"></a>
        <!--slider-->
    </div>
</div>
