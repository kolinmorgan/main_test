    <div class="header-top clearfix">
        <div class="body-wrapper clearfix bg-logo">
            <a class="header-top-logo" href="/">
                <img src="/img/logex-logo.png" alt="">
            </a>
            <ul class="header-top-menu">
                <li><a href="/orders/create">Вызов курьера</a></li>
                <li><a href="#" data-toggle="modal" data-target="#Modal-orderCall">Обратный звонок</a></li>
            </ul>
            <div class="header-top-tracking">
                {!! Form::open(['route' => 'waybills.search']) !!}
                    {{--<input type="text" minlength="12" pattern="^\d{4}-\d{4}-\d{4}$" required="" name="code" title="Pattern ****-****-****" placeholder="Отслеживание">--}}
                    <input type="text" id="code"  name="code"  placeholder="Отслеживание">
                    <input type="submit" class="header-top-tracking-submit" value="">
                {!! Form::close() !!}
            </div>
            <div class="header-top-number">(727) 3 777 000</div>
        </div>
        @include('flash::message')
    </div>
    <div class="header-bottom clearfix">
        <div class="body-wrapper clearfix">
            <ul class="header-bottom-menu">
                <li><a class="active-menu" href="/">Главная</a></li>
                <li class="dropdown-hover-services"><a href="#">Услуги</a>
                    <ul class="dropdown-services">
                        <li><a href="/courier-service">Курьерские услуги</a></li>
                        <li><a href="/transportation-services">Транспортные услуги</a></li>
                        <li><a href="/warehousing-services">Складские услуги</a></li>
                        <li><a href="/additional-services">Другие услуги</a></li>
                    </ul>
                </li>
                <li class="dropdown-hover-about-us"><a href="#">О нас</a>
                    <ul class="dropdown-about-us">
                        <li><a href="/about-us">О компании</a></li>
                        <li><a href="/clients">Наши клиенты</a></li>
                    </ul>
                </li>
                <li><a href="/contacts">Контакты</a></li>
            </ul>
            @if (Auth::guest())
                <a href="#" data-toggle="modal" data-target="#Modal-login" class="header-bottom-login">Кабинет</a>
            @else
                <a href="{!! route('cabinet.waybills.index') !!}" class="header-bottom-my-acc">Мой кабинет</a>
                <a href="/logout" class="header-bottom-login">Выйти</a>
            @endif						
		</div>