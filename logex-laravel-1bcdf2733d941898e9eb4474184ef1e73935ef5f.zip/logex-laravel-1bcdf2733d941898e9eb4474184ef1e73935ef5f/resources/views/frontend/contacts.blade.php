@extends('frontend.layouts.app')

@section('content')
<main>
    <div class="page-title">
        <div class="body-wrapper clearfix head-line">
            <p>Наши контакты</p>
        </div>
    </div>
    <div class="contacts-block">
        <div class="body-wrapper clearfix">
            <div class="contacts-block-form">
                <div class="contacts-form-title head-line-contacts">Напишите нам</div>
                <p>Появились вопросы? Напишите нам, и мы ответим на все Ваши вопросы в кратчайшие сроки</p>
                @foreach ($errors->all() as $error)
                    <div class="col-md-6">                  
                            <span class="help-block">
                                <strong>{{ $error }}</strong>
                            </span>
                    </div>
                @endforeach
                {!! Form::open(['route' => 'mail']) !!}
                <input type="text" id="contactform-name" class="form-control" name="ContactForm[name]" placeholder="Ваше имя" style="width: 48.5%;">

                <div class="help-block"></div>
                <div class="form-group field-contactform-email required">

                    <input type="text" id="contactform-email" class="form-control" name="ContactForm[email]" placeholder="Ваш e-mail" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAfBJREFUWAntVk1OwkAUZkoDKza4Utm61iP0AqyIDXahN2BjwiHYGU+gizap4QDuegWN7lyCbMSlCQjU7yO0TOlAi6GwgJc0fT/fzPfmzet0crmD7HsFBAvQbrcrw+Gw5fu+AfOYvgylJ4TwCoVCs1ardYTruqfj8fgV5OUMSVVT93VdP9dAzpVvm5wJHZFbg2LQ2pEYOlZ/oiDvwNcsFoseY4PBwMCrhaeCJyKWZU37KOJcYdi27QdhcuuBIb073BvTNL8ln4NeeR6NRi/wxZKQcGurQs5oNhqLshzVTMBewW/LMU3TTNlO0ieTiStjYhUIyi6DAp0xbEdgTt+LE0aCKQw24U4llsCs4ZRJrYopB6RwqnpA1YQ5NGFZ1YQ41Z5S8IQQdP5laEBRJcD4Vj5DEsW2gE6s6g3d/YP/g+BDnT7GNi2qCjTwGd6riBzHaaCEd3Js01vwCPIbmWBRx1nwAN/1ov+/drgFWIlfKpVukyYihtgkXNp4mABK+1GtVr+SBhJDbBIubVw+Cd/TDgKO2DPiN3YUo6y/nDCNEIsqTKH1en2tcwA9FKEItyDi3aIh8Gl1sRrVnSDzNFDJT1bAy5xpOYGn5fP5JuL95ZjMIn1ya7j5dPGfv0A5eAnpZUY3n5jXcoec5J67D9q+VuAPM47D3XaSeL4AAAAASUVORK5CYII=&quot;); background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; background-repeat: no-repeat;">

                    <div class="help-block"></div>
                </div>                    
                <div class="form-group field-contactform-subject required">

                    <input type="text" id="contactform-subject" class="form-control" name="ContactForm[subject]" placeholder="Тема сообщения">

                    <div class="help-block"></div>
                </div>                   
                <div class="form-group field-contactform-body required">

                    <textarea id="contactform-body" class="textarea-contacts" name="ContactForm[body]" rows="8" placeholder="Сообщение"></textarea>

                    <div class="help-block"></div>
                </div>                    <div class="form-group">
                    <input type="submit" class="btn" name="" value="Отправить">                    </div>
                {!! Form::close() !!}
            </div> 	

            <div class="our-office-block">
                <div class="our-office-title">
                    Наш офис
                </div>
                <div class="our-office-address">
                    <span class="our-office-bold">Адрес</span>
                    Республика Казахстан, 050050, г.Алматы, ул. Ратушного 16
                </div>
                <div class="our-office-telephone">
                    <span class="our-office-bold">Телефон</span>
                    +7 (727) 3 777 000<br>
                    8 777 007 60 60<br>
                    8 777 007 13 77<br>
                </div>
                <div class="our-office-email">E-mail: info@logex.kz</div>
            </div>
        </div>
    </div>
</div>
</main>
@endsection
