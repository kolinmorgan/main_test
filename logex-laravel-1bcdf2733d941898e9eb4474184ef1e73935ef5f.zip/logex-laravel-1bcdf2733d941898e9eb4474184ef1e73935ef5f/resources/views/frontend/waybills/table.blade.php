<div class="box-table-admin">
<table class="table table-responsive" id="waybills-table">
    <thead class="f-tab1">
        <th>Пользователь</th>
        <th>Менеджер отправитель</th>
        <th>Дата приема</th>
		<th>Номер Накладной</th>
        @if (Auth::user()->isAdmin)        
        <th>Номер отправления</th>
		<th>Номер накладной (Компании)</th>
        @endif        
        <th>Отправитель (Компания)</th>
        <th>Получатель (Компания)</th>
        <th>Город отправителя</th>
        <th>Город получателя</th>
        <th>Кол-во мест</th>
        <th>Вес</th>
        <th>Вид отправления</th>
        <th>Важность</th>
        <th>Прочие отметки</th>
        <th>Цена</th>
        <th>Статус</th>
        <th>Дата доставки</th>
        <th>Время доставки</th>
        <th>ФИО Получателя</th>
        <th>Должность получателя</th>
        @if (Auth::user()->isAdmin)
        <th colspan="3">Действие</th>
        @endif
    </thead>
    <thead class="f-tab2">
        <th>User name</th>
        <th>Manager</th>
        <th>Pick up date</th>
		<th>Airway bill number</th>
        @if (Auth::user()->isAdmin)        
        <th>Shipment number</th>
		<th>Airway bill number of sender (Company)</th>
        @endif        
        <th>Sender (Company)</th>
        <th>Receiver (Company)</th>
        <th>Origin city</th>
        <th>Destination city</th>
        <th>Quantity of place</th>
        <th>Weight</th>
        <th>Type of shipment</th>
        <th>Importance</th>
        <th>Addition</th>
        <th>Price</th>
        <th>Status</th>
        <th>Delivery date</th>
        <th>Delivery time</th>
        <th>Receiver's name</th>
        <th>Position of receiver</th>
        @if (Auth::user()->isAdmin)
        <th colspan="3">Action</th>
        @endif
    </thead>	
    <tbody>
    @foreach($waybills as $waybill)
        <tr>
            <td>{!! $waybill->user->name !!}</td>
            <td>{!! $waybill->manager !!}</td>
            <td>{!! $waybill->send_date->format('Y-m-d') !!}</td>
            <td>{!! $waybill->code !!}</td>
			<td>{!! $waybill->package_id !!}</td>
            @if (Auth::user()->isAdmin)            
            <td>{!! $waybill->company_cod !!}</td>
			<td>{!! $waybill->company_sender_name !!}</td>
            @endif            
            <td>{!! $waybill->company_recipient_name !!}</td>
            <td>{!! $waybill->sender_city !!}</td>
            <td>{!! $waybill->recipient_city !!}</td>
            <td>{!! $waybill->places !!}</td>
            <td>{!! $waybill->weight !!}</td>
            <td>{!! $waybill->kind !!}</td>
            <td>{!! $waybill->priority !!}</td>
            <td>{!! $waybill->description !!}</td>
            <td>{!! $waybill->cost !!}</td>
            <td>{!! $waybill->status !!}
            @if (Auth::user()->isAdmin)
                    <div class="btns-box"><a href="{!! route('waybills.move', [$waybill->id]) !!}" class='btn btn-blue'>>></a></div>
            @endif
            </td>
            <td>{!! $waybill->delivery_date->format('Y-m-d') !!}</td>
            <td>{!! $waybill->delivery_time !!}</td>
            <td>{!! $waybill->recipient !!}</td>
            <td>{!! $waybill->recipient_position !!}</td>
            @if (Auth::user()->isAdmin)
            <td>
                {!! Form::open(['route' => ['waybills.destroy', $waybill->id], 'method' => 'delete']) !!}
                <div class='btn-group'>
                    <div class="btns-box"><a href="{!! route('waybills.show', ['code' => $waybill->code]) !!}" class='btn btn-green'>смотреть</a></div>
                    @if (Auth::user()->isAdmin)
                        <div class="btns-box"><a href="{!! route('waybills.edit', [$waybill->id]) !!}" class='btn btn-yellow'>править</a></div>
                        <div class="btns-box">{!! Form::button('Удалить', ['type' => 'submit', 'class' => 'btn btn-red', 'onclick' => "return confirm('Are you sure?')"]) !!}</div>
                    @endif
                </div>
                {!! Form::close() !!}
            </td>
            @endif
        </tr>
    @endforeach
    </tbody>
</table>
</div>