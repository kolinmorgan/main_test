@extends('frontend.layouts.app')

@section('content')
    <div class="page-title">
        <div class="body-wrapper clearfix head-line">
            <p>Редактировать накладную</p>
        </div>
    </div>
<div class="body-wrapper">
        @include('core-templates::common.errors')

        <div class="row" id="crate-waybills">
            {!! Form::model($waybill, ['route' => ['waybills.update', $waybill->id], 'method' => 'patch']) !!}

            @include('frontend.waybills.fields')

            {!! Form::close() !!}
        </div>
</div>		
@endsection