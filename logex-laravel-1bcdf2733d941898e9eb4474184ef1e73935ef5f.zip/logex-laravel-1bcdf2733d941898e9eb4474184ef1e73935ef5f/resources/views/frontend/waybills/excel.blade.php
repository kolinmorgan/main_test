<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<table class="table table-responsive" id="waybills-table">
    <tr>
        <th>Пользователь</th>
        <th>Менеджер отправитель</th>
        <th>Дата приема</th>
	<th>Номер Накладной</th>
        <th>Номер отправления</th>
	<th>Номер накладной (Компании)</th> 
        <th>Отправитель (Компания)</th>
        <th>Получатель (Компания)</th>
        <th>Город отправителя</th>
        <th>Город получателя</th>
        <th>Кол-во мест</th>
        <th>Вес</th>
        <th>Вид отправления</th>
        <th>Важность</th>
        <th>Прочие отметки</th>
        <th>Цена</th>
        <th>Статус</th>
        <th>Дата доставки</th>
        <th>Время доставки</th>
        <th>ФИО Получателя</th>
        <th>Должность получателя</th>
    </tr>

    @foreach($waybills as $waybill)
        <tr>
            <td>{!! $waybill->user->name !!}</td>
            <td>{!! $waybill->manager !!}</td>
            <td>{!! $waybill->send_date->format('Y-m-d') !!}</td>
            <td>{!! $waybill->code !!}</td>
			<td>{!! $waybill->package_id !!}</td>
      
            <td>{!! $waybill->company_cod !!}</td>
			<td>{!! $waybill->company_sender_name !!}</td>
             
            <td>{!! $waybill->company_recipient_name !!}</td>
            <td>{!! $waybill->sender_city !!}</td>
            <td>{!! $waybill->recipient_city !!}</td>
            <td>{!! $waybill->places !!}</td>
            <td>{!! $waybill->weight !!}</td>
            <td>{!! $waybill->kind !!}</td>
            <td>{!! $waybill->priority !!}</td>
            <td>{!! $waybill->description !!}</td>
            <td>{!! $waybill->cost !!}</td>
            <td>{!! $waybill->status !!}</td>
            <td>{!! $waybill->delivery_date->format('Y-m-d') !!}</td>
            <td>{!! $waybill->delivery_time !!}</td>
            <td>{!! $waybill->recipient !!}</td>
            <td>{!! $waybill->recipient_position !!}</td>

        </tr>
    @endforeach

</table>
