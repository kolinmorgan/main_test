<!-- User Id Field -->

<div class="form-group col-sm-6">
    {!! Form::label('user_id', 'User Id:') !!}
    {!! Form::select('user_id', App\User::all('id','name')->lists('name','id'), null, ['class' => 'form-control']) !!}
</div>
<!-- Manager Field -->
<div class="form-group col-sm-6">
    {!! Form::label('manager', 'Менеджер отправитель :') !!}
    {!! Form::text('manager', null, ['class' => 'form-control']) !!}
</div>
<!-- Send date Date Field -->
<div class="form-group col-sm-6">
    {!! Form::label('send_date', 'Дата приема:') !!}
    {!! Form::text('send_date', null, ['class' => 'form-control datepicker-here']) !!}
</div>
<!-- Code Field -->
<div class="form-group col-sm-6">
    {!! Form::label('code', 'Номер накладной:') !!}
    {!! Form::text('code', null, ['class' => 'form-control']) !!}
</div>
<!-- package_id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('package_id', 'Номер отправления:') !!}
    {!! Form::text('package_id', null, ['class' => 'form-control']) !!}
</div>
<!-- company_cod Field -->
<div class="form-group col-sm-6">
    {!! Form::label('company_cod', 'Номер накладной (Компании):') !!}
    {!! Form::text('company_cod', null, ['class' => 'form-control']) !!}
</div>
<!-- company_sender_name Field -->
<div class="form-group col-sm-6">
    {!! Form::label('company_sender_name', 'Отправитель (Компания):') !!}
    {!! Form::text('company_sender_name', null, ['class' => 'form-control']) !!}
</div>
<!-- company_sender_name Field -->
<div class="form-group col-sm-6">
    {!! Form::label('company_recipient_name', 'Получатель (Компания):') !!}
    {!! Form::text('company_recipient_name', null, ['class' => 'form-control']) !!}
</div>
<!-- sender_city Field -->
<div class="form-group col-sm-6">
    {!! Form::label('sender_city', 'Город отправителя:') !!}
    {!! Form::text('sender_city', null, ['class' => 'form-control']) !!}
</div>
<!-- recipient_city Field -->
<div class="form-group col-sm-6">
    {!! Form::label('recipient_city', 'Город получателя:') !!}
    {!! Form::text('recipient_city', null, ['class' => 'form-control']) !!}
</div>
<!-- places Field -->
<div class="form-group col-sm-6">
    {!! Form::label('places', 'Кол-во мест:') !!}
    {!! Form::text('places', null, ['class' => 'form-control']) !!}
</div>
<!-- weight Field -->
<div class="form-group col-sm-6">
    {!! Form::label('weight', 'Вес:') !!}
    {!! Form::text('weight', null, ['class' => 'form-control']) !!}
</div>
<!-- kind Field -->
<div class="form-group col-sm-6">
    {!! Form::label('kind', 'Вид отправления:') !!}
    {!! Form::text('kind', null, ['class' => 'form-control']) !!}
</div>
<!-- priority Field -->
<div class="form-group col-sm-6">
    {!! Form::label('priority', 'Важность:') !!}
    {!! Form::select('priority', ['Авиа' => 'Авиа','Жд' => 'Жд','Город' => 'Город','Россия' => 'Россия','Международ' => 'Международ','Зона город' => 'Зона город']) !!}
</div>
<!-- description Field -->
<div class="form-group col-sm-6">
    {!! Form::label('description', 'Прочие отметки:') !!}
    {!! Form::text('description', null, ['class' => 'form-control']) !!}
</div>

<!-- cost Field -->
<div class="form-group col-sm-6">
    {!! Form::label('cost', 'Стоимость:') !!}
    {!! Form::text('cost', null, ['class' => 'form-control']) !!}
</div>
<!-- Status Field -->
<div class="form-group col-sm-6">
    {!! Form::label('status', 'Статус:') !!}
    {!! Form::select('status', ['Принят' => 'Принят', 'В доставке' => 'В доставке', 'Доставлено' => 'Доставлено'], null, ['class' => 'form-control']) !!}
</div>
<!-- Delivery Date Field -->
<div class="form-group col-sm-6">
    {!! Form::label('delivery_date', 'Дата доставки:') !!}
    {!! Form::text('delivery_date', null, ['class' => 'form-control datepicker-here']) !!}
</div>
<!-- Delivery Time Field -->
<div class="form-group col-sm-6">
    {!! Form::label('delivery_time', 'Время доставки:') !!}
    {!! Form::text('delivery_time', null, ['class' => 'form-control']) !!}
</div>
<!-- recipient Field -->
<div class="form-group col-sm-6">
    {!! Form::label('recipient', 'ФИО Получателя:') !!}
    {!! Form::text('recipient', null, ['class' => 'form-control']) !!}
</div>
<!-- recipient_position Field -->
<div class="form-group col-sm-6">
    {!! Form::label('recipient_position', 'Должность получателя:') !!}
    {!! Form::text('recipient_position', null, ['class' => 'form-control']) !!}
</div>


<!-- Submit Field -->
<div class="form-group col-sm-12">
    {!! Form::submit('Сохранить', ['class' => 'btn btn-green']) !!}
    <a href="{!! route('waybills.index') !!}" class="btn btn-red">Отменить</a>
    <a href="/waybills/create?withold=true" class="btn btn-red">Предыдущая накладная</a>
</div>
