@extends('frontend.layouts.app')

@section('content')
    <div class="page-title">
        <div class="body-wrapper clearfix head-line">
            <p>Создать накладную</p>
        </div>
    </div>
<div class="body-wrapper">
    @include('core-templates::common.errors')

    <div class="row" id="crate-waybills">
        {!! Form::open(['route' => 'waybills.store']) !!}

            @include('frontend.waybills.fields')

        {!! Form::close() !!}
    </div>
</div>	
@endsection
