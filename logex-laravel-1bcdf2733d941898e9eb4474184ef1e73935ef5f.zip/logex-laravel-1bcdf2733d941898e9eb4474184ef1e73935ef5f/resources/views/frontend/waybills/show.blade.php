@extends('frontend.layouts.app')

@section('content')
<div class="body-wrapper">
    @include('frontend.waybills.show_fields')

    <div class="form-group">
    </div>
</div>	
@endsection
