    <div class="page-title">
        <div class="body-wrapper clearfix head-line">
            <p>Подробная информация</p>
        </div>
    </div>
<table>
<!-- User Id Field -->
	<tr>
		<td>{!! Form::label('user_id', 'Отправитель:') !!}</td>	
		<td>Sender:</td>
		<td>{!! $waybill->user->name !!}</td>
	</tr>
<!-- manager Field -->
	<tr>
		<td>{!! Form::label('manager ', 'Менеджер отправитель :') !!}</td>
		<td>Manager:</td>
		<td>{!! $waybill->manager !!}</td>
	</tr>
<!-- Send Date Field -->
    <tr>
        <td>{!! Form::label('send_date', 'Дата приема:') !!}</td>
		<td>Pick up date:</td>
        <td>{!! $waybill->send_date !!}</td>
    </tr>
<!-- Cod Field -->
    <tr>
        <td>{!! Form::label('code', 'Номер накладной:') !!}</td>
		<td>Airway bill number:</td>
        <td>{!! $waybill->code !!}</td>
    </tr>
@if (Auth::user() && Auth::user()->isAdmin)
<!-- package_id Field -->
    <tr>
        <td>{!! Form::label('package_id', 'Номер отправления:') !!}</td>
		<td>Shipment number:</td>
        <td>{!! $waybill->package_id !!}</td>
    </tr>
<!-- company_cod Field -->
    <tr>
        <td>{!! Form::label('company_cod', 'Номер накладной (Компании):') !!}</td>
		<td>Airway bill number of sender (Company):</td>
        <td>{!! $waybill->company_cod !!}</td>
    </tr>
@endif
<!-- company_sender_name Field -->
    <tr>
        <td>{!! Form::label('company_sender_name', 'Отправитель (Компания):') !!}</td>
		<td>Sender (Company):</td>
        <td>{!! $waybill->company_sender->name !!}</td>
    </tr>
<!-- company_recipient_name Field -->
    <tr>
        <td>{!! Form::label('company_recipient_name', 'Получатель (Компания):') !!}</td>
		<td>Receiver (Company):</td>
        <td>{!! $waybill->company_recipient_name !!}</td>
    </tr>
<!-- sender_city Field -->
    <tr>
        <td>{!! Form::label('sender_city', 'Город отправителя:') !!}</td>
		<td>Origin city</td>
        <td>{!! $waybill->sender_city !!}</td>
    </tr>
<!-- recipient_city Field -->
    <tr>
        <td>{!! Form::label('recipient_city', 'Город получателя:') !!}</td>
		<td>Destination city:</td>
        <td>{!! $waybill->recipient_city !!}</td>
    </tr>
<!-- places Field -->
    <tr>
        <td>{!! Form::label('places', 'Кол-во мест:') !!}</td>
		<td>Quantity of place:</td>
        <td>{!! $waybill->places !!}</td>
    </tr>
<!-- weight Field -->
    <tr>
        <td>{!! Form::label('weight', 'Вес:') !!}</td>
		<td>Weight:</td>
        <td>{!! $waybill->weight !!}</td>
    </tr>
<!-- kind Field -->
    <tr>
        <td>{!! Form::label('kind', 'Вид отправления:') !!}</td>
		<td>Type of shipment:</td>
        <td>{!! $waybill->kind !!}</td>
    </tr>
<!-- Priority Field -->
    <tr>
        <td>{!! Form::label('priority', 'Важность:') !!}</td>
		<td>Importance:</td>
        <td>{!! $waybill->priority !!}</td>
    </tr>
<!-- Description Field -->
    <tr>
        <td>{!! Form::label('description', 'Прочие отметки:') !!}</td>
		<td>Addition:</td>
        <td>{!! $waybill->description !!}</td>
    </tr>
<!-- Cost Field -->
    <tr>
        <td>{!! Form::label('cost', 'Стоимость:') !!}</td>
		<td>Price:</td>
        <td>{!! $waybill->cost !!}</td>
    </tr>
<!-- Status Field -->
    <tr>
        <td>{!! Form::label('status', 'Статус:') !!}</td>
		<td>Status:</td>
        <td>{!! $waybill->status !!}</td>
    </tr>
<!-- delivery_date Field -->
    <tr>
        <td>{!! Form::label('delivery_date', 'Дата доставки:') !!}</td>
		<td>Delivery date:</td>
        <td>{!! $waybill->delivery_date !!}</td>
    </tr>
<!-- delivery_time Field -->
    <tr>
        <td>{!! Form::label('delivery_time', 'Время доставки:') !!}</td>
		<td>Delivery time:</td>
        <td>{!! $waybill->delivery_time !!}</td>
    </tr>
<!-- Recipient Field -->
    <tr>
        <td>{!! Form::label('recipient', 'ФИО Получателя:') !!}</td>
		<td>Receiver's name:</td>
        <td>{!! $waybill->recipient !!}</td>
    </tr>
<!-- delivery_time Field -->
    <tr>
        <td>{!! Form::label('recipient_position', 'Должность получателя:') !!}</td>
		<td>Position of receiver:</td>
        <td>{!! $waybill->recipient_position !!}</td>
    </tr>
<!-- Updated At Field -->
	<tr>
		<td>{!! Form::label('updated_at', 'Последнее обновление:') !!}</td>	
		<td>Last update:</td>
		<td>{!! $waybill->updated_at !!}</td>
	</tr>
</table>

