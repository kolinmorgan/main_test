@extends('frontend.layouts.app')

@section('content')
<div class="tabble-admin">
    <div class="page-title">
        <div class="body-wrapper clearfix head-line">
            <p>Накладные</p>
        </div>
    </div>

    <h1 class="pull-left">Накладные</h1>
    @if (Auth::user()->isAdmin)
           
    <a class="btn btn-blue" href="/users">Пользователи</a>
        
    <a class="btn btn-red" style="margin-top: 25px" href="{!! route('waybills.create') !!}">Создать</a>
    <form style="display: inline-block;" action="/waybills/export" method="GET">
        С <input type="text" name="from" class="datepicker-here">
        По <input type="text" name="to" class="datepicker-here">
        <select id="company_sender_name1" hidden="hidden" name="company_sender_name">
					<option value="">Все</option>
					@foreach($company_sender_names as $name)
					@if(isset($searchInput['company_sender_name']) && $searchInput['company_sender_name'] == $name)
					<option selected>{{$name}}</option>
					@else
					<option>{{$name}}</option>
					@endif
					@endforeach
				</select>
        <input id="company_cod1" type="hidden" value="{{$searchInput['company_cod'] or ''}}" type="text" placeholder="Номер накладной" name="company_cod">				
        <button class="btn btn-yellow" type="submit">Скачать накладные</button>
    </form>
    @elseif(Auth::user()->isManager)
    <a class="btn btn-yellow" style="margin-top: 25px" href="{!! route('waybills.create') !!}">Создать</a>
    @endif
    <br>
    <form style="display: inline-block;" action="/waybills" method="GET">
		<div>
			<div  style="float:left;width:230px;">
				<input onchange="company_cod1.value=this.value;" value="{{$searchInput['company_cod'] or ''}}" type="text" placeholder="Номер накладной" name="company_cod">				
			</div>
			<div style="float:left;width:550px;">	
			    Отправитель (Компания)
				<select onchange="company_sender_name1.value=this.value;"  name="company_sender_name">
					<option value="">Все</option>
					@foreach($company_sender_names as $name)
					@if(isset($searchInput['company_sender_name']) && $searchInput['company_sender_name'] == $name)
					<option selected>{{$name}}</option>
					@else
					<option>{{$name}}</option>
					@endif
					@endforeach
				</select>
				<button class="btn btn-yellow" type="submit">Поиск</button>
			</div>
		</div>        
    </form>
    <div class="clearfix"></div>

    @include('flash::message')

    <div class="clearfix"></div>
    <div class="box-scroll-table">
        <div class="top-scroll-table">
            <div class="fake"></div>
        </div>				
        @include('frontend.waybills.table')
        {!! $waybills->appends($searchInput)->render() !!}
    </div>
</div>        
@endsection
@section('scripts')
<script>
</script>
@endsection