@extends('frontend.layouts.app')

@section('content')
{!! App\Models\Page::orderBy('id','desc')->first()->text !!}

@endsection
