@extends('layouts.app')

@section('content')
    <main>
    <div class="page-title">
        <div class="body-wrapper clearfix head-line">
            <p>История Заказов</p>
        </div>
    </div>
    <div class="body-wrapper clearfix">
        <table class="table red">
            <thead>
            <tr>
                <td>№</td>
                <td>Создан</td>
                <td>Статус</td>
                <td>Причина</td>
                <td></td>
            </tr>
            </thead>
            <tbody>
            @foreach($orders as $order)
                <tr>
                    <td>{{$order->order_id}}</td>
                    <td>{{$order->created_at}}</td>
                    <td>{{$order->state}}</td>
                    <td>{{$order->not_delivered_reason}}</td>
                    <td><a href="/orders/{{$order->id}}">Подробнеее</a></td>
                </tr>
            @endforeach
            <tr>
            </tr>
            </tbody>
        </table>
        @if(count($orders) == 0)
            <h2>Ваша история пуста</h2>
        @endif
    </div>
</main>
    @endsection