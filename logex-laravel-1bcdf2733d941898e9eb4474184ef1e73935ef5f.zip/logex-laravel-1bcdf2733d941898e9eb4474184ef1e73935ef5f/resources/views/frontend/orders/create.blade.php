@extends('frontend.layouts.app')

@section('content')
    <main>
    <div class="page-title">
        <div class="body-wrapper clearfix head-line">
            <p>Вызов курьера</p>
        </div>
    </div>
    <div class="body-wrapper clearfix">
        <div class="call-courier-form-block clearfix">
            {!! Form::open(['route' => 'ascdeliverer']) !!}
                    @foreach ($errors->all() as $error)
                    <div class="col-md-12">                  
                            <span class="help-block">
                                <strong>{{ $error }}</strong>
                            </span>
                    </div>
                    @endforeach			
                <div class="left-coll-form">
                    <div class="call-courier-title1">Отправитель</div>
					
                    <div class="clearfix"></div>

                    <div class="form-group field-curierform-name required">
 
                        <input type="text" id="curierform-name" class="form-control" name="CurierForm[name]" placeholder="Имя отправителя" style="cursor: auto; background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAfBJREFUWAntVk1OwkAUZkoDKza4Utm61iP0AqyIDXahN2BjwiHYGU+gizap4QDuegWN7lyCbMSlCQjU7yO0TOlAi6GwgJc0fT/fzPfmzet0crmD7HsFBAvQbrcrw+Gw5fu+AfOYvgylJ4TwCoVCs1ardYTruqfj8fgV5OUMSVVT93VdP9dAzpVvm5wJHZFbg2LQ2pEYOlZ/oiDvwNcsFoseY4PBwMCrhaeCJyKWZU37KOJcYdi27QdhcuuBIb073BvTNL8ln4NeeR6NRi/wxZKQcGurQs5oNhqLshzVTMBewW/LMU3TTNlO0ieTiStjYhUIyi6DAp0xbEdgTt+LE0aCKQw24U4llsCs4ZRJrYopB6RwqnpA1YQ5NGFZ1YQ41Z5S8IQQdP5laEBRJcD4Vj5DEsW2gE6s6g3d/YP/g+BDnT7GNi2qCjTwGd6riBzHaaCEd3Js01vwCPIbmWBRx1nwAN/1ov+/drgFWIlfKpVukyYihtgkXNp4mABK+1GtVr+SBhJDbBIubVw+Cd/TDgKO2DPiN3YUo6y/nDCNEIsqTKH1en2tcwA9FKEItyDi3aIh8Gl1sRrVnSDzNFDJT1bAy5xpOYGn5fP5JuL95ZjMIn1ya7j5dPGfv0A5eAnpZUY3n5jXcoec5J67D9q+VuAPM47D3XaSeL4AAAAASUVORK5CYII=&quot;); background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; background-repeat: no-repeat;">

                        
                    </div>
                    <div class="form-group field-curierform-phone">

                        <input type="text" id="curierform-phone" class="form-control" name="CurierForm[phone]" placeholder="Контактный телефон">

                        <div class="help-block"></div>
                    </div>
                    <div class="form-group field-curierform-country required">
							<input type="text" id="curierform-adress" class="form-control" name="CurierForm[country]" placeholder="Город">
                        <div class="help-block"></div>
                    </div>
                </div>
                <div class="right-coll-form">
                    <div class="form-group field-curierform-adress required">

                        <input type="text" id="curierform-adress" class="form-control" name="CurierForm[adress]" placeholder="Адрес">

                        <div class="help-block"></div>
                    </div>
                    <div class="form-group field-curierform-when required">

                        <input type="text" id="curierform-when" class="form-control" name="CurierForm[when]" placeholder="Когда забрать?">

                        <div class="help-block"></div>
                    </div>				
                    <div class="form-group field-curierform-weight">

                        <input type="text" id="curierform-weight" class="form-control" name="CurierForm[weight]" placeholder="Вес,кг">

                        <div class="help-block"></div>
                    </div>
                    <div class="form-group field-curierform-package">

                        <input type="hidden" name="CurierForm[package]" value="0"><label><input type="checkbox" id="curierform-package" name="CurierForm[package]" value="1"> Упаковка</label>

                        <div class="help-block"></div>
                    </div>
                    <div class="form-group field-curierform-insurance">

                        <input type="hidden" name="CurierForm[insurance]" value="0"><label><input type="checkbox" id="curierform-insurance" name="CurierForm[insurance]" value="1"> Страховка</label>

                        <div class="help-block"></div>
                    </div>				
                </div>
                <div class="form-info">
                    <h2>Примечание</h2>
                    <p>Заявки на текущий день принимаются до 16:00. После указанного времени заявку можно сделать только на следующий день. Заявки не принимаются на выходные и праздничные дни.</p>
                </div>
                <div class="btns clearfix">
                    <button type="submit">Вызвать курьера</button>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</main>
    @endsection