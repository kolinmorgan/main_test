@extends('frontend.layouts.app')

@section('content')
    <main>
    <div class="page-title">
        <div class="body-wrapper clearfix head-line">
            <p>Заказ №{{$order->id}} </p>
        </div>
    </div>
    <div class="body-wrapper clearfix">
        <table class="table red">
            <thead>
            <tr>
                <td>№</td>
                <td>Создан</td>
                <td>Статус</td>
                <td>Причина</td>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{$order->order_id}}</td>
                    <td>{{$order->created_at}}</td>
                    <td>{{$order->state}}</td>
                    <td>{{$order->not_delivered_reason}}</td>
                </tr>
            <tr>
            </tr>
            </tbody>
        </table>
        <h2>Отправитель</h2>
        <ul>
            <li>Имя:</li>
        </ul>
        <h2>Получатель</h2>
        <ul>
            <li>Имя:</li>
        </ul>
    </div>
</main>
    @endsection