
/*
 $(document).ready(function () {
 
 $('.select-picker')
 .selectpicker({
 liveSearch: true
 })
 .ajaxSelectPicker({
 ajax: {
 url: '/server/path/to/ajax/results',
 data: function () {
 var params = {
 q: '{{{q}}}'
 };
 if (gModel.selectedGroup().hasOwnProperty('ContactGroupID')) {
 params.GroupID = gModel.selectedGroup().ContactGroupID;
 }
 return params;
 }
 },
 locale: {
 emptyTitle: 'Search for contact...'
 },
 preprocessData: function (data) {
 var contacts = [];
 if (data.hasOwnProperty('Contacts')) {
 var len = data.Contacts.length;
 for (var i = 0; i < len; i++) {
 var curr = data.Contacts[i];
 contacts.push(
 {
 'value': curr.ContactID,
 'text': curr.FirstName + ' ' + curr.LastName,
 'data': {
 'icon': 'icon-person',
 'subtext': 'Internal'
 },
 'disabled': false
 }
 );
 }
 }
 return contacts;
 },
 preserveSelected: false
 });
 
 
 });
 */
$(document).ready(function () {

});

$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

function getCourierModal(id) {

    $.ajax({
        type: "GET",
        url: "/cabinet/couriers/add-route/" + id,
        success: function (result) {
            $('#courier-modal-body').html(result);

            $('#courier-modal').modal('show');

            $('.selectpicker').selectpicker();

            $('#courier_from').on('change', function () {
                if ($(this).val() == 'client') {
                    $('#courier_from_sort_center').hide();
                    $('#courier_from_custom').hide();
                }

                if ($(this).val() == 'sort_center') {
                    $('#courier_from_sort_center').show();
                    $('#courier_from_custom').hide();
                }
                if ($(this).val() == 'custom') {
                    $('#courier_from_sort_center').hide();
                    $('#courier_from_custom').show()
                }

            });

            $('#courier_to').on('change', function () {
                if ($(this).val() == 'client') {
                    $('#courier_to_sort_center').hide();
                    $('#courier_to_custom').hide();
                }

                if ($(this).val() == 'sort_center') {
                    $('#courier_to_sort_center').show();
                    $('#courier_to_custom').hide();
                }
                if ($(this).val() == 'custom') {
                    $('#courier_to_sort_center').hide();
                    $('#courier_to_custom').show()
                }

            });

            $('#add-route-button').on('click', function () {
                id = $('#add-route-waybill-id').val();
                $.ajax({
                    type: "POST",
                    url: "/cabinet/couriers/add-route/" + id,
                    data: $('#add-route').serialize(),
                    success: function (result) {
                        $('#courier-modal').modal('hide');
                   //     setTimeout(' getCourierModal('+id+')', 1000);
                         
                    

                    }});
            });
        }
    });
}
;


function getCourierManyModal(id) {

    $.ajax({
        type: "GET",
        url: "/cabinet/couriers/add-route-many/",
        success: function (result) {
            $('#courier-modal-body').html(result);

            $('#courier-modal').modal('show');

            $('.selectpicker').selectpicker();

            $('#courier_from').on('change', function () {
                if ($(this).val() == 'client') {
                    $('#courier_from_sort_center').hide();
                    $('#courier_from_custom').hide();
                }

                if ($(this).val() == 'sort_center') {
                    $('#courier_from_sort_center').show();
                    $('#courier_from_custom').hide();
                }
                if ($(this).val() == 'custom') {
                    $('#courier_from_sort_center').hide();
                    $('#courier_from_custom').show()
                }

            });

            $('#courier_to').on('change', function () {
                if ($(this).val() == 'client') {
                    $('#courier_to_sort_center').hide();
                    $('#courier_to_custom').hide();
                }

                if ($(this).val() == 'sort_center') {
                    $('#courier_to_sort_center').show();
                    $('#courier_to_custom').hide();
                }
                if ($(this).val() == 'custom') {
                    $('#courier_to_sort_center').hide();
                    $('#courier_to_custom').show()
                }

            });

            $('#add-route-button').on('click', function () {
                id = $('#add-route-waybill-id').val();
                $.ajax({
                    type: "POST",
                    url: "/cabinet/couriers/add-route/" + id,
                    data: $('#add-route').serialize(),
                    success: function (result) {
                        $('#courier-modal').modal('hide');
                   //     setTimeout(' getCourierModal('+id+')', 1000);
                         
                    

                    }});
            });
        }
    });
}


(function ($) {

    jQuery.fn.doubleScroll = function (userOptions) {

        // Default options
        var options = {
            contentElement: undefined, // Widest element, if not specified first child element will be used
            scrollCss: {
                'overflow-x': 'auto',
                'overflow-y': 'hidden'
            },
            contentCss: {
                'overflow-x': 'auto',
                'overflow-y': 'hidden'
            },
            onlyIfScroll: true, // top scrollbar is not shown if the bottom one is not present
            resetOnWindowResize: false, // recompute the top ScrollBar requirements when the window is resized
            timeToWaitForResize: 100 // wait for the last update event (usefull when browser fire resize event constantly during ressing)
        };

        $.extend(true, options, userOptions);

        // do not modify
        // internal stuff
        $.extend(options, {
            topScrollBarMarkup: '<div class="doubleScroll-scroll-wrapper" style="height: 20px;"><div class="doubleScroll-scroll" style="height: 20px;"></div></div>',
            topScrollBarWrapperSelector: '.doubleScroll-scroll-wrapper',
            topScrollBarInnerSelector: '.doubleScroll-scroll'
        });

        var _showScrollBar = function ($self, options) {

            if (options.onlyIfScroll && $self.get(0).scrollWidth <= $self.width()) {
                // content doesn't scroll
                // remove any existing occurrence...
                $self.prev(options.topScrollBarWrapperSelector).remove();
                return;
            }

            // add div that will act as an upper scroll only if not already added to the DOM
            var $topScrollBar = $self.prev(options.topScrollBarWrapperSelector);

            if ($topScrollBar.length == 0) {

                // creating the scrollbar
                // added before in the DOM
                $topScrollBar = $(options.topScrollBarMarkup);
                $self.before($topScrollBar);

                // apply the css
                $topScrollBar.css(options.scrollCss);
                $self.css(options.contentCss);

                // bind upper scroll to bottom scroll
                $topScrollBar.bindWithDelay('scroll.doubleScroll', function () {
                    $self.scrollLeft($topScrollBar.scrollLeft());
                }, 20);

                // bind bottom scroll to upper scroll
                var selfScrollHandler = function () {
                    $topScrollBar.scrollLeft($self.scrollLeft());
                };
                $self.bindWithDelay('scroll.doubleScroll', selfScrollHandler, 20);
            }

            // find the content element (should be the widest one)	
            var $contentElement;

            if (options.contentElement !== undefined && $self.find(options.contentElement).length !== 0) {
                $contentElement = $self.find(options.contentElement);
            } else {
                $contentElement = $self.find('>:first-child');
            }


            // set the width of the wrappers
            //$(options.topScrollBarInnerSelector, $topScrollBar).width($contentElement.outerWidth());
            $(options.topScrollBarInnerSelector, $topScrollBar).width(6000);
            $topScrollBar.width($self.width());

            $topScrollBar.scrollLeft($self.scrollLeft());

        }

        return this.each(function () {

            var $self = $(this);

            _showScrollBar($self, options);

            // bind the resize handler 
            // do it once
            if (options.resetOnWindowResize) {

                var id;
                var handler = function (e) {
                    _showScrollBar($self, options);
                };

                $(window).bind('resize.doubleScroll', function () {
                    // adding/removing/replacing the scrollbar might resize the window
                    // so the resizing flag will avoid the infinite loop here...
                    clearTimeout(id);
                    id = setTimeout(handler, options.timeToWaitForResize);
                });

            }

        });

    }

}(jQuery));


;
(function (factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register module depending on jQuery using requirejs define.
        define(['jquery'], factory);
    } else {
        // No AMD.
        factory(jQuery);
    }
}(function ($) {
    $.fn.addBack = $.fn.addBack || $.fn.andSelf;

    $.fn.extend({
        actual: function (method, options) {
            // check if the jQuery method exist
            if (!this[ method ]) {
                throw '$.actual => The jQuery method "' + method + '" you called does not exist';
            }

            var defaults = {
                absolute: false,
                clone: false,
                includeMargin: false,
                display: 'block'
            };

            var configs = $.extend(defaults, options);

            var $target = this.eq(0);
            var fix, restore;

            if (configs.clone === true) {
                fix = function () {
                    var style = 'position: absolute !important; top: -1000 !important; ';

                    // this is useful with css3pie
                    $target = $target.
                            clone().
                            attr('style', style).
                            appendTo('body');
                };

                restore = function () {
                    // remove DOM element after getting the width
                    $target.remove();
                };
            } else {
                var tmp = [];
                var style = '';
                var $hidden;

                fix = function () {
                    // get all hidden parents
                    $hidden = $target.parents().addBack().filter(':hidden');
                    style += 'visibility: hidden !important; display: ' + configs.display + ' !important; ';

                    if (configs.absolute === true)
                        style += 'position: absolute !important; ';

                    // save the origin style props
                    // set the hidden el css to be got the actual value later
                    $hidden.each(function () {
                        // Save original style. If no style was set, attr() returns undefined
                        var $this = $(this);
                        var thisStyle = $this.attr('style');

                        tmp.push(thisStyle);
                        // Retain as much of the original style as possible, if there is one
                        $this.attr('style', thisStyle ? thisStyle + ';' + style : style);
                    });
                };

                restore = function () {
                    // restore origin style values
                    $hidden.each(function (i) {
                        var $this = $(this);
                        var _tmp = tmp[ i ];

                        if (_tmp === undefined) {
                            $this.removeAttr('style');
                        } else {
                            $this.attr('style', _tmp);
                        }
                    });
                };
            }

            fix();
            // get the actual value with user specific methed
            // it can be 'width', 'height', 'outerWidth', 'innerWidth'... etc
            // configs.includeMargin only works for 'outerWidth' and 'outerHeight'
            var actual = /(outer)/.test(method) ?
                    $target[ method ](configs.includeMargin) :
                    $target[ method ]();

            restore();
            // IMPORTANT, this plugin only return the value of the first element
            return actual;
        }
    });
}));


(function ($) {

    $.fn.bindWithDelay = function (type, data, fn, timeout, throttle) {

        if ($.isFunction(data)) {
            throttle = timeout;
            timeout = fn;
            fn = data;
            data = undefined;
        }

        // Allow delayed function to be removed with fn in unbind function
        fn.guid = fn.guid || ($.guid && $.guid++);

        // Bind each separately so that each element has its own delay
        return this.each(function () {

            var wait = null;

            function cb() {
                var e = $.extend(true, {}, arguments[0]);
                var ctx = this;
                var throttler = function () {
                    wait = null;
                    fn.apply(ctx, [e]);
                };

                if (!throttle) {
                    clearTimeout(wait);
                    wait = null;
                }
                if (!wait) {
                    wait = setTimeout(throttler, timeout);
                }
            }

            cb.guid = fn.guid;

            $(this).bind(type, data, cb);
        });
    };

})(jQuery);

//$(document).ready(function () {
//$('#scanner_waybill').val('line1\nline2');
//});
/*
$(document).scannerDetection({
	timeBeforeScanTest: 200, // wait for the next character for upto 200ms
	endChar: [13], // be sure the scan is complete if key 13 (enter) is detected
	avgTimeByChar: 20, // it's not a barcode if a character takes longer than 40ms
	ignoreIfFocusOn: 'input', // turn off scanner detection if an input has focus
	onComplete: function(barcode, qty){ 
             $('#scanner_waybill').val( $('#scanner_waybill').val() + barcode+'\n');
        }, // main callback function
	scanButtonKeyCode: 116, // the hardware scan button acts as key 116 (F5)
	scanButtonLongPressThreshold: 5, // assume a long press if 5 or more events come in sequence
	//onScanButtonLongPressed: showKeyPad, // callback for long pressing the scan button
	//onError: function(string){alert('Ошибка ' + string);}
});*/

$(document).ready(function () {
    $('.paste_from_excel_standart').on('change', function() {
         var data = $(this).val();
        
        data =   data.replace(/(?:\r\n|\r|\n)/g, '\t');
        data = data.split('\t');
        
        $('.inp-standart').each(function(i) {
            $(this).val( data[i] );
        });
        
    });
    
    $('.paste_from_excel_express').on('change', function() {
         var data = $(this).val();
        
        data =   data.replace(/(?:\r\n|\r|\n)/g, '\t');
        data = data.split('\t');
        
        $('.inp-express').each(function(i) {
            $(this).val( data[i] );
        });
        
    });
    
    $('#calc-button').on('click', function(event) {
        event.preventDefault();
        
        var data = $('#waybill_form').serialize();
        
         $.ajax({
            type: "POST",
            url: '/cabinet/calculator/calc',
             dataType: 'json',
            data: data,
            success: function (response) {
              if(response.status == 'success') {
                  $('#waybill-cost').val(response.price);
              } else {
                  alert('Возникла ошибка при расчете')
              }
            }
        });
    });
});