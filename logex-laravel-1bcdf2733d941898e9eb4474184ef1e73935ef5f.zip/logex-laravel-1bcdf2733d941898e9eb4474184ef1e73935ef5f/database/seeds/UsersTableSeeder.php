<?php

use Illuminate\Database\Seeder;
use App\User;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create(['id'=>0,'name'=>'Неизвестный','email'=>'noname@logex.kz','password'=>bcrypt('asdasdasd')]);
        $user->id = 0;
        $user->save();
        User::create(['id'=>1,'name'=>'Администратор','email'=>'admin@logex.kz','password'=>bcrypt('1LogexTheBest'),'isAdmin'=>1]);
    }
}
