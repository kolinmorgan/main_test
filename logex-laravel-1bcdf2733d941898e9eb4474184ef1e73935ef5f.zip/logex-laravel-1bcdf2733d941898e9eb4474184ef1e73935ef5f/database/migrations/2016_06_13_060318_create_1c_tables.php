<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Create1cTables extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sender_1c', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('waybill_1c_id');
            $table->integer('customer_id')->unsigned();
            $table->integer('location_id')->unsigned();
            $table->string('contact_name',512);
            $table->string('address', 512);
            $table->string('zipcode',20);
            $table->string('contact_phone',20);
            $table->string('customer_role');
            $table->timestamps();
        });
        Schema::create('receiver_1c', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('waybill_1c_id');
            $table->integer('location_id')->unsigned();
            $table->string('contact_name',512);
            $table->string('address', 512);
            $table->string('zipcode',20);
            $table->string('contact_phone',20);
            $table->string('customer_role');
            $table->timestamps();
        });
        Schema::create('waybill_1c', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('waybill_1c_id');
            $table->integer('order_id')->unsigned();
            $table->integer('waybill_type')->unsigned();
            $table->integer('items_value')->unsigned();
            $table->integer('created_user_id')->unsigned();
            $table->integer('updated_user_id')->unsigned();
            $table->integer('courier_id')->unsigned();
            $table->boolean('is_newsletter');
            $table->boolean('is_envelop');
            $table->boolean('only_documents');
            $table->string('state');
            $table->string('not_delivered_reason');
            $table->string('not_delivered_other');
            $table->string('description');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('waybill_1c');
        Schema::drop('sender_1c');
        Schema::drop('receiver_1c');
    }
}
