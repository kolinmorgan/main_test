<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateWaybillsTable extends Migration
{

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('waybills', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id')->unsigned()->default(NULL);
            $table->string('code');
            $table->integer('places', false, true);
            $table->float('weight');
            $table->float('description');
            $table->string('kind');
            $table->enum('status', ['Принят', 'В доставке', 'Доставлено'])->default('Принят');
            $table->enum('priority',['Авиа','Жд','Город','Россия','Международ','Зона город']);
            $table->integer('cost');

            $table->string('sender_city');
            $table->timestamp('send_date');

            $table->string('recipient');
            $table->string('recipient_position');
            $table->string('recipient_city');
            $table->date('delivery_date');
            $table->time('delivery_time');
            $table->string('delivery_address');

            $table->string('package_id');
            $table->string('manager');

            $table->string('company_cod');
            $table->string('company_sender_name');
            $table->string('company_recipient_name');

            $table->timestamps();
            $table->softDeletes();
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('waybills');
    }
}
