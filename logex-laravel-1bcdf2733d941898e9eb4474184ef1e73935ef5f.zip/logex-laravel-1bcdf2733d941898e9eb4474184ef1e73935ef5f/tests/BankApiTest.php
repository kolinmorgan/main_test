<?php

use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Storage;
use App\Models\APIKey;

class BankApiTest extends TestCase
{
	/**
	 * Testing the creation of a waybill.
	 *
	 * @return array
	 */
	public function testCreateWaybill()
	{
		$api_key = APIKey::first(['key']);

		$data = [
			'id' => rand(1, 1000),
			'name' => 'Ф.И.О.',
			'city' => 'Алматы',
			'address' => 'ул. Уличная',
			'phone' => '+111 (111) 111-11-11'
		];

		$response = $this->json('post', '/bankapi/waybills/create?api_key=' . $api_key->key, $data);

		$response
			->assertResponseStatus(200)
			->seeJson(['status' => 'success']);

		return $response->decodeResponseJson();
	}

	/**
	 * Testing the receipt of the waybills list.
	 *
	 * @return void
	 */
	public function testGetWaybillsStatusList()
	{
		$api_key = APIKey::first(['key']);

		$response = $this->json('get', '/bankapi/waybills/status_list?api_key=' . $api_key->key);

		$response
			->assertResponseStatus(200)
			->seeJson(['status' => 'success']);
	}

	/**
	 * Testing the status update of the waybill.
	 *
	 * @depends testCreateWaybill
	 * @param array $input
	 * @return void
	 */
	public function testUpdateWaybillStatus(array $input)
	{
		$api_key = APIKey::first(['key']);

		$input['status'] = 'Доставлено';
		$input['return_reason'] = 'Return reason';

		$images = ['test_image_1.jpg', 'test_image_2.jpg', 'test_image_3.jpg'];

		foreach ($images as $image) {
			$file_encode = base64_encode(Storage::disk('local')->get('waybill_images/' . $image));

			$input['documents'][] = [
				'filename' => $image,
				'mimetype' => 'image/jpeg',
				'file_encode' => $file_encode
			];
		}

		$response = $this->json('post', '/bankapi/waybills/status_update?api_key=' . $api_key->key, $input);

		$response
			->assertResponseStatus(200)
			->seeJson(['status' => 'success']);
	}

	/**
	 * Testing for status.
	 *
	 * @depends testCreateWaybill
	 * @param array $input
	 * @return array
	 */
	public function testGetWaybillStatus(array $input)
	{
		$api_key = APIKey::first(['key']);

		$response = $this->json('get', '/bankapi/waybills/status?api_key=' . $api_key->key . '&waybill_id=' . $input['waybill_id']);

		$response
			->assertResponseStatus(200)
			->seeJson(['status' => 'success']);

		return $response->decodeResponseJson();
	}

	/**
	 * File receipt test.
	 *
	 * @depends testGetWaybillStatus
	 * @param array $input
	 * @return void
	 */
	public function testGetFile(array $input)
	{
		$api_key = APIKey::first(['key']);

		$response = $this->json('get', '/bankapi/waybills/get_file?api_key=' . $api_key->key . '&id=' . $input['data']['documents'][0]['id']);

		$res_data = $response->decodeResponseJson();
		Storage::disk('local')->put('waybill_images/' . 'download_' . $res_data['filename'], base64_decode($res_data['file_encode']));

		$response
			->assertResponseStatus(200)
			->seeJson(['status' => 'success']);
	}
}
