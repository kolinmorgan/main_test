<?php

use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use App\Models\APIKey;

class WebApi2Test extends TestCase
{
	/**
	 * Testing the creation of a waybill.
	 *
	 * @return array
	 */
	public function testCreateWaybill()
	{
		$api_key = APIKey::first(['key']);

		$data = [
			'api_key' => $api_key->key,
			'id' => rand(1, 5000),
			'payment_type' => 'cash',
			'type' => 'express',
			'send_date' => time(),
			'description' => 'Description test',
			'from' => [
				[
					'city' => 'Алматы',
					'address' => 'ул. Уличная, 11',
					'price' => 999.5,
					'count' => 1,
					'weight' => 2
				]
			],
			'to' => [
				'name' => 'Иванов Иван Иванович',
				'city' => 'Алматы',
				'address' => 'ул. Иванова, 333',
				'phone' => '+380 (111) 111-11-11'
			]
		];

		$response = $this->post('/webapi2/waybills/create', $data);

		$response
			->assertResponseStatus(200)
			->seeJson(['status' => 'success']);

		return $response->decodeResponseJson();
	}

	/**
	 * Testing for status.
	 * Get status by waybill id.
	 *
	 * @depends testCreateWaybill
	 * @param array $input
	 * @return void
	 */
	public function testGetWaybillStatusById(array $input)
	{
		$api_key = APIKey::first(['key']);

		$response = $this->get('/webapi2/waybills/status?api_key=' . $api_key->key . '&waybill_id=' . $input['data']['waybill_id']);

		$response
			->assertResponseStatus(200)
			->seeJson(['status' => 'success']);
	}

	/**
	 * Testing for status.
	 * Get status by code.
	 *
	 * @depends testCreateWaybill
	 * @param array $input
	 * @return void
	 */
	public function testGetWaybillStatusByCode(array $input)
	{
		$api_key = APIKey::first(['key']);

		$response = $this->get('/webapi2/waybills/status?api_key=' . $api_key->key . '&id=' . $input['data']['code']);

		$response
			->assertResponseStatus(200)
			->seeJson(['status' => 'success']);
	}
}
