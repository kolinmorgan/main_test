<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
        'location_id', 'company_id', 'role', 'company_name', 
        'webkassa_login', 'webkassa_password', 'webkassa_id', 'webkassa_token'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
    
    
        public function company() {
            return $this->belongsToMany('App\Models\Company', 'user_company', 'company_id', 'user_id');
 
    }
    
    
       public function location() {
        return $this->hasOne('App\Models\Location', 'id', 'location_id');
    }
    
}
