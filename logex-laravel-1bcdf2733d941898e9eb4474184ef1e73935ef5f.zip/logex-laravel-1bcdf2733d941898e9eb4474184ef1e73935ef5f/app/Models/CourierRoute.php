<?php

namespace App\Models;

use Eloquent as Model;
use App\Models\Waybill;
use App\User;

class CourierRoute extends Model {

    // use SoftDeletes;

    public $table = 'courier_route';
    public $fillable = [
        'from', 'from_value', 'to', 'to_value', 'waybill_id', 'courier_id', 'status','active'
    ];
    protected $appends = array('from_text', 'to_text', 'from_value_text', 'to_value_text');

    public function courier() {
        return $this->hasOne('App\User', 'id', 'courier_id');
    }
    
    public function waybill() {
        return $this->hasOne('App\Models\Waybill', 'id', 'waybill_id');
    }

    public function getFromTextAttribute() {
        $val = ['client' => 'Клиент', 'sort_center' => 'С.Ц.', 'custom' => 'Другое', 'courier' => 'Курьер'];
        return $val[$this->attributes['from']];
    }

    public function getToTextAttribute() {
         $val = ['client' => 'Клиент', 'sort_center' => 'С.Ц.', 'custom' => 'Другое', 'courier' => 'Курьер'];
        return $val[$this->attributes['to']];
    }

    public function getFromValueTextAttribute() {
        if ($this->attributes['from'] == 'custom')
            return $this->attributes['from_value'];

        if ($this->attributes['from'] == 'sort_center') {
            $sort_center = SortCenter::where('id', $this->attributes['from_value'])->first();
            return $sort_center->name.' '.$sort_center->adress;
        }
        if ($this->attributes['from'] == 'client') {
            $waybill = Waybill::where('id', $this->attributes['waybill_id'])->withTrashed()->first();
            if($waybill != '') {
            return $waybill->sender_address;
            } else {
                return '';
            }
        }
        if ($this->attributes['from'] == 'courier') {
            $courier = User::where('id', $this->attributes['from_value'])->first();
            return $courier->name;
        }
    }

    public function getToValueTextAttribute() {
              if ($this->attributes['to'] == 'custom')
            return $this->attributes['from_value'];

        if ($this->attributes['to'] == 'sort_center') {
            $sort_center = SortCenter::where('id', $this->attributes['to_value'])->first();
            return $sort_center->name;
        }
        if ($this->attributes['to'] == 'client') {
            $waybill = Waybill::where('id', $this->attributes['waybill_id'])->withTrashed()->first();
            if($waybill != null) {
            return $waybill->recipient_address;
            } else {
               return '';
            }
        }
             if ($this->attributes['to'] == 'courier') {
            $courier = User::where('id', $this->attributes['to_value'])->first();
            return $courier->name;
        }
    }

}
