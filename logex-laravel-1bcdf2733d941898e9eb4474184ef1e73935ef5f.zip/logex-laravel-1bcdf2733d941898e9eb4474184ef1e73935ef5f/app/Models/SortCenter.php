<?php

namespace App\Models;

use Eloquent as Model;
use App\Models\Waybill;

class SortCenter extends Model {

    // use SoftDeletes;

    public $table = 'sort_centers';
    //  protected $dates = ['deleted_at'];
    public $fillable = [
        'name',
        'adress',
        'location_id'
    ];

    
       public function location() {
        return $this->hasOne('App\Models\Location', 'id', 'location_id');
    }
    

}
