<?php

namespace App\Models;

use Eloquent as Model;
use App\Models\Waybill;

class Company extends Model {

    // use SoftDeletes;

    public $table = 'companies';
    //  protected $dates = ['deleted_at'];
    public $fillable = [
        'name',
        'location_id',
        'address',
        'id_min',
        'id_max',
        'id_null_count',
        'rate_id'
    ];

    public function getIdBalanceAttribute() {

        $codes = [];
        for ($i = $this->attributes['id_min']; $i <= $this->attributes['id_max']; $i++) {
            $codes[] = $this->nulls.$i;
        }

        $waybills_count = Waybill::whereIn('code', $codes)->count();
        
        $count = $this->attributes['id_max'] - $this->attributes['id_min'] - $waybills_count + 1;
        return $count;
    }

    public function getNullsAttribute() {
        $nulls = '';
        for($i=0; $i<$this->attributes['id_null_count']; $i++) {
            $nulls = $nulls.'0';
        }
        return $nulls;
    }
    /*
      public function hasAutoCode() {
      if ($this->attributes['id_max'] != null && $this->attributes['id_max'] > 0) {
      return true;
      } else {
      return false;
      }
      }
     */

    public function getNextCodeAttribute() {

        if ($this->attributes['id_max'] != null && $this->attributes['id_max'] > 0) {
            $codes = [];
            for ($i = $this->attributes['id_min']; $i <= $this->attributes['id_max']; $i++) {
                $codes[] = $this->nulls.$i;
            }
            //      dd($codes);

            $code = Waybill::whereIn('code', $codes)->max('code');
            if ($code == null) {
                $code = $this->attributes['id_min'];
            } else {
                $code++;
            }
            if ($code <= $this->attributes['id_max']) {
                return $this->nulls.$code;
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

}
