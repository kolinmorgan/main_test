<?php

namespace App\Models;

use Eloquent as Model;


class ZonesKz extends Model {

    protected $guarded = ['id'];
    protected $table = 'zones_kz';

}
