<?php

namespace App\Models;

use Eloquent as Model;


class APIKey extends Model {

    protected $guarded = ['id'];
    protected $table = 'api_keys';

}
