<?php

namespace App\Models;

use Eloquent as Model;


class CalculatorZones extends Model {

    protected $guarded = ['id'];
    protected $table = 'calculator_zones';
    
    public $timestamps = false;
    
    public function city_from() {
        return $this->hasOne('App\Models\Location', 'id', 'from_id');
        
    }
        public function city_to() {
        return $this->hasOne('App\Models\Location', 'id', 'to_id');
        
    }



}
