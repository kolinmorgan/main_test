<?php

namespace App\Models;

use Eloquent as Model;
use App\Models\Waybill;

class Page extends Model {

    // use SoftDeletes;

    public $table = 'pages';
    //  protected $dates = ['deleted_at'];
    public $fillable = [
        'text',
    ];

   
    

}
