<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WaybillFile extends Model
{
	/**
	 * The table associated with the model.
	 *
	 * @var string
	 */
	protected $table = 'waybill_files';

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected $fillable = ['waybill_id', 'filename', 'mimetype'];

	/**
	 * Receive waybill.
	 */
	public function waybill()
	{
		return $this->belongsTo('App\Models\Waybill');
	}
}