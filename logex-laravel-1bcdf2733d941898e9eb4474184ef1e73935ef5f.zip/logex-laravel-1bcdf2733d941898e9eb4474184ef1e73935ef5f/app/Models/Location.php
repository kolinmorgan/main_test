<?php

namespace App\Models;

use Eloquent as Model;


class Location extends Model {

   // use SoftDeletes;

    public $table = 'locations';


  //  protected $dates = ['deleted_at'];
    public $fillable = [
        'name',
    ];



}
