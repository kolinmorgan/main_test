<?php

namespace App\Models;

use Eloquent as Model;


class CalculatorRates extends Model {

    protected $guarded = ['id'];
    protected $table = 'calculator_rates';
    
    public $timestamps = false;


    public function getRatesAttribute() {
        return json_decode($this->data, TRUE);
    }

        
    public function companies() {
        return $this->hasMany('App\Models\Company', 'rate_id', 'id');
    }
}
