<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Models\Setting;

class Waybill extends Model {

    use SoftDeletes;

//    public $table = 'waybills';
//protected $dateFormat = 'd.m.Y';
    protected $dates = ['created_at', 'updated_at', 'deleted_at', 'send_date'];
    //protected $dates = ['deleted_at'];
    public $guarded = ['id'];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'user_id' => 'integer',
        'code' => 'string',
        'places' => 'integer',
        //   'weight' => 'float',
        'weight' => 'string',
        'description' => 'string',
        'kind' => 'string',
        'status' => 'string',
        'priority' => 'string',
        'cost' => 'integer',
        'sender_city' => 'string',
        'send_date' => 'date',
        'recipient' => 'string',
        'recipient_position' => 'string',
        'recipient_city' => 'string',
        'delivery_date' => 'date',
        'delivery_time' => 'time',
        'sender_address' => 'string',
        'recipient_address' => 'string',
        'package_id' => 'integer',
        'manager' => 'string',
        'company_cod' => 'string',
        'company_sender_id' => 'string',
        'company_recipient_name' => 'string',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'code' => 'required|unique:waybills|max:255',
        'send_date' => 'required',
        'manager' => 'required|max:255',
        'delivery_date' => 'required',
        //'cost' => 'required',
        'status' => 'required',
        'deliverer' => 'max:255',
        'delivery_address' => 'max:255',
    ];

    public function user() {
        return $this->belongsTo('App\User');
    }

    public function company_sender() {
        return $this->hasOne('App\Models\Company', 'id', 'company_sender_id');
    }

    public function courier_routes() {
        return $this->hasMany('App\Models\CourierRoute', 'waybill_id', 'id');
    }

    public function getDeliveryDateAttribute($value) {
        //dd(date('d.m.Y', strtotime($value)));
        if ($value > 0) {
            return date('d.m.Y', strtotime($value));
        } else {
            return 'Не указано';
        }
    }

    public function getDeliveryTimeAttribute($value) {
        if ($value > 0) {
            return date('H:i', strtotime($value));
        } else {
            return 'Не указано';
        }
    }

    public function getSendDateAttribute($value) {
        if ($value > 0) {
            return date('d.m.Y H:i', strtotime($value));
        } else {
            return 'Не указано';
        }
    }

    public function setSendDateAttribute($value) {
       
            $this->attributes['send_date'] = date('Y-m-d H:i:s', strtotime($value));
      
    }

    public function setDeliveryDateAttribute($value) {
        $this->attributes['delivery_date'] = date('Y-m-d H:i:s', strtotime($value));
    }

    public function setWeightAttribute($value) {
        $this->attributes['weight'] = str_replace(',', '.', $value);
    }

    public function getWeightAttribute($value) {

        return str_replace('.', ',', $value);
    }

    public function getCurrentLocationName() {
        $names = [
            0 => 'Не выбрано',
            1 => 'Клиент',
            2 => 'Курьер',
            3 => 'Сортировочный центр'
        ];

        return $names[$this->attributes['current_location']];
    }

    public function getStatusNameAttribute() {
        $status = [
            'Новая' => 'new',
            'В обработке' => 'accepted',
            'В доставке' => 'delivery',
            'Доставлено' => 'delivered',
            'Не доставлено' => 'not_delivered',
            'Возврат' => 'returned',
            'Частичный возврат' => 'returned',
            'Возврат в сортировочный центр' => 'returned',
            'Забор осуществлён' => 'pickup'
        ];
    
        return $status[$this->attributes['status']];
    }

    
    public function getCommissionAttribute() {
       if($this->payment_sum > 0 && $this->payment_type == 'наличный') {
           $commission =  Setting::where('name', 'commission')->first()->value;
           
           return round($this->payment_sum * ($commission/100));
       } else {
           return '';
       }
    }
    
    public function waybills() {
        return $this->hasMany('App\Models\Waybill', 'main_waybill_id', 'id');
    }

	/**
	 * Receive all files for the current waybill.
	 */
	public function files()
	{
		return $this->hasMany('App\Models\WaybillFile');
	}
}
