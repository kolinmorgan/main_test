<?php

namespace App\Models;

use Eloquent as Model;


class ZonesRates extends Model {

    protected $guarded = ['id'];
    protected $table = 'zones_rates';

}
