<?php

namespace App\Repositories;

use App\Models\Waybill;
use App\User;
use InfyOm\Generator\Common\BaseRepository;

class WaybillRepository extends BaseRepository
{
    /**
     * @var array
     */
//    protected $fieldSearchable = [
//        'code'
//    ];

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Waybill::class;
    }

    /**
     * Retrieve all data of repository
     *
     * @param array $columns
     *
     * @return mixed
     */
    public function all($columns = ['*'])
    {
        $this->applyCriteria();
        $this->applyScope();

        $user = \Auth::user();
        if (empty($user)) return [];
        if ($user->isAdmin) {
            if ($this->model instanceof Builder) {
                $results = $this->model->get($columns);
            } else {
                $results = $this->model->all($columns);
            }
        } else {
            if ($this->model instanceof Builder) {
                $results = $this->model->where('user_id', '=', $user->id)->get($columns);
            } else {
                $results = $this->model->where('user_id', '=', $user->id)->get($columns);
            }
        }

        $this->resetModel();
        $this->resetScope();

        return $this->parserResult($results);
    }
}
