<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;
use App\Models\Waybill;

class UpdateWaybillRequest extends Request {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        if($this->has('send_date')) {
        return [
            'send_date' => 'required',
            'manager' => 'required|max:255',
            'delivery_date' => 'required',
            //'cost' => 'required',
           // 'status' => 'required',
           // 'deliverer' => 'max:255',
            'delivery_address' => 'max:255',
        ];
        } else {
            return [];
        }
    }

    public function messages() {
        return [
            'manager.required' => 'Поле менеджер обязательно для заполнения',
            'send_date.required' => 'Поле "Дата приема" обязательно',
            'code.required' => 'Поле "Номер накладной" обязательно',
            'package_id.required' => 'Поле "Номер отправления" обязательно',
            'company_cod.required' => 'Поле "Номер накладной (Компании)" обязательно',
            'company_sender_name.required' => 'Поле "Отправитель (Компания)" обязательно',
            'company_recipient_name.required' => 'Поле "Получатель (Компания)" обязательно',
            'sender_city.required' => 'Поле "Город отправителя" обязательно',
            'recipient_city.required' => 'Поле "Город получателя" обязательно',
            'places.required' => 'Поле "Кол-во мест" обязательно',
            'weight.required' => 'Поле "Вес" обязательно',
            'kind.required' => 'Поле "Вид отправления" обязательно',
            'priority.required' => 'Поле "Важность" обязательно',
            'cost.required' => 'Поле "Цена" обязательно',
            'delivery_date.required' => 'Поле "Дата доставки" обязательно',
            'recipient.required' => 'Поле "ФИО Получателя" обязательно'
        ];
    }

}
