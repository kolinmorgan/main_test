<?php

/*
  |--------------------------------------------------------------------------
  | Application Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register all of the routes for an application.
  | It's a breeze. Simply tell Laravel the URIs it should respond to
  | and give it the controller to call when that URI is requested.
  |
 */

Route::get('/', 'HomeController@index')->name('index');
Route::get('{page}', 'HomeController@staticPage')->where('page', "about-us|additional-services|clients|contacts|courier-service|transportation-services|warehousing-services");

Route::get('login', 'Auth\AuthController@getLogin');
Route::post('login', 'Auth\AuthController@postLogin');
Route::get('logout', 'Auth\AuthController@logout');


Route::get('register', 'Auth\AuthController@getRegister');
Route::post('register', 'Auth\AuthController@postRegister');


Route::get('password/reset', 'Auth\PasswordController@getEmail');
Route::post('password/email', 'Auth\PasswordController@postEmail');
Route::get('password/reset/{token}', 'Auth\PasswordController@getReset');
Route::post('password/reset', 'Auth\PasswordController@postReset');



Route::get('orders/create', 'Frontend\OrdersController@create');


Route::post('ascdeliverer', 'Frontend\CallBackController@ascDeliverer')->name('ascdeliverer');
Route::post('callback', 'Frontend\CallBackController@backCall')->name('callback');
Route::post('mail', 'Frontend\CallBackController@mail')->name('mail');

Route::post('waybills/search', 'Frontend\OrdersController@search')->name('waybills.search');




Route::group(['middleware' => ['auth', 'role:user'], 'prefix' => 'cabinet'], function () {
    Route::resource('waybills', 'Cabinet\WaybillController', ['only' => ['index']]);
});



Route::group(['middleware' => ['auth', 'role:admin'], 'prefix' => 'cabinet'], function () {

    Route::get('waybills/{id}/move', 'Cabinet\WaybillController@move')->name('cabinet.waybills.move');
    Route::resource('waybills', 'Cabinet\WaybillController', [ 'only' => ['destroy']]);

    Route::get('waybills/export', 'Cabinet\ExportController@exel');

    Route::controller('users', 'Cabinet\UsersController');
});

Route::get('waybills/print', 'Cabinet\PrintController@excel');

Route::group(['middleware' => ['auth', 'role:manager'], 'prefix' => 'cabinet'], function () {

    Route::resource('locations', 'Cabinet\LocationsController');
    Route::resource('sortcenters', 'Cabinet\SortCenterController');
    Route::resource('companies', 'Cabinet\CompaniesController');
        Route::controller('rates', 'Cabinet\RateController');
    Route::resource('waybills', 'Cabinet\WaybillController', ['only' => ['create', 'store', 'update', 'edit']]);
    

    Route::controller('couriers', 'Cabinet\CourierController');
    
    
    Route::controller('report', 'Cabinet\ReportController');
     Route::controller('calculator', 'Cabinet\CalculatorController');
     
});

Route::get('cabinet/companies/meta/{id}', 'Cabinet\CompaniesController@getMeta');

Route::get('waybills/{code}', 'Frontend\OrdersController@show')->name('waybills.show');

Route::get('/cabibet/waybills/{code}', 'Cabinet\WaybillController@show')->name('cabinet.waybills.show');



Route::group(['prefix' => 'api'], function() {
    Route::get('auth', 'API\AuthController@authenticate');
    Route::post('auth-test', 'API\AuthController@authtest');
    Route::get('auth/success', 'API\AuthController@success');
    Route::get('auth/user', 'API\AuthController@getAuthenticatedUser');

    Route::post('waybills/status', 'API\WaybillController@updateStatus');
    
    Route::post('waybills/code_update', 'API\WaybillController@updateCode');
    
    Route::get('webkassa/check', 'API\WebKassaController@getCheck');
    
    Route::get('waybills/active', 'API\WaybillController@active');
    Route::get('waybills/history', 'API\WaybillController@history');
    Route::post('waybills/create', 'API\WaybillController@create');
    Route::get('waybills/{id}', 'API\WaybillController@show');

    Route::get('user', 'API\UserController@index');
    Route::post('user', 'API\UserController@update');
    Route::get('couriers', 'API\UserController@couriers');
    Route::get('user/companies', 'API\UserController@companies');
    Route::post('webkassa', 'API\WebKassaController@postIndex');
});

Route::group(['prefix' => 'webapi', 'middleware' => ['WebAPI']], function() { 
    Route::controller('rates', 'WebAPI\RatesController');
    Route::controller('waybills', 'WebAPI\WaybillController');
});

Route::group(['prefix' => 'webapi2', 'middleware' => ['WebAPI']], function() { 
    Route::controller('rates', 'WebAPI2\RatesController');
    Route::controller('waybills', 'WebAPI2\WaybillController');
});

// BankApi
Route::group(['prefix' => 'bankapi', 'middleware' => ['WebAPI']], function() {
	Route::post('waybills/create', 'API\BankApiController@createWaybill');
	Route::get('waybills/status_list', 'API\BankApiController@getWaybillsStatusList');
	Route::get('waybills/status', 'API\BankApiController@getWaybillStatus');
	Route::post('waybills/status_update', 'API\BankApiController@updateWaybillStatus');
	Route::get('waybills/get_file', 'API\BankApiController@getFile');
});

//Route::get('test', 'API\WebKassaController@test');
/*
Route::get('test', function() {
    
$fixed_serialized_data = preg_replace_callback ( '!s:(\d+):"(.*?)";!',
    function($match) {
        return ($match[1] == strlen($match[2])) ? $match[0] : 's:' . strlen($match[2]) . ':"' . $match[2] . '";';
    },
'a:3:{s:6:"status";s:7:"success";s:7:"message";s:0:"";s:4:"data";a:7:{s:10:"total_cost";d:500;s:12:"total_weight";i:0;s:12:"payment_type";s:16:"наличный";s:11:"payment_sum";i:0;s:4:"from";O:29:"Illuminate\Support\Collection":1:{s:8:"*items";a:1:{i:0;a:8:{s:5:"count";s:1:"1";s:7:"product";s:30:"Кружка ФК Кайрат";s:4:"city";s:12:"Алматы";s:6:"weight";s:1:"0";s:5:"price";s:4:"1000";s:5:"phone";s:0:"";s:4:"name";s:55:"Официальный магазин ФК КАЙРАТ";s:7:"address";s:0:"";}}}s:2:"to";a:5:{s:5:"phone";s:11:"77089275328";s:7:"address";s:57:"ул. Тажибаевой 155, БЦ «Pine Office Park»";s:4:"name";s:37:"Кашкынбаева Каракат";s:4:"city";s:12:"Алматы";s:4:"cost";d:500;}s:4:"type";s:8:"standart";}}' );

    
    $data = unserialize($fixed_serialized_data);
    
    $from = [];
    $from[0] = [
   "count" => "1",
          "product" => "Трусики Sweety Pantz Gold M34 (7-12кг)",
          "city" => "Алматы",
          "weight" => "0",
          "price" => "2800",
          "phone" => "77089275328",
          "name" => "bebek_almaty",
          "address" => ""
    ];
    
    
    $data['data']['from'] = collect($from);
    \App\Models\Waybill::where('id','86244')->update(['api_request' =>serialize($data)]);

   

});

*/
