<?php

namespace App\Http\Controllers\Frontend;

use App\User;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App\Http\Requests;

use App\Http\Requests\OrderCreateRequest;
use App\Http\Requests\OrderUpdateRequest;
use Flash;

use App\Models\Waybill;

class OrdersController extends Controller
{



    public function create()
    {

        return view('frontend.orders.create');
    }

    public function store(OrderCreateRequest $request)
    {

        try {

      

            $order = Waybill::create($request->all());

            $response = [
                'message' => 'Order created.',
                'data'    => $order->toArray(),
            ];

            if ($request->wantsJson()) {

                return response()->json($response);
            }

            return redirect()->back()->with('message', $response['message']);
        } catch (ValidatorException $e) {
            if ($request->wantsJson()) {
                return response()->json([
                    'error'   => true,
                    'message' => $e->getMessageBag()
                ]);
            }

            return redirect()->back()->withErrors($e->getMessageBag())->withInput();
        }
    }

      public function search(Request $request) {
        $code = $request->get('code');
        $waybill = WayBill::where('code', '=', $code)->first();
        if (empty($waybill)) {
            Flash::error('Накладная не найдена');
            return \Redirect::back();
        }
        return \Redirect::route('waybills.show', ['code' => $code]);
    }
    
   public function show($code) {
        $waybill = Waybill::with('user')->where('code',$code)->first();

        if (empty($waybill)) {
            Flash::error('waybill not found');
            return redirect(route('waybills.index'));
        }

        return view('frontend.waybills.show')->with('waybill', $waybill);
    }

}
