<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Http\Requests;

use App\Models\Waybill;
use Illuminate\Http\Request;
use Mail;
use Flash;

class CallBackController extends Controller {

    public function backCall(Request $request) {
        $this->validateWithBag('CallBack', $request, [
            'CallBack.name' => 'required',
            'CallBack.phone' => 'required',
            'CallBack.email' => 'required',
            'CallBack.subject' => 'required',
            'CallBack.text' => 'required',
                ], [
            'CallBack.name.required' => 'Укажите ваше имя',
            'CallBack.phone.required' => 'Укажите ваш телефон',
            'CallBack.email.required' => 'Укажите ваш email ',
            'CallBack.subject.required' => 'Укажите тему',
            'CallBack.text.required' => 'Укажите сообщение',
        ]);
        try {
            Mail::send('emails.callback', ['сallBack' => $request->get('CallBack')], function ($m) use ($request) {
                $from = \Config::get('mail.from');
                $to = \Config::get('mail.from');
                $m->from($from['address'], $from['name']);

                $m->to($to['address'], $to['name'])->subject('Обратный звонок');
            });
        } catch (\Exception $e) {
            \Log::error($e);
        }
         Flash::overlay('Менеджер свяжется с вами в ближайшее время','Благодарим за обращение');
        return \Redirect::back();
    }

    public function ascDeliverer(Request $request) {
        $this->validate($request, [
            'CurierForm.name' => 'required',
            'CurierForm.phone' => 'required',
            'CurierForm.adress' => 'required',
            'CurierForm.country' => 'required',
            'CurierForm.when' => 'required',
            'CurierForm.weight' => 'required',
                ], [
            'CurierForm.name.required' => 'Укажите имя отправителя',
            'CurierForm.phone.required' => 'Укажите контактный телефон',
            'CurierForm.adress.required' => 'Укажите адрес',
            'CurierForm.country.required' => 'Укажите город',
            'CurierForm.when.required' => 'Укажите когда необходимо забрать',
            'CurierForm.weight.required' => 'Укажите вес',
        ]);
        try {
            Mail::send('emails.ask_deliverer', ['curierForm' => $request->get('CurierForm')], function ($m) use ($request) {
                $from = \Config::get('mail.from');
                $to = \Config::get('mail.from');
                $m->from($from['address'], $from['name']);

                $m->to($to['address'], $to['name'])->subject('Заказ курьера');
            });
        } catch (\Exception $e) {
            \Log::error($e);
        }
        Flash::overlay('Менеджер свяжется с вами в ближайшее время','Благодарим за обращение');
        return \Redirect::back();
    }

    public function mail(Request $request) {
        $this->validate($request, [
            'ContactForm.name' => 'required',
            'ContactForm.email' => 'required',
            'ContactForm.subject' => 'required',
            'ContactForm.body' => 'required',
                ], [
            'ContactForm.name.required' => 'Укажите ваше имя',
            'ContactForm.email.required' => 'Укажите ваш email ',
            'ContactForm.subject.required' => 'Укажите тему',
            'ContactForm.body.required' => 'Укажите сообщение',
        ]);
        try {
            Mail::send('emails.mail', ['contactForm' => $request->get('ContactForm')], function ($m) use ($request) {
                $from = \Config::get('mail.from');
                $to = \Config::get('mail.from');
                $m->from($from['address'], $from['name']);

                $m->to($to['address'], $to['name'])->subject('Форма контактов');
            });
        } catch (\Exception $e) {
            \Log::error($e);
        }
         Flash::overlay('Менеджер свяжется с вами в ближайшее время','Благодарим за обращение');
        return \Redirect::back();
    }

}
