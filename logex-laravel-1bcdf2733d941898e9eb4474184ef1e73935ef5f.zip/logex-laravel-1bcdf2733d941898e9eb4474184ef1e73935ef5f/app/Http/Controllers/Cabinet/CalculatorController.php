<?php

namespace App\Http\Controllers\Cabinet;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\CalculatorRates;
use App\Models\CalculatorZones;
use App\Models\Company;
use App\Models\Location;


class CalculatorController extends Controller {


    public function getIndex(Request $request) {

        $rates =  CalculatorRates::get();
        
  
        return view('cabinet.calculator.index', compact('rates'));
    }
    
    public function getCreate() {
        
        return view('cabinet.calculator.create');
    }
    
    public function postCreate(Request $request) {
       
        
        
        CalculatorRates::insert(['name' => $request->get('name'), 'data' => json_encode($request->get('rates'))]);
        
        return redirect('/cabinet/calculator');
        
        
    }
    
    public function postCompanies(Request $request) {
        $companies = $request->get('company_id');
        
        $rate_id = $request->get('rate_id');
        
        foreach ($companies as $company) {
            \App\Models\Company::find($company)->update(['rate_id' => $rate_id]);
        }
        
        return redirect('/cabinet/calculator');
    }
    
    public function getEdit($id, Request $request) {
        
        $rate = CalculatorRates::find($id);
        
        return view('cabinet.calculator.edit', compact('rate'));
        
    }
    
     public function postEdit($id, Request $request) {
        
                
        CalculatorRates::find($id)->update(['name' => $request->get('name'), 'data' => json_encode($request->get('rates'))]);
        
        return redirect('/cabinet/calculator');
        
        
    }
    
    
    public function getZones() {
        $cities = \App\Models\Location::get();
        
        $zones = CalculatorZones::with('city_from','city_to')->get();
   
        return view('cabinet.calculator.zones', compact('cities', 'zones'));
    }
    
    public function postZones(Request $request) {
        
        CalculatorZones::insert(['from_id' => $request->get('from_id'), 'to_id' => $request->get('to_id'), 'zone' => $request->get('zone')]);
        return redirect('/cabinet/calculator/zones');
    }
    
    
    public function postCalc(Request $request) {
        
      //  dd($request->all());
        
        if($request->get('weight') == '') {
             return response()->json(['status'=> 'failed']);
        }
        
        $weight =floatval(str_replace(',', '.', $request->get('weight')));;
        $company = Company::find($request->get('company_sender_id'));
        
       // dd($company);
        if($company->rate_id == '') {
            return response()->json(['status'=> 'failed']);
        }
        
       $rates = CalculatorRates::find($company->rate_id);
       
       $rates = $rates->rates;
      // dd($rates);
       
       $city_1 = Location::where('name',$request->get('sender_city'))->first();
       $city_2 = Location::where('name',$request->get('recipient_city'))->first();
       
       $zone = CalculatorZones::where(function ($q) use ($city_1, $city_2) {
                $q->where('from_id', $city_1->id)->where('to_id', $city_2->id);
             })->orWhere(function ($q) use ($city_1, $city_2) {
                $q->where('to_id', $city_1->id)->where('from_id', $city_2->id);
             })->first();
           
             if($zone == null) {
                 return response()->json(['status'=> 'failed']);
             }
       
        $zone = $zone->zone;
        
        $price = '';
       if($request->get('priority') == 'Стандарт' && $zone != 0) {
        
           $rates = $rates['standart'];
           foreach([0.5,1,1.5,2,2.5,3,3.5,4,4.5] as $num) {
                  if($weight <= $num) {
                      
                       $num = str_replace('.', ',', $num);
                    $price =  $rates[$num]['zone_'.$zone];
                     break;
                  }
              }
              if($price == '') {
                  if($weight < 10) {
                    $price =  $rates['5-10']['zone_'.$zone];
                  } else {
                  

                  $price =  $rates['5-10']['zone_'.$zone];
       
                  $price += (ceil(($weight-10)/0.5) * $rates['+0,5']['zone_'.$zone]);
                  }
                  
              }
            
       }
       
       if($request->get('priority') == 'Экспресс' || $zone == 0) {
              $rates = $rates['express'];
              foreach([0.3,0.5,1,1.5,2,2.5,3,3.5,4,4.5,5] as $num) {
               
                  if($weight <= $num) {
                   
                      $num = str_replace('.', ',', $num);
                   
                    $price =  $rates[$num]['zone_'.$zone];
                     break;
                  }
              }
              if($price == '') {
                  $price =  $rates['5']['zone_'.$zone];
       
                  $price += (ceil(($weight-5)/0.5) * $rates['+0,5']['zone_'.$zone]);
                  
              }
              
              
           
       }
       
       return response()->json(['status' => 'success', 'price'=>$price]);
      // dd($price);
      // dd($rates);
        
        
    }
    
    public function patchCalc(Request $request) {
        return $this->postCalc($request);
    }
    
}
