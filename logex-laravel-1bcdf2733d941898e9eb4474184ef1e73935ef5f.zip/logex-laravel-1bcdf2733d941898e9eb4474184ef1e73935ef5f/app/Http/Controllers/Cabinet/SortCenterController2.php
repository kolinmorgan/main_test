<?php

namespace App\Http\Controllers\Cabinet;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Flash;
use Auth;
use App\Models\Location;
use App\Models\SortCenter;

class SortCenterController2 extends Controller {


    public function index(Request $request) {

        $centers = SortCenter::with('location')->paginate(20);
     
        return view('cabinet.sortcenters.index', compact('centers'));
    }

    /**
     * Show the form for creating a new waybill.
     *
     * @return Response
     */
    public function create(Request $request) {

        return view('cabinet.sortcenters.create');
    }

    /**
     * Store a newly created waybill in storage.
     *
     * @param CreatewaybillRequest $request
     *
     * @return Response
     */
    public function store(Request $request) {
        $input = $request->all();

        $sortcenter = SortCenter::create($input);

        Flash::success('Сортировочный центр сохранен');

        return redirect(route('cabinet.sortcenters.index'));
    }


    public function edit($id) {
     
        $center = SortCenter::find($id);

        if (empty($center)) {
            Flash::error('sortcenter not found');

            return redirect(route('cabinet.sortcenters.index'));
        }

        return view('cabinet.sortcenters.edit')->with('center', $center);
    }

    /**
     * Update the specified waybill in storage.
     *
     * @param  int              $id
     * @param UpdateWaybillRequest $request
     *
     * @return Response
     */
    public function update($id, Request $request) {
        $location = Location::find($id);

        if (empty($location)) {
            Flash::error('location not found');

            return redirect(route('cabinet.locations.index'));
        }

        $location = Location::find($id)->update($request->all());

        Flash::success('location updated successfully.');

        return redirect(route('cabinet.locations.index'));
    }
    
  

    public function destroy($id) {


        Location::find($id)->delete();

        Flash::success('Локация успешно удалена');

        return redirect(route('cabinet.locations.index'));
    }

  

}
