<?php

namespace App\Http\Controllers\Cabinet;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use Flash;

class UsersController extends Controller
{

    public function getIndex() {
        $users = User::paginate(20);
       
        return view('cabinet.users.index', compact('users'));
    }
    
    public function postUpdate(Request $request) {
        User::find($request->get('user_id'))->update([
            'role' => $request->get('role'),
            'location_id' => $request->get('location_id')]);
       
        User::find($request->get('user_id'))->company()->detach();
        User::find($request->get('user_id'))->company()->attach($request->get('company_id'));
        Flash::success('Пользователь обновлен');
        return redirect('/cabinet/users');
    }
  
}
