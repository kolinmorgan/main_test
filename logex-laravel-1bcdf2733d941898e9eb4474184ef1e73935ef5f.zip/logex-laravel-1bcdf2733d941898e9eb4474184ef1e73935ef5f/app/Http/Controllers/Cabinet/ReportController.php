<?php

namespace App\Http\Controllers\Cabinet;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Flash;
use Auth;
use App\Models\Waybill;

use App\Models\APIKey;

class ReportController extends Controller {


    public function getIndex(Request $request) {

         if (Auth::user()->role == 'manager' || Auth::user()->role == 'admin') {
             
              $company_sender_id = APIKey::first()->company_id;
          //   $waybills = Waybill::where('user_id', 57)->orderBy('id', 'desc')->paginate(50);
              $waybills = Waybill::with('waybills')->where('company_sender_id', $company_sender_id)->orderBy('id', 'desc')->paginate(50);
             
            //  dd($waybills[0]);
             return view('cabinet.report.index', compact('waybills'));
             
         } else {
             return redirect()->back();
         }
     
    }

 

}
