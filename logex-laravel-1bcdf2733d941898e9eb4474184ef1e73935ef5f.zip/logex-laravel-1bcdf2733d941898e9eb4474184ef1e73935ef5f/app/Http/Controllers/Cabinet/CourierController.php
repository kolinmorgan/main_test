<?php

namespace App\Http\Controllers\Cabinet;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\Models\Waybill;
use App\Models\CourierRoute;
use App\Models\SortCenter;
use App\Http\Controllers\IonicController;
use Flash;

class CourierController extends Controller {

    public function getIndex() {
        $users = User::where('role', 'courier')->paginate(20);

        return view('cabinet.courier.index', compact('users'));
    }

    public function postUpdate(Request $request) {
        User::find($request->get('user_id'))->update([
            'role' => $request->get('role'),
            'location_id' => $request->get('location_id')]);

        User::find($request->get('user_id'))->company()->detach();
        User::find($request->get('user_id'))->company()->attach($request->get('company_id'));
        Flash::success('Пользователь обновлен');
        return redirect('/cabinet/couriers');
    }

    public function getAddRoute($id, Request $request) {
        $couriers = User::with('company')->where('role', 'courier')->get();
        
        $waybill = Waybill::where('id', $id)->first();
        $routes = CourierRoute::where('waybill_id', $id)->get();

        $sort_centers = SortCenter::get();

        return view('cabinet.courier.add_route', compact('couriers', 'waybill', 'routes', 'sort_centers'));
    }

    public function postAddRoute($id, Request $request) {


        $waybill = Waybill::find($id);
        $route = [];

        $route['from'] = $request->get('from');
        $route['to'] = $request->get('to');
        if ($request->get('from') == 'client') {
            $route['from_value'] = $waybill->sender_address;
        }

        if ($request->get('from') == 'sort_center') {
            $waybill->update(['status'=>'В доставке']);
            $route['from_value'] = $request->get('from_sort_center');
        }

        if ($request->get('from') == 'custom') {
            $route['from_value'] = $request->get('from_custom');
        }

        if ($request->get('to') == 'client') {
            $route['to_value'] = $waybill->recipient_address;
        }

        if ($request->get('to') == 'sort_center') {
            $route['to_value'] = $request->get('to_sort_center');
        }

        if ($request->get('to') == 'custom') {
            $route['to_value'] = $request->get('to_custom');
        }

        $route['courier_id'] = $request->get('courier_id');
        $route['waybill_id'] = $request->get('waybill_id');
        $route['status'] = 'Новый';
        $route['active'] = 'true';

        CourierRoute::create($route);
        
      IonicController::sendPush([ (string) $request->get('courier_id')], 'Новая доставка');
    }

    public function getRoutes($id) {
        $routes = CourierRoute::where('courier_id', $id)->with('waybill')->orderBy('id','desc')->paginate(100);

        return view('cabinet.courier.routes', compact('routes'));
    }

    
   public function getAddRouteMany(Request $request) {
        $couriers = User::with('company')->where('role', 'courier')->get();
        

        $sort_centers = SortCenter::get();

        return view('cabinet.courier.add_route_many', compact('couriers', 'waybill', 'routes', 'sort_centers'));
    }
}
