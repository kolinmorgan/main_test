<?php

namespace App\Http\Controllers\Cabinet;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\CreatewaybillRequest;
use App\Http\Requests\UpdateWaybillRequest;
use App\Http\Controllers\IonicController;
use App\Models\Waybill;
use App\User;
use App\Models\Location;
use App\Models\Company;
use App\Models\SortCenter;
use App\Models\CourierRoute;
use Flash;
use Response;
use Mail;
use Auth;

class WaybillController extends Controller {

    public function index(Request $request) {
        $waybills = new Waybill();

        if (Auth::user()->role == 'user') {
            $waybills = $waybills->whereIn('company_sender_id', Auth::user()->company->lists('id')->all());
        }

        if (Auth::user()->role == 'manager') {
            $waybills = $waybills->where('user_id', Auth::user()->id);
        }

        if (Auth::user()->role == 'courier') {

            $waybills = $waybills->whereIn('id', CourierRoute::where('courier_id', Auth::user()->id)->lists('waybill_id'))->groupBy('id');
        }


        $searchInput = array();
        /*
          if($request->has('company') && $request->get('company') != '') {
          $waybills = $waybills->where('company_sender_name', 'LIKE', '%'.$request->get('company').'%')
          ->orWhere('company_recipient_name', 'LIKE', '%'.$request->get('company').'%');
          $searchInput['company'] = $request->get('company');
          } */

        if ($request->has('from') && $request->get('from') != '') {
            $waybills = $waybills->where('send_date', '>=', date('Y-m-d', strtotime($request->get('from'))) . ' 00:00');
            $searchInput['from'] = $request->get('from');
        }
        if ($request->has('to') && $request->get('to') != '') {
            $waybills = $waybills->where('send_date', '<=', date('Y-m-d', strtotime($request->get('to'))) . ' 23:59');
            $searchInput['to'] = $request->get('to');
        }

        if ($request->has('company_cod') && $request->get('company_cod') != '') {
            $waybills = $waybills->where('company_cod', 'LIKE', '%' . $request->get('company_cod') . '%')
                    ->orWhere('code', 'LIKE', '%' . $request->get('company_cod') . '%');
            $searchInput['company_cod'] = $request->get('company_cod');
        }


        if ($request->has('company_sender_id') && $request->get('company_sender_id') != '') {
            $waybills = $waybills->where('company_sender_id', $request->get('company_sender_id'));
            $searchInput['company_sender_id'] = $request->get('company_sender_id');
        }


        $not_deliver = [];
        if ($request->has('status') && $request->get('status') != '') {
            $searchInput['status'] = $request->get('status');
            if ($request->get('status') != 'Удалено') {
                $waybills = $waybills->where('status', $request->get('status'));
            } else {
                $waybills = $waybills->onlyTrashed();
            }
        } else {
            if (Auth::user()->role == 'manager') {
                $not_deliver = Waybill::where('status', 'Не доставлено')->where('user_id', Auth::user()->id)->orderBy('id', 'desc')->get();
            } elseif (Auth::user()->role == 'admin') {
                $not_deliver = Waybill::where('status', 'Не доставлено')->orderBy('id', 'desc')->get();
            }
            $waybills = $waybills->where('status', '!=', 'Не доставлено');
        }
        $waybills = $waybills->with('company_sender','waybills')->orderBy('id', 'desc')->paginate(20);


        $company_senders = Company::all();


        $locations = Location::lists('name', 'id');


        $couriers = User::where('role', 'courier')->lists('name', 'id')->toArray();
        $couriers['0'] = 'Нет курьера';

        ksort($couriers);
        return view('cabinet.waybills.index', compact('waybills', 'searchInput', 'company_senders', 'couriers', 'locations', 'not_deliver'));
    }

    /**
     * Show the form for creating a new waybill.
     *
     * @return Response
     */
    public function create(Request $request) {
        if ($request->has('withold')) {
            $oldInput = Waybill::where('user_id', Auth::user()->id)->orderBy('id', 'desc')->first();
            if ($oldInput != null) {
                $oldInput = $oldInput->toArray();
                return redirect('cabinet/waybills/create')->withInput($oldInput);
            }
        }


        return view('cabinet.waybills.create');
    }

    public function store(CreatewaybillRequest $request) {
        $input = $request->all();

        $input['user_id'] = Auth::user()->id;
        $waybill = Waybill::create($input);

        Flash::success('Накладная успешно сохранена');

        return redirect(route('cabinet.waybills.index'));
    }

    public function show($id) {
        $waybill = Waybill::with('user')->where('id', $id)->first();

        if (empty($waybill)) {
            Flash::error('Накладная не найдена');
            return redirect(route('cabinet.waybills.index'));
        }

        return view('cabinet.waybills.show')->with('waybill', $waybill);
    }

    public function edit($id) {
        $waybill = Waybill::where('id', $id)->with('waybills')->first();

        if (empty($waybill)) {
             Flash::error('Накладная не найдена');

            return redirect(route('cabinet.waybills.index'));
        }
 
        $waybill->api_request = unserialize($waybill->api_request);

        return view('cabinet.waybills.edit')->with('waybill', $waybill);
    }

    public function update($id, UpdateWaybillRequest $request) {

        $waybill = Waybill::find($id);

        if (empty($waybill)) {
             Flash::error('Накладная не найдена');

            return redirect(route('cabinet.waybills.index'));
        }
        
    
      
      





        $data = $request->except('_token', '_method');

   
       
         if (isset($data['code']) && Waybill::where('code', $data['code'])->where('id', '!=', $id)->first() != null) {
       
             Flash::error('Данный номер накладной уже занят');

           return back()->withInput();
        }

        
        if (isset($data['send_date']))
            $data['send_date'] = date('Y-m-d', strtotime($data['send_date']));
        if (isset($data['delivery_date']))
            $data['delivery_date'] = date('Y-m-d', strtotime($data['delivery_date']));
        if (isset($data['weight']))
            $data['weight'] = str_replace(',', '.', $data['weight']);

        $notify = false;
           if (isset($data['status']) && $waybill->status != $data['status']) {
               $notify  = true;
           }
        $waybill->update($data);

         if ($notify) {
                \App\Http\Controllers\WebAPI2\DarBazarController::sendStatus($waybill, $request->get('status'));
          }
        Flash::success('Накладная успешно обновлена');

        return redirect(route('cabinet.waybills.index'));
    }

    public function destroy($id, Request $request) {
     
        if ($request->has('delete')) {
            
            $waybill = Waybill::find($id)->delete();
            
            Flash::success('Накладная успешно удалена');
            return redirect(route('cabinet.waybills.index'));
            
        } elseif ($request->has('restore')) {
            
            $waybill = Waybill::withTrashed()->find($id)->restore();
            
            Flash::success('Накладная успешно восстановлена');
            
            return redirect(route('cabinet.waybills.index'));
        }
    }

    /**
     * Move status to next stage
     *
     * @param int $id
     *
     * @return Response
     */
    public function move($id) {
        $weyBill = WayBill::findOrFail((int) $id);
        switch ($weyBill->status) {
            case 'Принят':
                $weyBill->status = 'В доставке';
                break;
            case 'В доставке':
                $weyBill->status = 'Доставлено';
                break;
        }
        $weyBill->save();
        return \Redirect::back();
    }

    /*
      public function courier($id, Request $request) {
      $waybill = Waybill::find($id);

      if (empty($waybill)) {
      Flash::error('waybill not found');

      return redirect(route('cabinet.waybills.index'));
      }

      $waybill = Waybill::find($id)->update($request->all());

      Flash::success('waybill updated successfully.');

      return redirect(route('cabinet.waybills.index'));
      }
     */
}
