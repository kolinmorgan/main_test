<?php

namespace App\Http\Controllers\Cabinet;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Flash;
use Auth;
use App\User;
use App\Models\CourierRoute;

use App\Models\Waybill;
use App\Http\Controllers\IonicController;
use App\Http\Controllers\WebAPI2\DarBazarController;


class SortCenterController extends Controller {

    public function index(Request $request) {

        $routes = CourierRoute::with('waybill')->where('from', 'sort_center')->orWhere('to', 'sort_center')->groupBy('waybill_id')->orderBy('id','desc')->paginate(20);
        //  return view('cabinet.sortcenter.index', compact('routes'));

        
        $couriers = User::where('role', 'courier')->get();
        return view('cabinet.sortcenter.index', compact('couriers', 'routes'));
    }

    public function store(Request $request) {
        //dd($request->all());

        $waybills = preg_split("/\\r\\n|\\r|\\n/", $_POST['waybills']);

        $type = $request->get('type');

        if ($type == 'courier') {
            foreach ($waybills as $id) {
                if($id != '') {
              
                $waybill = Waybill::where('code', $id)->first();
          
                $waybill->update(['status' => 'В доставке']);
                
               
                        DarBazarController::sendStatus($waybill, 'В доставке');
             
                
                
                $route = [];

                $route['from'] = 'sort_center';
                $route['to'] = 'client';
                
                 $route['from_value'] = 1;
                 
                $route['to_value'] = $waybill->recipient_address;
              
                
                $route['courier_id'] = $request->get('courier_id');
                $route['waybill_id'] = $waybill->id;
                
                $route['status'] = 'Новый';

                CourierRoute::create($route);

                IonicController::sendPush([(string) $request->get('courier_id')], 'Новая доставка');
                
                 Flash::success('Накладные успешно отправлены');
                }
            }
        }
        
       if ($type == 'sort') {
            foreach ($waybills as $id) {
                if($id != '') {
              
                $waybill = Waybill::where('code', $id)->first();
                
                //$waybill->update(['status' => 'В обработке']);
                
               
               CourierRoute::where('waybill_id', $waybill->id)->where('courier_id', $request->get('courier_id'))->update(['active' => 'false']);
                
               

                $route['from'] = 'client';
                $route['to'] = 'sort_center';
                
                 $route['from_value'] = $waybill->sender_address;
                 
                $route['to_value'] = 1;
              
                
                $route['courier_id'] = $request->get('courier_id');
                $route['waybill_id'] = $waybill->id;
                
                $route['status'] = 'Новый';
                
                $route['active'] = 'false';

                CourierRoute::create($route);

         
                
                 Flash::success('Накладные успешно приняты');
                }
            }
        }
        
        
        return redirect('/cabinet/sortcenters');
    }

}
