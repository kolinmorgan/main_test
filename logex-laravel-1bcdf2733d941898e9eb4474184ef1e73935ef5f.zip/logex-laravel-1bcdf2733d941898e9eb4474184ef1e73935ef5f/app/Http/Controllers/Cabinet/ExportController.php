<?php

namespace App\Http\Controllers\Cabinet;

use App\Http\Controllers\Controller;
use App\Http\Requests;
use App\Models\Waybill;
use Illuminate\Http\Request;
use Excel;
use Auth;

class ExportController extends Controller {

    public function exel(Request $request) {
    //    dd($request->all());
        $waybills = new Waybill();
        
      if (Auth::user()->role == 'user') {
            $waybills = $waybills->whereIn('company_sender_id', Auth::user()->company->lists('id')->all());
        }

        if (Auth::user()->role == 'manager') {
            $waybills = $waybills->where('user_id', Auth::user()->id);
        }
        
        if (Auth::user()->role == 'courier') {
            
           $waybills = $waybills->whereIn('id',  CourierRoute::where('courier_id',Auth::user()->id)->lists('waybill_id'))->groupBy('id');
        }
        
        if ($request->has('from')) {
            $waybills = $waybills->where('send_date', '>=', date('Y-m-d', strtotime($request->get('from'))). ' 00:00');
        }
        if ($request->has('to')) {
            $waybills = $waybills->where('send_date', '<=', date('Y-m-d', strtotime($request->get('to'))). ' 23:59');
        }

        if ($request->has('company_cod') && $request->get('company_cod') != '') {
            $waybills = $waybills->where('company_cod', 'LIKE', '%' . $request->get('company_cod') . '%')
                    ->orWhere('code', 'LIKE', '%' . $request->get('company_cod') . '%');
            $searchInput['company_cod'] = $request->get('company_cod');
        }


        if ($request->has('company_sender_id') && $request->get('company_sender_id') != '') {
            $waybills = $waybills->where('company_sender_id', $request->get('company_sender_id'));
            $searchInput['company_sender_id'] = $request->get('company_sender_id');
        }

         if ($request->has('status')  && $request->get('status') != '') {
            $waybills = $waybills->where('status', $request->get('status'));
            $searchInput['status'] = $request->get('status');

        }
        
         $waybills = $waybills->orderBy('send_date','asc')->get();

        Excel::create('накладные', function($excel) use ($waybills) {
            $excel->sheet('Накладные', function($sheet) use ($waybills) {
                $sheet->loadView('cabinet.waybills.excel', compact('waybills'));
            });
        })->download('xlsx');
    }

}
