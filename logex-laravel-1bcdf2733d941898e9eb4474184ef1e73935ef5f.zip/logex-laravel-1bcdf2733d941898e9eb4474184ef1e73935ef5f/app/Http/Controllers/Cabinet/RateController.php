<?php

namespace App\Http\Controllers\Cabinet;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Flash;
use Auth;
use App\Models\ZonesRates;

use App\Models\Setting;

class RateController extends Controller {


	public function getIndex(Request $request) {

		$rates = ZonesRates::all()->keyBy('id');
		$page =  \App\Models\Page::orderBy('id','desc')->first();
		return view('cabinet.rates.index', compact('rates', 'page'));
	}


	public function postApiRates(Request $request) {
		$rates = $request->get('rates');
		foreach ($rates as $key => $rate) {
			ZonesRates::find($key)->update($rate);
		}

		$settings = $request->get('settings');
		Setting::where('name', 'commission')->update(['value' => $settings['commission']]);
		Setting::where('name', 'min_products_cost')->update(['value' => $settings['min_products_cost']]);
		return redirect()->back();
	}
  
		public function postPage($id, Request $request) {
			\App\Models\Page::insert(['url' => 'courier-service','text' => $request->get('text')]);
		return redirect()->back();
	}

	public function getRollback() {
		\App\Models\Page::orderBy('id', 'desc')->first()->delete();
		return redirect()->back();
	}

}
