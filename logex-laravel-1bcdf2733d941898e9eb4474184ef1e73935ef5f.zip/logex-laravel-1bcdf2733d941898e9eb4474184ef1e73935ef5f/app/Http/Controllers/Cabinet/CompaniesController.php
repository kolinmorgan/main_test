<?php

namespace App\Http\Controllers\Cabinet;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Flash;
use Auth;
use App\Models\Company;
use App\Models\Location;

class CompaniesController extends Controller {


    public function index(Request $request) {

        $companies = Company::paginate(20);
        return view('cabinet.companies.index', compact('companies'));
    }

    /**
     * Show the form for creating a new waybill.
     *
     * @return Response
     */
    public function create(Request $request) {


        
        return view('cabinet.companies.create');
    }

    /**
     * Store a newly created waybill in storage.
     *
     * @param CreatewaybillRequest $request
     *
     * @return Response
     */
    public function store(Request $request) {
        $input = $request->all();

        Company::create($input);

        Flash::success('company saved successfully.');

        return redirect(route('cabinet.companies.index'));
    }

    /**
     * Display the specified waybill.
     *
     * @param  string $code
     *
     * @return Response
     */

    /**
     * Show the form for editing the specified waybill.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id) {
        $company = Company::find($id);

        if (empty($company)) {
            Flash::error('companies not found');

            return redirect(route('cabinet.companies.index'));
        }

        return view('cabinet.companies.edit')->with('company', $company);
    }

    /**
     * Update the specified waybill in storage.
     *
     * @param  int              $id
     * @param UpdateWaybillRequest $request
     *
     * @return Response
     */
    public function update($id, Request $request) {
        $company = Company::find($id);

        if (empty($company)) {
            Flash::error('location not found');

            return redirect(route('cabinet.companies.index'));
        }

        $company = Company::find($id)->update($request->all());

        Flash::success('company updated successfully.');

        return redirect(route('cabinet.companies.index'));
    }

    /**
     * Remove the specified waybill from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
  

    
    public function getMeta($id) {
        $company = Company::find($id);
   

        
        $meta = ['address' => $company->address,
            'code' => $company->next_code, 
          //  'hasAutoCode' => $company->hasAutoCode
          ];
        
        return json_encode($meta);
    }
}
