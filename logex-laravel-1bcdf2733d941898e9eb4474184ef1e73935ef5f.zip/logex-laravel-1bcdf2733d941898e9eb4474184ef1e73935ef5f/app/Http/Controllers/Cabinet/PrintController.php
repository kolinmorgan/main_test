<?php

namespace App\Http\Controllers\Cabinet;

use App\Http\Controllers\Controller;
use App\Http\Requests;
use App\Models\Waybill;
use Illuminate\Http\Request;
use Excel;

class PrintController extends Controller {

    public function excel(Request $request) {
        //    dd($request->all());


        $waybill = Waybill::find($request->get('id'));

        // dd($waybill);

        Excel::load(storage_path() . '/template.xlsx', function($reader) use ($waybill) {
            $reader->noHeading();

            // dd($reader->getActiveSheet()->getCell('A2')->getCalculatedValue());

            $reader->getActiveSheet()->setCellValue('G2', $waybill->code);
            $reader->getActiveSheet()->setCellValue('A4', 'Ф.И.О.: ' . $waybill->company_sender_name);
            $reader->getActiveSheet()->setCellValue('A5', 'Компания: ' . $waybill->company_sender->name);
            $reader->getActiveSheet()->setCellValue('A6', 'Адрес: ' . $waybill->sender_address);
            $reader->getActiveSheet()->setCellValue('A7', 'Город: ' . $waybill->sender_city);
            //$reader->getActiveSheet()->setCellValue('C6', 'Индекс: '.$waybill->sender_city);
            //$reader->getActiveSheet()->setCellValue('A7', 'Страна: '.$waybill->sender_city);
            $reader->getActiveSheet()->setCellValue('A11', 'Дата: ' . date('d.m.Y', strtotime($waybill->send_date)));
            $reader->getActiveSheet()->setCellValue('C11', 'Время: ' . date('H:i', strtotime($waybill->send_date)));

            
             $reader->getActiveSheet()->setCellValue('A14', 'Количество: ' . $waybill->places);
             
            $reader->getActiveSheet()->setCellValue('A17', 'Конверт: ' . ($waybill->kind == 'конверт' ? 'да' : ''));
            $reader->getActiveSheet()->setCellValue('B17', 'Пакет: ' . ($waybill->kind == 'пакет' ? 'да' : ''));
            $reader->getActiveSheet()->setCellValue('D17', 'Посылка: ' . ($waybill->kind == 'посылка' ? 'да' : ''));
            
            
            $reader->getActiveSheet()->setCellValue('E4', 'Ф.И.О.: ' . $waybill->recipient);
            $reader->getActiveSheet()->setCellValue('E5', 'Компания: ' . $waybill->company_recipient_name);
            $reader->getActiveSheet()->setCellValue('E6', 'Адрес: ' . $waybill->recipient_address);
            $reader->getActiveSheet()->setCellValue('E7', 'Город: ' . $waybill->recipient_city);
        })->download('xlsx');
    }

}
