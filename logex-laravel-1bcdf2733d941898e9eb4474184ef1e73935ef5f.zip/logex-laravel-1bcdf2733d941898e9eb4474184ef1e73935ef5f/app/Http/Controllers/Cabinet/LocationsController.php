<?php

namespace App\Http\Controllers\Cabinet;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Flash;
use Auth;
use App\Models\Location;

class LocationsController extends Controller {


    public function index(Request $request) {

        $locations = Location::paginate(20);
        return view('cabinet.locations.index', compact('locations'));
    }

    /**
     * Show the form for creating a new waybill.
     *
     * @return Response
     */
    public function create(Request $request) {

        return view('cabinet.locations.create');
    }

    /**
     * Store a newly created waybill in storage.
     *
     * @param CreatewaybillRequest $request
     *
     * @return Response
     */
    public function store(Request $request) {
        $input = $request->all();

        $waybill = Location::create($input);

        Flash::success('location saved successfully.');

        return redirect(route('cabinet.locations.index'));
    }

    /**
     * Display the specified waybill.
     *
     * @param  string $code
     *
     * @return Response
     */
    public function show($code) {
        $waybill = Waybill::with('user')->where('code',$code)->first();

        if (empty($waybill)) {
            Flash::error('waybill not found');
            return redirect(route('waybills.index'));
        }

        return view('cabinet.waybills.show')->with('waybill', $waybill);
    }

    /**
     * Show the form for editing the specified waybill.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id) {
        $location= Location::find($id);

        if (empty($location)) {
            Flash::error('location not found');

            return redirect(route('cabinet.locations.index'));
        }

        return view('cabinet.locations.edit')->with('location', $location);
    }

    /**
     * Update the specified waybill in storage.
     *
     * @param  int              $id
     * @param UpdateWaybillRequest $request
     *
     * @return Response
     */
    public function update($id, Request $request) {
        $location = Location::find($id);

        if (empty($location)) {
            Flash::error('location not found');

            return redirect(route('cabinet.locations.index'));
        }

        $location = Location::find($id)->update($request->all());

        Flash::success('location updated successfully.');

        return redirect(route('cabinet.locations.index'));
    }
    
  

    public function destroy($id) {


        Location::find($id)->delete();

        Flash::success('Локация успешно удалена');

        return redirect(route('cabinet.locations.index'));
    }

  

}
