<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\Models\Location;
use Response;

use App\Http\Controllers\API\WebKassaController;


class UserController extends Controller {

    public function index(Request $request) {


        $user = User::find($request->get('user_id'));

        $locations = Location::orderBY('name')->get();
        $user->locations = $locations;

        return $user->toJson();
    }

    public function update(Request $request) {
        $user = User::find($request->get('user_id'))->update([
            'company_name' => $request->get('company_name'),
            'name' => $request->get('name'),
            'location_id' => $request->get('location_id'),
            'webkassa_login' => $request->get('webkassa_login'),
            'webkassa_password' => $request->get('webkassa_password'),
            'webkassa_id' => $request->get('webkassa_id'),
        ]);
        if($request->has('webkassa_login') && $request->has('webkassa_password')) {
            $u = User::find($request->get('user_id'));
            return WebKassaController::auth($u);
        } else {
            return '';
        }
        
    }
    
    public function couriers() {
       return User::where('role', 'courier')->get()->toJson();
    }
    
   
    public function companies(Request $request) {


        $user = User::with('company')->where('id',($request->get('user_id')))->first();

        

        return $user->company->toJson();
    }

}
