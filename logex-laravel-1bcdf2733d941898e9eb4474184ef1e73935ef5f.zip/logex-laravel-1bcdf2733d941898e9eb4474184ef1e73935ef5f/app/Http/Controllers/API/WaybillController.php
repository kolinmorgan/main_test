<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\CreatewaybillRequest;
use App\Http\Requests\UpdateWaybillRequest;
use App\Http\Controllers\IonicController;
use App\Models\Waybill;
use App\Models\CourierRoute;
use App\User;
use Flash;
use Response;
use Mail;
use Auth;
use JWTAuth;
use App\Http\Controllers\WebAPI2\DarBazarController;

class WaybillController extends Controller {
    /*
      public function __construct() {
      $this->middleware('jwt.auth');
      }
     */

    public function active(Request $request) {


        $user = User::where('id', $request->get('user_id'))->first();
        if ($user->role == 'courier') {
            $routes = CourierRoute::with('waybill.company_sender')->where('courier_id', $request->get('user_id'))->whereHas('waybill', function ($query) {
                        $query->whereIn('status', ['Новая', 'В доставке', 'Забор осуществлён', 'В обработке', 'Возврат', 'Частичный возврат']);
                    })->where('active', 'true')->orderBy('id', 'desc')->groupBy('waybill_id')->paginate(20);


            return Response::json($this->transformCollection($routes), 200);
        }
    }

    public function history(Request $request) {

        $user = User::where('id', $request->get('user_id'))->first();
        if ($user->role == 'courier') {
            $routes = CourierRoute::with('waybill', 'waybill.company_sender')->where('courier_id', $request->get('user_id'))->whereHas('waybill', function ($query) {
                        $query->whereIn('status', ['Доставлено']);
                    })->orWhere('active', 'false')->orderBy('id', 'desc')->groupBy('waybill_id')->paginate(20);



            return Response::json($this->transformCollection($routes), 200);
        }
    }

    public function show(Request $request, $id) {


        $route = CourierRoute::where('id', $id)->with('waybill', 'waybill.company_sender')->first();

        $route['waybill']['commision'] = $route->waybill->commission;

        $route['couriers'] = User::where('role', 'courier')->get()->toArray();

        $route['courier_status'] = $route['status'];

      //  $route['courier_status_text'] = 'Забрать: (' . $route['from_text'] . ') ' . $route['from_value_text'] . '. Доставить (' . $route['to_text'] . ') ' . $route['to_value_text'];
        
        $route['courier_status_text'] = 'Забрать: ' . $route['from_text'] . '. Доставить ' . $route['to_text'];
        switch ($route['waybill']['status']) {
            case 'Принят':
                $route['status_color'] = 'energized';
                break;
            case 'В доставке':
                $route['status_color'] = 'energized';
                break;
            case 'Забор осуществлён':
                $route['status_color'] = 'energized';
                break;
            case 'Доставлено':
                $route['status_color'] = 'balanced';
                break;
            case 'Возврат':
                $route['status_color'] = 'assertive';
                break;
            case 'Частичный возврат':
                $route['status_color'] = 'assertive';
                break;
            case 'Возврат в сортировочный центр':
                $route['status_color'] = 'assertive';
                break;
            default: $route['status_color'] = 'dark';
        }

        $route['waybill']['api_request'] = unserialize($route['waybill']['api_request']);
        return $route->toJson();
    }

    private function transformCollection($routes) {

        $routesArray = $routes->toArray();

//dd($routesArray);
        foreach ($routesArray['data'] as $key => $route) {

            //    $waybillsArray['data'][$key]['delivery_date'] = date('d.m.Y', strtotime($waybillsArray['data'][$key]['delivery_date']));
            //    $waybillsArray['data'][$key]['delivery_time'] = date('H:i', strtotime($waybillsArray['data'][$key]['delivery_time']));

            $routesArray['data'][$key]['courier_status'] = $route['status'];
            $routesArray['data'][$key]['courier_status_text'] = 'Забрать: (' . $route['from_text'] . ') ' . $route['from_value_text'] . '. Доставить (' . $route['to_text'] . ') ' . $route['to_value_text'];


            switch ($route['status']) {
                case 'Принят':
                    $routesArray['data'][$key]['status_color'] = 'energized';
                    break;
                case 'В доставке':
                    $routesArray['data'][$key]['status_color'] = 'energized';
                    break;
                case 'Забор осуществлён':
                    $routesArray['data'][$key]['status_color'] = 'energized';
                    break;
                case 'Доставлено':
                    $routesArray['data'][$key]['status_color'] = 'balanced';
                    break;
                case 'Не доставлено':
                    $routesArray['data'][$key]['status_color'] = 'assertive';
                    break;
                case 'Возврат':
                    $routesArray['data'][$key]['status_color'] = 'assertive';
                    break;
                case 'Частичный возврат':
                    $routesArray['data'][$key]['status_color'] = 'assertive';
                    break;
                case 'Возврат в сортировочный центр':
                    $routesArray['data'][$key]['status_color'] = 'assertive';
                    break;
                default: $routesArray['data'][$key]['status_color'] = 'dark';
            }
        }

        return [
            'total' => $routesArray['total'],
            'per_page' => intval($routesArray['per_page']),
            'current_page' => $routesArray['current_page'],
            'last_page' => $routesArray['last_page'],
            'next_page_url' => $routesArray['next_page_url'],
            'prev_page_url' => $routesArray['prev_page_url'],
            'from' => $routesArray['from'],
            'to' => $routesArray['to'],
            //     'data' => array_map([$this, 'transform'], $waybillsArray['data'])
            'data' => $routesArray['data']
        ];
    }

    private function transform($waybill) {
        return [
            'delivery_date' => date('d.m.Y', strtotime($waybill['delivery_date'])),
            'delivery_time' => date('H:i', strtotime($waybill['delivery_time'])),
        ];
    }

    public function updateStatus(Request $request) {


        $ids = $request->get('ids');

        foreach ($ids as $id) {

            $route = CourierRoute::find($id);

            if ($request->status == 'Доставлено') {

                if (!$request->has('recipient') || $request->get('recipient') == '') {

                    abort(500);
                } else {
                    /*
                      $route->update(
                      [
                      'status' => $request->get('status'),
                      ]
                      );
                     * 
                     */

                    Waybill::where('id', $route->waybill_id)->update(
                            [
                                'recipient' => $request->get('recipient'),
                                'delivery_date' => date('Y-m-d'),
                                'delivery_time' => date('H:i:s'),
                                'status' => 'Доставлено'
                            ]
                    );

                    $ww = Waybill::find($route->waybill_id);
                    
                        DarBazarController::sendStatus($ww, 'Доставлено');
                    
                }

                /*
                  $ww = Waybill::find($route->waybill_id);
                  if ($ww->user_id == 57) {
                  DarBazarController::sendStatus($ww->darbazar_id, 'Доставлено');
                  }
                 * 
                 */
            }
            if ($request->status == 'Передано другому курьеру') {

                CourierRoute::find($id)->update(
                        [
                            'status' => 'Передано другому курьеру',
                            'to' => 'courier',
                            'to_value' => $request->get('to_courier_id'),
                            'active' => 'false'
                        ]
                );
                
             //   $route->update(['active' => 'false']);
                CourierRoute::where('waybill_id', $route->waybill_id)->where('courier_id', $route->courier_id)->update(['active' => 'false']);

                CourierRoute::create([
                    'from' => 'courier',
                    'from_value' => $route->courier_id,
                    'waybill_id' => $route->waybill_id,
                    'status' => 'Получено от другого курьера',
                    'to' => $route->to,
                    'to_value' => $route->to_value,
                    'courier_id' => $request->get('to_courier_id'),
                    'active' => 'true'
                ]);

                CourierRoute::where('id', '>', $id)->where('waybill_id', $route->waybill_id)->update(['courier_id' => $request->get('to_courier_id')]);

                IonicController::sendPush([(string) $request->get('to_courier_id')], 'Новая доставка');
            }
            if ($request->status == 'Возврат в сортировочный центр') {

                
                CourierRoute::create([
                    'from' => 'courier',
                    'from_value' => $route->courier_id,
                    'waybill_id' => $route->waybill_id,
                    'status' => 'Возврат в сортировочный центр',
                    'courier_id' => $route->courier_id,
                    'to' => 'sort_center',
                    'to_value' => 1,
                    'active' => 'false'
                ]);
              //  $route->update(['active' => 'false']);
                  CourierRoute::where('waybill_id', $route->waybill_id)->where('courier_id', $route->courier_id)->update(['active' => 'false']);

                //CourierRoute::where('id', $id)->delete();
            }
            
            if ($request->status == 'Частичный возврат') {

                    Waybill::where('id', $route->waybill_id)->update(
                            [
                                'return_reason' => $request->get('reason'),
                                'recipient' => $request->get('recipient'),
                                'delivery_date' => date('Y-m-d'),
                                'delivery_time' => date('H:i:s'),
                                'status' => $request->status
                            ]
                    );
            }
            
            if ($request->status == 'Возврат') {

                    Waybill::where('id', $route->waybill_id)->update(
                            [
                                'return_reason' => $request->get('reason'),
                                'status' => $request->status
                            ]
                    );
            }


            if ($request->status != 'Возврат в сортировочный центр' && $request->status != 'Передано другому курьеру') {

                             $ww = Waybill::find($route->waybill_id);
                
                    DarBazarController::sendStatus($ww, $request->status);
                    
                Waybill::where('id', $route->waybill_id)->update(['status' => $request->status]);

   
                
            }
        }
    }

    public function create(Request $request) {
        $waybill = $request->all();

        if (Waybill::where('code', $waybill['code'])->first() == null) {
            $waybill = Waybill::create($waybill);

            $route = [];

            $route['from'] = 'client';
            $route['to'] = 'client';

            $route['courier_id'] = $waybill->user_id;
            $route['waybill_id'] = $waybill->id;
            $route['status'] = 'Новый';

            CourierRoute::create($route);
        } else {
            abort(400);
        }
    }
    
    
    public function updateCode(Request $request) { 
        $waybill_id = $request->get('id');
        
        $code = $request->get('code');
        
        if(Waybill::where('code', $code)->first() == null) {
                
            Waybill::find($waybill_id)->update(['code' => $code]);
        } else {
            abort(500);
        }
        
        
    }

}
