<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Validator;
use App\Http\Controllers\Controller;
use App\Models\APIKey;
use App\Models\Waybill;
use App\Models\WaybillFile;

class BankApiController extends Controller
{
	/**
	 * Create a waybill.
	 *
	 * @param \Illuminate\Http\Request $request
	 * @return \Illuminate\Http\Response
	 */
	public function createWaybill(Request $request)
	{
		$validator = Validator::make($request->all(), [
			'id' => 'required|max:255',
			'name' => 'required|max:255',
			'city' => 'required|max:255',
			'address' => 'required|max:255',
			'phone' => 'required|max:255'
		]);

		if ($validator->fails()) {
			return response()
					->json(['status' => 'error', 'message' => 'Internal server error'], 500)
					->withHeaders([
						'Access-Control-Allow-Origin' => '*',
						'Access-Control-Allow-Methods' => 'POST, GET, PUT, DELETE, OPTIONS',
						'Access-Control-Allow-Headers' => 'X-Requested-With, content-type'
					]);
		}

		$api_key = APIKey::where('key', $request->api_key)->first();

		$waybill = Waybill::create([
			'code' => $request->id,
			'recipient' => $request->name,
			'recipient_city' => $request->city,
			'recipient_address' => $request->address,
			'recipient_phone' => $request->phone,
			'company_sender_id' => $api_key->company_id,
			'user_id' => $api_key->user_id,
			'description' => 'Заказ Альфабанк'
		]);

		$data = [
			'status' => 'success',
			'waybill_id' => $waybill->id
		];

		return response()
				->json($data)
				->withHeaders([
					'Access-Control-Allow-Origin' => '*',
					'Access-Control-Allow-Methods' => 'POST, GET, PUT, DELETE, OPTIONS',
					'Access-Control-Allow-Headers' => 'X-Requested-With, content-type'
				]);
	}

	/**
	 * Get a waybills status list.
	 *
	 * @param \Illuminate\Http\Request $request
	 * @return \Illuminate\Http\Response
	 */
	public function getWaybillsStatusList(Request $request)
	{
		$api_key = APIKey::where('key', $request->api_key)->first();
		$waybills = Waybill::select('id', 'code', 'status')->where('user_id', $api_key->user_id)->get();

		$data = [
			'status' => 'success',
			'data' => $waybills
		];

		return response()->json($data);
	}

	/**
	 * Getting the status of a waybill.
	 *
	 * @param \Illuminate\Http\Request $request
	 * @return \Illuminate\Http\Response
	 */
	public function getWaybillStatus(Request $request)
	{
		$this->validate($request, [
			'waybill_id' => 'required|integer'
		]);

		$api_key = APIKey::where('key', $request->api_key)->first();
		$waybill = Waybill::where('id', $request->waybill_id)->where('user_id', $api_key->user_id)->first();

		if (empty($waybill)) {
			return response()->json(['status' => 'error', 'message' => 'Waybill not found'], 500);
		}

		$data = [
			'status' => 'success',
			'data' => [
				'id' => $waybill->id,
				'status' => $waybill->status,
				'status_name' => $waybill->status_name,
				'send_date' => strtotime($waybill->send_date),
				'delivery_date' => strtotime($waybill->delivery_date),
				'documents' => $waybill->files()->select('id', 'filename', 'mimetype', 'created_at')->get(),
				'created_at' => strtotime($waybill->created_at),
				'updated_at' => strtotime($waybill->updated_at)
			]
		];

		return response()->json($data);
	}

	/**
	 * Updating the status of the waybill.
	 *
	 * @param \Illuminate\Http\Request $request
	 * @return \Illuminate\Http\Response
	 */
	public function updateWaybillStatus(Request $request)
	{
		$this->validate($request, [
			'waybill_id' => 'required|integer',
			'status' => 'required|max:255'
		]);

		$api_key = APIKey::where('key', $request->api_key)->first();
		$waybill = Waybill::where('id', $request->waybill_id)->where('user_id', $api_key->user_id)->first();

		if (empty($waybill)) {
			return response()->json(['status' => 'error', 'message' => 'Waybill not found'], 500);
		}

		$waybill->update([
			'status' => $request->status,
			'return_reason' => $request->return_reason
		]);

		if (!empty($request->documents)) {
			foreach ($request->documents as $key => $file) {
				$filename = $waybill->id . '_' . $key . '_' . $file['filename'];

				Storage::disk('local')->put('waybill_images/' . $filename, base64_decode($file['file_encode']));

				$files[] = new WaybillFile([
					'filename' => $filename,
					'mimetype' => $file['mimetype']
				]);
			}

			if (!empty($files)) {
				$waybill->files()->saveMany($files);
			}
		}

		$data = [
			'status' => 'success',
			'waybill_id' => $waybill->id
		];

		return response()->json($data);
	}

	/**
	 * Get file by id.
	 *
	 * @param \Illuminate\Http\Request $request
	 * @return \Illuminate\Http\Response
	 */
	public function getFile(Request $request)
	{
		$api_key = APIKey::where('key', $request->api_key)->first();
		$user_id = $api_key->user_id;

		$file = WaybillFile::where('id', $request->id)
					->whereHas('waybill', function($query) use ($user_id) {
						$query->where('user_id', $user_id);
					})->first();

		if (empty($file)) {
			return response()->json(['status' => 'error', 'message' => 'File not found'], 500);
		}

		$file_encode = base64_encode(Storage::disk('local')->get('waybill_images/' . $file->filename));

		$data = [
			'status' => 'success',
			'filename' => $file->filename,
			'mimetype' => $file->mimetype,
			'file_encode' => $file_encode
		];

		return response()->json($data);
	}
}