<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use JWTAuth;
use Auth;
use Tymon\JWTAuth\Exceptions\JWTException;

class AuthController extends Controller {

    public function __construct() {
        $this->middleware('jwt.auth', ['except' => ['authenticate', 'authtest']]);
    }


    public function authtest(Request $request) {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            return response('true', 200);
        } else {
            return response('Проверьте правильность логина и пароля', 401);
        }
    }

    public function authenticate(Request $request) {


        $credentials = JWTAuth::parseToken()->getPayload()['data'];



        // $credentials = $request->only('email', 'password');

        if (!$user = \Auth::attempt($credentials)) {
            return response()->json(['error' => 'invalid_credentials'], 401);
        }

        $token = JWTAuth::fromUser(\Auth::user(), ['user_id' => (string) \Auth::user()->id]);

        // dd(JWTAuth::getPayload($token));
        //  $user = JWTAuth::parseToken()->toUser();
        //   dd($user);

        $redirect_uri = $request->get('redirect_uri') . '&' . http_build_query([
                    'token' => $token,
                    'state' => $request->get('state')
        ]);
        //dd($redirect_uri);
        //return \Redirect::to($redirect_uri);
        header("Location: $redirect_uri");
        exit;

        // return response()->json(compact('token'));
    }

    public function success(Request $request) {
        dd($request->all());
    }

    public function getAuthenticatedUser() {

        try {

            if (!$user = JWTAuth::parseToken()->authenticate()) {
                return response()->json(['user_not_found'], 404);
            }
        } catch (Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {

            return response()->json(['token_expired'], $e->getStatusCode());
        } catch (Tymon\JWTAuth\Exceptions\TokenInvalidException $e) {

            return response()->json(['token_invalid'], $e->getStatusCode());
        } catch (Tymon\JWTAuth\Exceptions\JWTException $e) {

            return response()->json(['token_absent'], $e->getStatusCode());
        }

        return response()->json(compact('user'));
    }

}
