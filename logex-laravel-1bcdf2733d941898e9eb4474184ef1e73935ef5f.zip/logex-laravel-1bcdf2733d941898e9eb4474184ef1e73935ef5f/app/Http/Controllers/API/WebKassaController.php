<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Waybill;
use App\User;
use SnappyImage;
use PDF;
use App\Http\Controllers\WebAPI2\DarBazarController;

class WebKassaController extends Controller {

    public static $host = 'https://kkm.webkassa.kz/';

    //   public static $host = 'http://devkkm.webkassa.kz/';

    public static function curl($data, $url) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    public static function auth($user) {




        $request = [
            "Login" => $user->webkassa_login,
            "Password" => $user->webkassa_password
        ];
        $data = json_decode(WebKassaController::curl(json_encode($request), WebKassaController::$host . 'api/Authorize'), true);

        if (isset($data['Data']['Token'])) {

            User::where('webkassa_login', $user->webkassa_login)->update(['webkassa_token' => $data['Data']['Token']]);

            return 'true';
        } else {
            return 'false';
        }
    }

    public static function zreport($user) {
        $request = [
            "Token" => $user->webkassa_token,
            "CashboxUniqueNumber" => $user->webkassa_id
        ];

        $data = json_decode(WebKassaController::curl(json_encode($request), WebKassaController::$host . 'api/ZReport'));
    }

    public static function pay($waybill_id, $user_id) {

        $waybill = Waybill::find($waybill_id);
        $waybill_data = unserialize($waybill->api_request);

        //  dd(!isset(unserialize($waybill->check_data)['CheckNumber']));
        if ($waybill->check_data == null || !isset(unserialize($waybill->check_data)['Data'])) {
            $user = User::find($user_id);



            $positions = [];

            foreach ($waybill_data['data']['from'] as $from) {
                if ($from['count'] > 0) {
                    $positions[] = [
                        "Count" => $from['count'],
                        "Price" => $from['price'],
                        "Tax" => 0,
                        "TaxType" => 0,
                        "PositionName" => $from['product']
                    ];
                }
            }
            /*
              if ($waybill_data['data']['payment_type'] == 'наличный') {


              $positions[] = [
              "Count" => 1,
              "Price" => $waybill->commission,
              "Tax" => 0,
              "TaxType" => 0,
              "PositionName" => 'Комиссия'
              ];
              }
             * 
             */

            $positions[] = [
                "Count" => 1,
                "Price" => $waybill_data['data']['total_cost'],
                "Tax" => round((($waybill_data['data']['total_cost'] - $waybill_data['data']['total_cost'] / 1.12)), 2),
                "TaxType" => 100, // 100
                "PositionName" => 'Доставка'
            ];
            // dd($positions);

            $payment_total_sum = ($waybill_data['data']['payment_sum'] + $waybill_data['data']['total_cost']);
            if ($waybill_data['data']['payment_type'] == 'наличный') {
                //$payment_total_sum += $waybill->commission;
            }

            $request = [
                "Token" => $user->webkassa_token,
                "CashboxUniqueNumber" => $user->webkassa_id, //Номер кассы
                "OperationType" => 2, // Продажа
                "Payments" => [
                    ["sum" => $payment_total_sum, "PaymentType" => 0]
                ],
                "Positions" => $positions
            ];

            $data = json_decode(WebKassaController::curl(json_encode($request), WebKassaController::$host . 'api/Check'), true);
//dd($data);




            if (isset($data['Errors'][0])) {

                if ($data['Errors'][0]['Code'] == 9 || $data['Errors'][0]['Code'] == 2) {

                    WebKassaController::auth($user);
                    return WebKassaController::pay($waybill_id, $user_id);
                }
                if ($data['Errors'][0]['Code'] == 11) {
                    WebKassaController::zreport($user);
                    return WebKassaController::pay($waybill_id, $user_id);
                }
            } else {
                $waybill->update(['check_data' => serialize($data)]);
            }
        }
    }

    public function postIndex(Request $request) {

        $data_from = $request->get('data_from');

        $waybill = Waybill::find($request->get('waybill_id'));


        $api_request = unserialize($waybill->api_request);



        $return_reason = '';

        $new_collection = [];

        foreach ($api_request['data']['from'] as $key => $from) {

            if ($from['count'] != $data_from[$key]['count']) {
                $diff_count = $from['count'] - $data_from[$key]['count'];
                // dd($dif);
                $price_diff = $diff_count * $from['price'];


                $api_request['data']['payment_sum'] -= $price_diff;

                $return_reason .= $from['product'] . ' возврат: ' . $diff_count . ' шт. ';


                $new_collection[$key] = $data_from[$key];
                $new_collection[$key]['count'] = $data_from[$key]['count'];

                $new_collection[$key]['old_count'] = $from['count'];
            } else {
                $new_collection[$key] = $data_from[$key];
            }
        }
        //  dd($api_request);

        $api_request['data']['from'] = collect($new_collection);


        if ($return_reason != '') {
            Waybill::where('id', $waybill->id)->update(
                    [
                        'payment_sum' => $api_request['data']['payment_sum'],
                        'return_reason' => $waybill->return_reason . ' ' . $return_reason,
                        'status' => 'Частичный возврат',
                        'delivery_date' => date('Y-m-d'),
                        'delivery_time' => date('H:i:s'),
                        'api_request' => serialize($api_request)
                    ]
            );
        } else {
            Waybill::where('id', $waybill->id)->update(
                    [
                        'delivery_date' => date('Y-m-d'),
                        'delivery_time' => date('H:i:s'),
                        'status' => 'Доставлено'
                    ]
            );

            $ww = Waybill::find($waybill->id);

            DarBazarController::sendStatus($ww, 'Доставлено');
        }
        //  dd($return_reason);
        //  dd($api_request);
        //     exit;

        if ($waybill->payment_type == 'наличный') {
            WebKassaController::pay($request->get('waybill_id'), $request->get('user_id'));

            return WebKassaController::check($request->get('waybill_id'));
        } else {
            return response()->json([]);
        }

        // return WebKassaController::check(28194);
    }

    public function test(Request $request) {


        return WebKassaController::pay(28196, 5);
        //    WebKassaController::pay($request->get('waybill_id'), $request->get('user_id'));
        // return WebKassaController::check($request->get('waybill_id'));
        // return WebKassaController::check(28196);
    }

    public static function check($waybill_id) {

        $waybill = Waybill::find($waybill_id);

        $check = unserialize($waybill->check_data);

        $products = unserialize($waybill->api_request);




        //return view('kassa.check', compact('products', 'check'));
        //return response(iconv("UTF-8", "ISO-8859-5", 'ТОВАРИЩЕСТВО С ОГРАНИЧЕННОЙ{br}ОТВЕТСТВЕННОСТЬЮ "Logex"{br}'.
        //     $products_text.'{br}*** СПАСИБО ЗА ПОКУПКУ ***'))->header('Content-Type', 'text/plain;  charset=ISO-8859-5');
        //    return 'ТОВАРИЩЕСТВО С ОГРАНИЧЕННОЙ{br}ОТВЕТСТВЕННОСТЬЮ "Logex"
        //  $products_text.'{br}*** СПАСИБО ЗА ПОКУПКУ ***'))->header('Content-Type', 'text/plain;  charset=ISO-8859-5');

        $img = SnappyImage::loadView('kassa.check', compact('products', 'check', 'waybill'))->setOption('width', 360);


        $size = getimagesizefromstring($img->output());

        return response()->json(['base64' => base64_encode($img->output()), 'width' => $size[0], 'height' => $size[1]]);
        // return $img->inline('1.jpg');
    }

}
