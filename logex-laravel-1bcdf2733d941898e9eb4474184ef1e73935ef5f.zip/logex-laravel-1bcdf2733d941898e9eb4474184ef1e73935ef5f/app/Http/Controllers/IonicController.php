<?php

namespace App\Http\Controllers;



class IonicController extends Controller {

    public static function sendPush($user_ids, $message) {

        $data = [
            "external_ids" => $user_ids,
            "notification" => [
                "title" => "Logex",
                "message" => $message,
                "priority" => "hight"
            ],
            "profile" => "bender"
        ];
        $data_string = json_encode($data);

        $ch = curl_init('https://api.ionic.io/push/notifications');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI2MzVkNWQ4Zi0yZDcwLTRmYmEtOWY2NS02MDM4NjI2N2M0ODgifQ.bZ5zetKSU_qcJcTPCSyd9v0kp78oRMJJW7k3Q-GiCg0'
           // 'Content-Length: ' . strlen($data_string))
        ));

        $result = curl_exec($ch);
        
        return json_decode($result);
    }

}
