<?php

namespace App\Http\Controllers\WebAPI;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ZonesKz;
use App\Models\ZonesRates;
use App\Models\APIKey;
use App\Models\Waybill;
use App\Models\Company;
use App\Models\Location;

class WaybillController extends Controller {

    public function getStatus($id, Request $request) {

        $waybill = Waybill::find($id);
        $api_key = APIKey::where('key', $request->get('api_key'))->first();

        if ($waybill->user_id == $api_key->user_id) {
            return response()->json(['status' => 'success', 'message' => '', 'data' => [
                            'status' => $waybill->status
            ]]);
        } else {
            return response()->json(['status' => 'error', 'message' => 'Permision denied', 'data' => []], 400);
        }
    }

    public function postCreate(Request $request) {
        $api_key = APIKey::where('key', $request->get('api_key'))->first();

        $company = Company::find($api_key->company_id);



        $data = RatesController::calc($request);

        $to = $data['data']['to'];
        if (count($data['data']['from']) > 1) {
            foreach ($data['data']['from'] as $key => $from) {
                if (Location::where('name', $from['city'])->first() == null) {
                    Location::create(['name' => $from['city']]);
                }
                $waybill = Waybill::create([
                            'code' => $company->next_code,
                            'places' => 1,
                            'weight' => $from['weight'],
                            'kind' => 'Посылка',
                            'priority' => ($data['data']['type'] == 'express' ? 'Экспресс' : 'Стандарт'),
                            'cost' => $from['cost'],
                            'sender_city' => $from['city'],
                            // 'recipient' => $to['name'],
                            //  'recipient_city' => $to['city'],
                            //  'recipient_address' => $to['address'],
                            'sender_phone' => (isset($from['phone']) ? $from['phone'] : ''),
                            'recipient_city' => 'Склад',
                            'recipient_address' => 'Склад',
                            'sender_address' => $from['address'],
                            'company_sender_id' => $company->id,
                            'user_id' => $api_key->user_id,
                            'description' => 'Магазин: ' . $from['name']
                ]);
                $data['data']['from'][$key]['waybill_id'] = $waybill->id;
            }

            if (Location::where('name', $to['city'])->first() == null) {
                Location::create(['name' => $to['city']]);
            }

            $waybill = Waybill::create([
                        'code' => $company->next_code,
                        'places' => 1,
                        'weight' => $data['data']['total_weight'],
                        'kind' => 'Посылка',
                        'priority' => ($data['data']['type'] == 'express' ? 'Экспресс' : 'Стандарт'),
                        'cost' => $to['cost'],
                        'sender_city' => 'Склад',
                        'recipient' => $to['name'],
                        'recipient_city' => $to['city'],
                        'recipient_phone' => (isset($to['phone']) ? $to['phone'] : ''),
                        'recipient_address' => $to['address'],
                        'sender_address' => 'Склад',
                        'company_sender_id' => $company->id,
                        'user_id' => $api_key->user_id,
            ]);
            $data['data']['to']['waybill_id'] = $waybill->id;
        } else {

            if (Location::where('name', $to['city'])->first() == null) {
                Location::create(['name' => $to['city']]);
            }

            $waybill = Waybill::create([
                        'code' => $company->next_code,
                        'places' => 1,
                        'weight' => $data['data']['from'][0]['weight'],
                        'kind' => 'Посылка',
                        'priority' => ($data['data']['type'] == 'express' ? 'Экспресс' : 'Стандарт'),
                        'cost' => ($to['cost']),
                        'sender_city' => $data['data']['from'][0]['city'],
                        'sender_phone' => (isset($data['data']['from'][0]['phone']) ? $data['data']['from'][0]['phone'] : ''),
                        'recipient' => $to['name'],
                        'recipient_city' => $to['city'],
                        'recipient_phone' => $to['phone'],
                        'recipient_address' => $to['address'],
                        'sender_address' => $data['data']['from'][0]['address'],
                        'company_sender_id' => $company->id,
                        'user_id' => $api_key->user_id
            ]);
            $data['data']['from'][0]['waybill_id'] = $waybill->id;
            $data['data']['to']['waybill_id'] = $waybill->id;
        }

        \Mail::send('emails.api', ['data' => $data], function ($m) {
            $from = \Config::get('mail.from');
      
            $m->from($from['address'], $from['name']);

            $m->to('info@logex.kz')->subject('Заказ с DarBazar');
        });

        return response()->json($data);
    }

}