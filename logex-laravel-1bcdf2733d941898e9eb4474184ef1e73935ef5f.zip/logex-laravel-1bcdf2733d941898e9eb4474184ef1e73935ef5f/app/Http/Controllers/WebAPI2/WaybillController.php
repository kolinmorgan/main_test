<?php

namespace App\Http\Controllers\WebAPI2;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ZonesKz;
use App\Models\ZonesRates;
use App\Models\APIKey;
use App\Models\Waybill;
use App\Models\Company;
use App\Models\Location;
use App\Models\Setting;

class WaybillController extends Controller {

    public function getStatus(Request $request) {
        if ($request->has('waybill_id')) {
            $waybill = Waybill::find($request->get('waybill_id'));
        } else {
            $waybill = Waybill::where('darbazar_id', $request->get('id'))->first();
        }
        $api_key = APIKey::where('key', $request->get('api_key'))->first();

        if (!isset($waybill)) {
            return response()->json(['status' => 'error', 'message' => 'Waybill not found', 'data' => []], 500);
        }
        if ($waybill->user_id == $api_key->user_id) {
            return response()->json(['status' => 'success', 'message' => '', 'data' => [
                            'status' => $waybill->status,
                            'status_name' => $waybill->status_name,
                            'send_date' => strtotime($waybill->send_date),
                            'delivery_date' => strtotime($waybill->delivery_date . ' ' . $waybill->delivery_time),
                            'description' => $waybill->description,
                            'updated_at' => strtotime($waybill->updated_at),
                            'created_at' => strtotime($waybill->created_at)
            ]]);
        } else {
            return response()->json(['status' => 'error', 'message' => 'Permision denied', 'data' => []], 400);
        }
    }

    public function postCreate(Request $request) {
        $api_key = APIKey::where('key', $request->get('api_key'))->first();
        $min_products_cost = Setting::where('name', 'min_products_cost')->first()->value;
        $data = RatesController::calc($request);

        if ($data['data']['payment_sum'] >= $min_products_cost) {
			$data['data']['total_cost'] = 0;
        	$data['data']['to']['cost'] = 0;
		}

        if (!$request->has('id')) {

            return response()->json(['status' => 'error', 'message' => 'Set order id', 'data' => []], 400);
        }
        $to = $data['data']['to'];

        /*
          $implode_values = [];

          foreach ($data['data']['from'] as $key => $from) {
          $ar = ['city', 'address', 'name', 'phone', 'volume', 'product'];
          foreach ($ar as $a) {
          if (isset($from[$a]) && $from[$a] != '') {
          $implode_values[$a][$key] = $from[$a];
          } else {
          $implode_values[$a][$key] = 'Не известно';
          }
          }



          $implode_values['name_address'][$key] = '"' . $implode_values['name'][$key] . '" ' . $implode_values['address'][$key];
          }
         */

        if ($data['data']['from']->groupBy('name')->count() == 1) {


            $implode_values = [];

            foreach ($data['data']['from'] as $key => $from) {
                $ar = ['city', 'address', 'name', 'phone', 'volume', 'product'];
                foreach ($ar as $a) {
                    if (isset($from[$a]) && $from[$a] != '') {
                        $implode_values[$a][$key] = $from[$a];
                    } else {
                        $implode_values[$a][$key] = 'Не известно';
                    }
                }



                $implode_values['name_address'][$key] = '"' . $implode_values['name'][$key] . '" ' . $implode_values['address'][$key];
            }

            if (Location::where('name', implode(' ; ', $implode_values['city']))->first() == null) {
                Location::create(['name' => implode(' ; ', $implode_values['city'])]);
            }
            $waybill = Waybill::create([
                        'code' => $request->get('id'),
                        'darbazar_id' => $request->get('id'),
                        'places' => 1,
                        'weight' => $data['data']['total_weight'],
                        'kind' => 'Посылка',
                        'priority' => ($data['data']['type'] == 'express' ? 'Экспресс' : 'Стандарт'),
                        'cost' => $data['data']['total_cost'],
                        'sender_city' => implode(' ; ', $implode_values['city']),
                        'sender_phone' => implode(' ; ', $implode_values['phone']),
                        'sender_address' => implode(' ; ', $implode_values['name_address']),
                        'recipient' => $to['name'],
                        'recipient_city' => $to['city'],
                        'recipient_phone' => (isset($to['phone']) ? $to['phone'] : ''),
                        'recipient_address' => $to['address'],
                        'company_sender_id' => $api_key->company_id,
                        'user_id' => $api_key->user_id,
                        'description' => !empty($request->get('description')) ? $request->get('description') : '',
                        'send_date' => date("d.m.Y H:i", $request->get('send_date')),
                        'volume' => implode(' ; ', $implode_values['volume']),
                        'product' => implode(' ; ', $implode_values['product']),
                        'payment_type' => $data['data']['payment_type'],
                        'api_request' => serialize($data),
                        'payment_sum' => $data['data']['payment_sum']
                            //             'delivery_date' => date("d.m.Y", $request->get('delivery_date')),
                            //             'delivery_time' => date('H:i', $request->get('delivery_date'))
            ]);
            $data['data']['waybill_id'] = $waybill->id;
            $data['data']['code'] = $waybill->code;


        } else {

            $company = Company::find($api_key->company_id);
            $waybill = Waybill::create([
                        'code' => $request->get('id'),
                        'darbazar_id' => $request->get('id'),
                        'places' => 1,
                        'weight' => $data['data']['total_weight'],
                        'kind' => 'Посылка',
                        'priority' => ($data['data']['type'] == 'express' ? 'Экспресс' : 'Стандарт'),
                        'cost' => $data['data']['total_cost'],
                        'sender_city' => '',
                        'sender_phone' => '',
                        'sender_address' => 'С.Ц.',
                        'recipient' => $to['name'],
                        'recipient_city' => $to['city'],
                        'recipient_phone' => (isset($to['phone']) ? $to['phone'] : ''),
                        'recipient_address' => $to['address'],
                        'company_sender_id' => $company->id,
                        'user_id' => $api_key->user_id,
						'description' => !empty($request->get('description')) ? $request->get('description') : '',
                        'send_date' => date("d.m.Y H:i", $request->get('send_date')),
                        'volume' => '',
                        'product' => '',
                        'payment_type' => $data['data']['payment_type'],
                        'api_request' => serialize($data),
                        'payment_sum' => $data['data']['payment_sum']
                            //             'delivery_date' => date("d.m.Y", $request->get('delivery_date')),
                            //             'delivery_time' => date('H:i', $request->get('delivery_date'))
            ]);

            $data['data']['waybill_id'] = $waybill->id;
            $data['data']['code'] = $waybill->code;


            $part = 0;

            foreach ($data['data']['from']->groupBy('name') as $company_name => $items) {
                $part += 1;

                $company = Company::where('name', $company_name)->first();
                if ($company == null) {
                    $company = Company::create(['name' => $company_name, 'address' => $items[0]['address']]);
                }

                $product_names = [];
                $total_weight = 0;
                $total_cost = 0;
                foreach ($items as $item) {
                    $total_weight += $item['weight'];
                    $product_names[] = $item['product'] . ' ' . $item['weight'] . 'кг x ' . $item['count'] . 'шт. ';
                    $total_cost += $item['count'] * $item['price'];
                }
                $product_name = implode(' ; ', $product_names);

                $from = $items[0];
                $waybill = Waybill::create([
                            'code' => $request->get('id').'/'.$part,
                            'darbazar_id' => $request->get('id'),
                            'places' => 1,
                            'weight' => $total_weight,
                            'kind' => 'Посылка',
                            'priority' => ($data['data']['type'] == 'express' ? 'Экспресс' : 'Стандарт'),
                            'cost' => '',
                            'sender_city' => isset($item['city']) ? $from['city'] : '',
                            'sender_phone' => isset($from['phone']) ? $from['phone'] : '',
                            'sender_address' => isset($from['address']) ? $from['address'] : '',
                            'company_recipient_name' => 'С.Ц.',
                            'recipient' => $to['name'],
                            'recipient_city' => $to['city'],
                            'recipient_phone' => (isset($to['phone']) ? $to['phone'] : ''),
                            'recipient_address' => $to['address'],
                            'company_sender_id' => $company->id,
                            'user_id' => $api_key->user_id,
							'description' => !empty($request->get('description')) ? $request->get('description') : '',
                            'send_date' => date("d.m.Y H:i", $request->get('send_date')),
                            'volume' =>  isset($from['volume']) ? $from['volume'] : '',
                            'product' => $product_name,
                            'main_waybill_id' => $data['data']['waybill_id'],
                            'payment_type' => $data['data']['payment_type'],
                            'payment_sum' => $total_cost,
                                //    'price' => $from['price'],
                                //    'count' => $from['count']
                                //             'delivery_date' => date("d.m.Y", $request->get('delivery_date')),
                                //             'delivery_time' => date('H:i', $request->get('delivery_date'))
                ]);
            }
        }



        \Mail::send('emails.api', ['data' => $data], function ($m) {
            $from = \Config::get('mail.from');

            $m->from($from['address'], $from['name']);

            $m->to('logex@webid.kz')->subject('Заказ с DarBazar');
        });

        return response()->json($data);
    }

}
