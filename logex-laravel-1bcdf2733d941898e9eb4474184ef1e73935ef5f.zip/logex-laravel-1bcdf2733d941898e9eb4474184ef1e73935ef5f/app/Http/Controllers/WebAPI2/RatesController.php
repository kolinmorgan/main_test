<?php

namespace App\Http\Controllers\WebAPI2;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ZonesKz;
use App\Models\ZonesRates;

class RatesController extends Controller {

    public function postIndex(Request $request) {

        $response = $this->calc($request);

        if ($response['status'] == 'success') {
            return response()->json($response);
        } else {
            return response()->json($response, 400);
        }
    }

    public function json_error($error) {
        //$errors[] = $error;
        return json_encode(compact('error'));
    }

    /*
      public static function calc($request) {

      $status = 'success';
      $message = '';
      $from = $request->get('from');
      $type = $request->get('type');
      if (count($from) > 5) {
      $status = 'error';
      $message = 'Max 5 consolidation';
      }

      $total_cost = 0;
      $total_weight = 0;


      if ($status == 'success') {
      $all_almaty = true;
      foreach ($from as $key => $cargo) {
      if ($cargo['city'] != 'Алматы') {
      $all_almaty = false;
      } else {

      $zone = ZonesKz::where('city', $cargo['city'])->first();
      $rates = ZonesRates::where('type', 'consolidation_' . $type)->orderBy('max_weight')->get();

      $max_fixed_weight = 0;
      $cost = 0;
      $zone_name = 'zone_' . $zone->zone_id;
      //  dd($zone_name);
      foreach ($rates as $rate) {
      if ($rate->rate_type == 'fixed') {
      $fixed = $rate;
      $max_fixed_weight = $rate->max_weight;
      if ($cargo['weight'] <= $rate->max_weight) {
      $cost = (float) $rate->$zone_name;
      }
      } else {
      $exta = $rate;


      if ($cargo['weight'] > $rate->max_weight) {
      $status = 'error';

      $message = 'Max weight - ' . $rate->max_weight;
      }
      }
      }
      // dd($cost);
      if ($cost == 0) {
      $extra_weight = ceil($cargo['weight'] - $max_fixed_weight);

      $cost = $fixed->$zone_name + ($exta->$zone_name * $extra_weight);
      }
      $from[$key]['cost'] = 0;

      $total_weight += $cargo['weight'];

      }
      }

      if (!$all_almaty) {
      foreach ($from as $key => $cargo) {


      $zone = ZonesKz::where('city', $cargo['city'])->first();

      if ($zone == null) {
      $status = 'error';
      $message = 'Unknown city - ' . $cargo['city'];
      } else {
      $rates = ZonesRates::where('type', 'consolidation_' . $type)->orderBy('max_weight')->get();

      $max_fixed_weight = 0;
      $cost = 0;
      $zone_name = 'zone_' . $zone->zone_id;
      //  dd($zone_name);
      foreach ($rates as $rate) {
      if ($rate->rate_type == 'fixed') {
      $fixed = $rate;
      $max_fixed_weight = $rate->max_weight;
      if ($cargo['weight'] <= $rate->max_weight) {
      $cost = (float) $rate->$zone_name;
      }
      } else {
      $exta = $rate;


      if ($cargo['weight'] > $rate->max_weight) {
      $status = 'error';

      $message = 'Max weight - ' . $rate->max_weight;
      }
      }
      }
      // dd($cost);
      if ($cost == 0) {
      $extra_weight = ceil($cargo['weight'] - $max_fixed_weight);

      $cost = $fixed->$zone_name + ($exta->$zone_name * $extra_weight);
      }
      $from[$key]['cost'] = $cost;
      $total_cost += $cost;
      $total_weight += $cargo['weight'];
      }
      }
      }

      }


      foreach ($from as $f) {
      $total_weight += $f['weight'];
      }


      $to = $request->get('to');

      if ($all_almaty) {
      $zone_id = 0;
      } else {
      $zone_id = 1;
      }



      if (count($from) == 1) {
      $rates = ZonesRates::where('type', 'api_delivery_' . $type)->orderBy('max_weight')->get();
      } else {
      $rates = ZonesRates::where('type', 'consolidation_' . $type)->orderBy('max_weight')->get();
      }
      $max_fixed_weight = 0;
      $cost = 0;

      $zone_name = 'zone_' . $zone_id;

      foreach ($rates as $rate) {

      if ($rate->rate_type == 'fixed') {
      $fixed = $rate;
      $max_fixed_weight = $rate->max_weight;
      if ($total_weight <= $rate->max_weight) {
      $cost = (float) $rate->$zone_name;
      }
      } else {
      $exta = $rate;


      if ($total_weight > $rate->max_weight) {
      $status = 'error';

      $message = 'Max total weight - ' . $rate->max_weight;
      }
      }
      }


      if ($cost == 0) {
      $extra_weight = ceil($total_weight - $max_fixed_weight);

      $cost = $fixed->$zone_name + ($exta->$zone_name * $extra_weight);
      }

      $to['cost'] = $cost;
      $total_cost += $cost;






      if ($status == 'success') {


      return [
      'status' => 'success',
      'message' => $message,
      'data' => [
      'total_cost' => $total_cost,
      'total_weight' => $total_weight,
      'from' => $from,
      'to' => $to,
      'type' => $type
      ]
      ];
      } else {
      return ['status' => 'error', 'message' => $message, 'data' => []];
      }
      }
     */

    public static function calc($request) {

        if($request->has('payment_type')) {
            if($request->get('payment_type') == 'cash') {
                $payment_type = 'наличный';
            } else {
                $payment_type = 'безналичный';
            }
        } else {
            $payment_type = null;
        }
        
        
        $status = 'success';
        $message = '';
        $from = $request->get('from');
        $type = $request->get('type');


        $total_cost = 0;
        $total_weight = 0;

        $from = collect($from);


        $payment_sum = 0;
        foreach($from as $f) {
          
            
            if(isset($f['price']) && isset($f['count'])) {
                $payment_sum += ($f['price'] * $f['count']);
            }
        }
      
        $from_count = $from->unique('address')->count();

       /*
        if ( $from_count > 5) {
            $status = 'error';
            $message = 'Max 5 consolidation';
        }
        * 
        */
        
        
        if ($status == 'success') {

            $to = $request->get('to');

            if ($from_count == 1) {
                if ($from[0]['city'] == $to['city']) {
                    $zone_id = 0;
                } else {
                    if ($from[0]['city'] == 'Алматы' || $to['city'] == 'Алматы') {
                        $zone_id = 1;
                    } else {
                        $zone_id = 2;
                    }
                }
            } else {

                if ($from->whereLoose('city', $to['city'])->count() == $from->count()) {
                    $zone_id = 0;
                } else {
                    if ($from->whereLoose('city', 'Алматы')->count() == $from->count() || $to['city'] == 'Алматы') {
                        $zone_id = 1;
                    } else {
                        $zone_id = 2;
                    }
                }
            }


            foreach ($from as $f) {
                $total_weight += $f['weight'];
            }




            if ($from_count == 1) {
                $rates = ZonesRates::where('type', 'api_delivery_' . $type)->orderBy('max_weight')->get();
            } else {
                $rates = ZonesRates::where('type', 'consolidation_' . $type)->orderBy('max_weight')->get();
            }


            $max_fixed_weight = 0;
            $cost = 0;

            $zone_name = 'zone_' . $zone_id;

           
            foreach ($rates as $rate) {

                if ($rate->rate_type == 'fixed') {
                    $fixed = $rate;
                    $max_fixed_weight = $rate->max_weight;
                    if ($total_weight <= $rate->max_weight) {
                        $cost = (float) $rate->$zone_name;
                    }
                } elseif($rate->rate_type == 'extra') {
                    $exta = $rate;


                    if ($total_weight > $rate->max_weight) {
                        $status = 'error';

                        $message = 'Max total weight - ' . $rate->max_weight;
                    }
                } elseif ($rate->rate_type == 'consolidation') {
                    $cons = $rate;
                }
            }

            

            if ($cost == 0) {
                $extra_weight = ceil($total_weight - $max_fixed_weight);

                $cost = $fixed->$zone_name + ($exta->$zone_name * $extra_weight);
            }
            
            if($from_count > 5) {
                $cost += ($from_count-5)*$cons->$zone_name;
            }

            $to['cost'] = $cost;
            $total_cost += $cost;
        }

        if ($status == 'success') {

            return [
                'status' => 'success',
                'message' => $message,
                'data' => [
                    'total_cost' => $total_cost,
                    'total_weight' => $total_weight,
                    'payment_type' => $payment_type,
                    'payment_sum' => $payment_sum,
                    'from' => $from,
                    'to' => $to,
                    'type' => $type
                ]
            ];
        } else {
            return ['status' => 'error', 'message' => $message, 'data' => []];
        }
    }

}
