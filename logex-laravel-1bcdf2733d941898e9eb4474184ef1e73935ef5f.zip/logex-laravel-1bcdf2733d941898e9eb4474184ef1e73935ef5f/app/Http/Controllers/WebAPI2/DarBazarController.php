<?php

namespace App\Http\Controllers\WebAPI2;

use App\Http\Controllers\Controller;
use App\Models\Waybill;

class DarBazarController extends Controller {

    public static function sendStatus($waybill, $status) {

     //   dd($waybill);
        $api_key = \App\Models\APIKey::first();
        
        $id = $waybill->darbazar_id;

        if ($api_key->user_id == $waybill->user_id && $api_key->company_id != $waybill->company_sender_id) {
            
            $id = $waybill->darbazar_id;

            if ($waybill->main_waybill_id != '') {
                $main_waybill = Waybill::where('id', $waybill->main_waybill_id)->with('waybills')->first();
                if ($main_waybill->waybills->where('status', 'Забор осуществлён')->count() != count($main_waybill->waybills)) {
                    return false;
                } else {
                    $main_waybill->update(['status' => 'Забор осуществлён']);
                    
                    DarBazarController::sendStatus($main_waybill, 'Забор осуществлён');
                }
            }
        }

        if ($api_key->company_id == $waybill->company_sender_id) {

            switch ($status) {
                case "Новая": $code = 'new';
                    break;
                case "В обработке": $code = "accepted";
                    break;
                case "В доставке": $code = "delivery";
                    break;
                case "Доставлено": $code = "delivered";
                    break;
                case "Не доставлено": $code = "not_delivered";
                    break;
                case "Возврат": $code = "returned";
                    break;
                case "Забор осуществлён": $code = "pickup";
                    break;
                case "Частичный возврат": $code = "partial_return";
                    break;
            }

            //dd($code);

            $post = [
                'order' => $id,
                'status' => $status,
                'code' => $code,
                'api_key' => 'hYK7nnB1fJbkC+30zZ1aT51q76MNtnrcA6BvKaqftcBx7HxtQwbU54vE5YLBkBEET+hSCL9RToIVUBNZW3ElSA==',
            ];


            $ch = curl_init('https://darbazar.kz/api/notify/v1/logex');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);

            $response = curl_exec($ch);


            curl_close($ch);
        }
    }

}
