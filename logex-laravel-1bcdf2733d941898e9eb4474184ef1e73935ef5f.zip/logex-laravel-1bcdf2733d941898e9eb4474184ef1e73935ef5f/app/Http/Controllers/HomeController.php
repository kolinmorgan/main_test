<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;

class HomeController extends Controller
{

    public function index()
    {
        return view('frontend.home');
    }


    public function staticPage($page)
    {
        return view('frontend.'.$page);
    }
    
}
