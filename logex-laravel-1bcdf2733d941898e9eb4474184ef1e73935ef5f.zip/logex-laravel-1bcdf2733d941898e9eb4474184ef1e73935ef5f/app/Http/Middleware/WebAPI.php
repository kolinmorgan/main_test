<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use App\Models\APIKey;

class WebAPI {

    public function handle($request, Closure $next) {

        $api_key = APIKey::where('key', $request->get('api_key'))->first();

        
        if($api_key == null) {
            
            return response('Unauthorized.', 401);
        
        }

        return $next($request);
    }

}
