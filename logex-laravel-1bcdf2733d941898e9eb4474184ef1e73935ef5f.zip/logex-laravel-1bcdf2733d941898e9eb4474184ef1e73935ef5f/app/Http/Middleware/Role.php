<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class Role {

    
    public function handle($request, Closure $next, $role) {

        $permision = [
            'admin' => ['admin'],
            'manager' => ['admin', 'manager'],
            'courier' => ['admin', 'courier'],
            'user' => ['admin', 'manager', 'courier', 'user']
        ];

        if (!in_array(Auth::user()->role, $permision[$role])) {

            if ($request->ajax() || $request->wantsJson()) {
                return response('Unauthorized.', 401);
            } else {
                return redirect('/cabinet/waybills');
            }
        }

        return $next($request);
    }

}
